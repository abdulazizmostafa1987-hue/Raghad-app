# Round 9 — Non-blocking quiz completion (2026-11-22)

- Fixed the underlying completion-path issue: saving an attempt no longer waits for the optional native Android launcher-widget plugin to respond.
- Quiz XP, review scheduling, and attempt history are persisted first; the home-screen widget refresh is dispatched in the background and safely ignored if the native bridge is unavailable.
- Kept the visible result percentage assertion and stable result-key assertion in the true/false widget test.
- Bumped app version to 0.6.3+9.

Validation: source-level checks and curriculum audit are run before packaging. Flutter/Dart SDK is not available in this editing environment, so `flutter test`, `flutter analyze`, and APK build must be confirmed by GitHub Actions.
