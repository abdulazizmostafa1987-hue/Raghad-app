#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/android/app"
MANIFEST="$APP/src/main/AndroidManifest.xml"
PKG_DIR="$APP/src/main/kotlin/com/example/raghad"
mkdir -p "$APP/src/main/res/layout" "$APP/src/main/res/xml" "$APP/src/main/res/drawable" "$PKG_DIR"
cat > "$APP/src/main/res/layout/raghad_home_widget.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/widget_root" android:layout_width="match_parent"
    android:layout_height="match_parent" android:orientation="vertical"
    android:padding="14dp" android:gravity="center_vertical"
    android:background="@drawable/raghad_widget_bg">
    <TextView android:id="@+id/widget_title" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:text="رغد – رحلتي نحو التفوق"
        android:textColor="#FFFFFF" android:textSize="16sp" android:textStyle="bold" />
    <TextView android:id="@+id/widget_lesson" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:layout_marginTop="5dp"
        android:text="ابدئي رحلة التعلم" android:textColor="#FFF5FC" android:textSize="13sp"
        android:maxLines="2" android:ellipsize="end" />
    <TextView android:id="@+id/widget_stats" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:layout_marginTop="9dp"
        android:text="⭐ 0 نقطة   •   🔥 0 يوم" android:textColor="#FFE8A3" android:textSize="12sp" />
    <TextView android:id="@+id/widget_footer" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:layout_marginTop="4dp"
        android:text="اضغطي لفتح رغد" android:textColor="#EADCFB" android:textSize="11sp" />
</LinearLayout>
XML
cat > "$APP/src/main/res/drawable/raghad_widget_bg.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <corners android:radius="20dp" />
    <gradient android:angle="135" android:startColor="#7045B5" android:centerColor="#8C60C5" android:endColor="#D879A7" />
</shape>
XML
cat > "$APP/src/main/res/xml/raghad_home_widget_info.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="220dp" android:minHeight="110dp"
    android:minResizeWidth="180dp" android:minResizeHeight="90dp"
    android:updatePeriodMillis="0" android:initialLayout="@layout/raghad_home_widget"
    android:resizeMode="horizontal|vertical" android:widgetCategory="home_screen"
    android:description="@string/raghad_widget_description" />
XML
cat > "$PKG_DIR/RaghadHomeWidgetProvider.kt" <<'KOTLIN'
package com.example.raghad

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetLaunchIntent
import es.antonborri.home_widget.HomeWidgetProvider

class RaghadHomeWidgetProvider : HomeWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
        widgetData: SharedPreferences
    ) {
        appWidgetIds.forEach { widgetId ->
            val views = RemoteViews(context.packageName, R.layout.raghad_home_widget).apply {
                val name = widgetData.getString("studentName", "رغد") ?: "رغد"
                val lesson = widgetData.getString("lastLesson", "ابدئي رحلة التعلم") ?: "ابدئي رحلة التعلم"
                val xp = widgetData.getString("xp", "0") ?: "0"
                val streak = widgetData.getString("streak", "0") ?: "0"
                val minutes = widgetData.getString("studyMinutes", "0") ?: "0"
                setTextViewText(R.id.widget_title, "$name – رحلتي نحو التفوق")
                setTextViewText(R.id.widget_lesson, "آخر درس: $lesson")
                setTextViewText(R.id.widget_stats, "⭐ $xp نقطة   •   🔥 $streak يوم   •   ⏱ $minutes دقيقة")
                setOnClickPendingIntent(R.id.widget_root, HomeWidgetLaunchIntent.getActivity(context, MainActivity::class.java))
            }
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }
}
KOTLIN
# Add localized widget description resource.
mkdir -p "$APP/src/main/res/values"
cat > "$APP/src/main/res/values/raghad_widget_strings.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources><string name="raghad_widget_description">آخر درس ونقاط التعلم في رغد</string></resources>
XML
python - "$MANIFEST" <<'PY'
import sys
from pathlib import Path
p=Path(sys.argv[1]); s=p.read_text(encoding='utf-8')
receiver='''        <receiver android:name="com.example.raghad.RaghadHomeWidgetProvider" android:exported="true" android:label="رغد – رحلتي نحو التفوق">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/raghad_home_widget_info" />
        </receiver>'''
if 'RaghadHomeWidgetProvider' not in s:
    s=s.replace('</application>', receiver+'\n    </application>')
p.write_text(s,encoding='utf-8')
PY
