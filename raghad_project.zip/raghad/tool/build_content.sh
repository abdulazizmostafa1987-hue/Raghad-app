#!/usr/bin/env bash
# يعيد توليد كل الإضافات (آمن لإعادة التشغيل) ثم يفحص المحتوى.
set -e
cd "$(dirname "$0")/.."
python3 tool/enrich_extra.py
python3 tool/enrich_content.py
python3 tool/audit_curriculum.py
