#!/usr/bin/env python3
"""Validate Raghad curriculum JSON without requiring Flutter."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
content = json.loads((ROOT / "assets/content/sample_content.json").read_text(encoding="utf-8"))
catalog = json.loads((ROOT / "assets/content/curriculum_catalog.json").read_text(encoding="utf-8"))
errors, warnings = [], []
subjects = content.get("subjects", [])
subject_ids = [s.get("id") for s in subjects]
if len(subject_ids) != len(set(subject_ids)):
    errors.append("Duplicate subject IDs")
lesson_ids, question_ids = set(), set()
lesson_count = question_count = 0
for subject in subjects:
    if not subject.get("id") or not subject.get("lessons"):
        errors.append(f"Empty subject package: {subject.get('id')}")
    for lesson in subject.get("lessons", []):
        lesson_count += 1
        lid = lesson.get("id")
        if not lid or lid in lesson_ids:
            errors.append(f"Missing/duplicate lesson ID: {lid}")
        lesson_ids.add(lid)
        if not lesson.get("title") or len((lesson.get("body") or "").strip()) < 80:
            errors.append(f"Missing title or short explanation: {lid}")
        questions = lesson.get("questions", [])
        if len(questions) < 3:
            errors.append(f"Fewer than 3 questions: {lid}")
        for q in questions:
            question_count += 1
            qid = q.get("id")
            if not qid or qid in question_ids:
                errors.append(f"Missing/duplicate question ID: {qid}")
            question_ids.add(qid)
            options, answer = q.get("options", []), q.get("answer")
            if not isinstance(answer, int) or answer < 0 or answer >= len(options):
                errors.append(f"Invalid answer index: {qid}")
            if not q.get("text") or not q.get("explanation"):
                errors.append(f"Question missing text/explanation: {qid}")
# Every catalog entry must point to a package; track-specific packages are explicit.
catalog_ids = [x.get("id") for x in catalog.get("term1", {}).get("subjects", [])]
for sid in catalog_ids:
    if sid not in subject_ids:
        errors.append(f"Catalog subject has no lesson package: {sid}")
for sid in subject_ids:
    if sid not in catalog_ids and not sid.endswith("_2025_2026") and sid not in {"math_en","math_fr","science_ar","science_fr"}:
        warnings.append(f"Package not listed in main term1 catalog: {sid}")
print(f"Subjects={len(subjects)} Lessons={lesson_count} Questions={question_count}")
print(f"Errors={len(errors)} Warnings={len(warnings)}")
for item in errors + warnings:
    print(("ERROR: " if item in errors else "WARN: ") + item)
raise SystemExit(1 if errors else 0)
