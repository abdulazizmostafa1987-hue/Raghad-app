#!/usr/bin/env python3
"""Enrich Raghad content: richer math drills (computed, so always correct),
derived practice for every subject, summaries and worked examples.
Idempotent: removes previously generated items (ids containing '-x') before adding.
"""
import json, random, math
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / "assets/content/sample_content.json"
data = json.loads(P.read_text(encoding="utf-8"))

def mcq(r, text, correct, wrongs, expl, d=1):
    opts = [str(correct)]
    for w in wrongs:
        if str(w) not in opts: opts.append(str(w))
    r.shuffle(opts)
    return dict(type="mcq", text=text, options=opts, answer=opts.index(str(correct)), difficulty=d, explanation=expl)

def tf(text, truth, expl, d=1):
    return dict(type="tf", text=text, options=["صح", "خطأ"], answer=0 if truth else 1, difficulty=d, explanation=expl)

def order(text, items, expl, d=2):
    return dict(type="order", text=text, options=[str(i) for i in items], answer=0, difficulty=d, explanation=expl)

def near(r, v, k=3, lo=None):
    out = set()
    for _ in range(40):
        c = v + r.choice([-1, 1]) * r.randint(1, max(2, abs(int(v)) // 4 + 3))
        if c != v and (lo is None or c >= lo): out.add(c)
        if len(out) >= k: break
    return list(out)[:k]

def fr(x):  # pretty fraction
    return f"{x.numerator}/{x.denominator}" if x.denominator != 1 else str(x.numerator)

def prime_factors(n):
    f, d = [], 2
    while n > 1:
        while n % d == 0: f.append(d); n //= d
        d += 1
    return f

def median(a):
    a = sorted(a); n = len(a)
    return a[n // 2] if n % 2 else Fraction(a[n // 2 - 1] + a[n // 2], 2)

def num(v):
    v = Fraction(v)
    return str(v.numerator) if v.denominator == 1 else (str(float(v)).rstrip('0').rstrip('.'))

# ---------------------------------------------------------------- math generators
def g_div(r):
    qs = []
    for d in (2, 5, 10):
        n = r.randint(12, 99) * d
        qs.append(mcq(r, f"أي الأعداد الآتية يقبل القسمة على {d}؟", n,
                      [n + r.choice(range(1, d)) for _ in range(3)] if d > 1 else [],
                      f"{n} ÷ {d} = {n // d} بدون باقٍ.", 1))
    for d in (3, 9):
        n = r.randint(100, 900)
        ok = n % d == 0
        s = sum(map(int, str(n)))
        qs.append(tf(f"العدد {n} يقبل القسمة على {d}.", ok,
                     f"مجموع أرقامه {s}، و{s} {'يقبل' if s % d == 0 else 'لا يقبل'} القسمة على {d}.", 2))
    n = r.choice([36, 48, 72, 84, 96, 120, 144])
    qs.append(tf(f"العدد {n} يقبل القسمة على 6.", True, f"{n} زوجي ومجموع أرقامه {sum(map(int,str(n)))} يقبل القسمة على 3، فيقبل القسمة على 6.", 2))
    m = r.choice([35, 55, 75, 95, 115])
    qs.append(tf(f"العدد {m} يقبل القسمة على 6.", False, f"{m} فردي فلا يقبل القسمة على 2، وبالتالي لا يقبل القسمة على 6.", 2))
    a = r.randint(1, 8) * 100 + r.randint(1, 9) * 10 + 2
    qs.append(tf(f"العدد {a} يقبل القسمة على 4.", a % 4 == 0, f"نحكم بآخر رقمين {a % 100}: {'يقبل' if (a % 100) % 4 == 0 else 'لا يقبل'} القسمة على 4.", 2))
    for _ in range(2):
        d = r.choice([3, 4, 6, 9])
        n = r.randint(20, 90)
        c = n * d
        qs.append(mcq(r, f"ما أصغر عدد من ثلاثة أرقام يقبل القسمة على {d}؟", ((99 // d) + 1) * d,
                      [100, ((99 // d) + 2) * d, ((99 // d)) * d], f"نقسم 100 على {d} ونأخذ أول ناتج صحيح ونضربه في {d}.", 3))
    ex = f"مثال محلول: هل 756 يقبل القسمة على 9؟ نجمع أرقامه: 7 + 5 + 6 = 18، و18 يقبل القسمة على 9، إذن نعم."
    return qs, ex

def g_prime(r):
    qs = []
    n = r.choice([12, 18, 20, 24, 30, 36, 45, 48, 60, 72])
    f = prime_factors(n)
    qs.append(mcq(r, f"ما التحليل إلى العوامل الأولية للعدد {n}؟", " × ".join(map(str, f)),
                  [" × ".join(map(str, prime_factors(n + 2))), " × ".join(map(str, f[:-1] + [f[-1] * 2])) if f[-1] * 2 else "2 × 2",
                   " × ".join(map(str, sorted(f + [2])))], f"نجزئ {n} حتى تصبح العوامل أولية: {' × '.join(map(str,f))}.", 1))
    for _ in range(2):
        a = r.choice([7, 11, 13, 17, 19, 23, 29, 31])
        b = r.choice([9, 15, 21, 25, 27, 33, 35])
        qs.append(mcq(r, "أي الأعداد الآتية أولي؟", a, [b, b + 6, b + 12], f"{a} لا يقبل القسمة إلا على 1 ونفسه.", 1))
    for n in r.sample([24, 28, 40, 54, 63, 90], 3):
        f = prime_factors(n)
        qs.append(mcq(r, f"كم عاملًا أوليًا (بالتكرار) في تحليل {n}؟", len(f), [len(f) + 1, len(f) - 1, len(set(f)) + 3],
                      f"{n} = {' × '.join(map(str,f))} وفيه {len(f)} عوامل.", 2))
    n = r.choice([100, 150, 200, 360])
    qs.append(tf(f"العدد 1 عدد أولي.", False, "العدد الأولي له عاملان مختلفان بالضبط، و1 له عامل واحد فقط.", 2))
    qs.append(order(f"رتّبي خطوات تحليل {n}:", [f"نكتب {n} كحاصل ضرب عاملين", "نجزئ العامل غير الأولي", "نكرر حتى تصبح العوامل كلها أولية", "نكتب حاصل ضرب العوامل الأولية"],
                    "نبدأ بعاملين ثم نجزئ ونكرر ثم نكتب الناتج.", 2))
    return qs[:9], "مثال محلول: 84 = 2 × 42 = 2 × 2 × 21 = 2 × 2 × 3 × 7."

def g_gcf(r):
    qs = []
    for _ in range(4):
        g = r.choice([2, 3, 4, 5, 6, 8, 9, 12])
        a, b = g * r.randint(2, 6), g * r.randint(7, 12)
        gg = math.gcd(a, b)
        qs.append(mcq(r, f"ما ع.م.أ للعددين {a} و{b}؟", gg, near(r, gg, 3, 1), f"أكبر عدد يقسم {a} و{b} معًا هو {gg}.", 1 if _ < 2 else 2))
    for _ in range(2):
        g = r.choice([3, 4, 5, 6, 7]); p, q = r.randint(2, 5), r.randint(6, 9)
        a, b = g * p, g * q
        qs.append(mcq(r, f"اكتبي {a} + {b} باستخدام ع.م.أ:", f"{g} × ({p} + {q})",
                      [f"{p} × ({g} + {q})", f"{g} × ({p} × {q})", f"{g + 1} × ({p} + {q})"], f"ع.م.أ = {g}، فـ {a} + {b} = {g} × ({p} + {q}).", 2))
    a, b = r.choice([(18, 24), (20, 30), (28, 42), (36, 60)])
    qs.append(mcq(r, f"لدى سلمى {a} وردة و{b} شمعة وتريد توزيعها في أكياس متماثلة بلا بقايا. ما أكبر عدد أكياس؟", math.gcd(a, b),
                  near(r, math.gcd(a, b), 3, 1), f"أكبر عدد أكياس = ع.م.أ({a}, {b}) = {math.gcd(a,b)}.", 3))
    qs.append(tf("ع.م.أ لعددين لا يكون أكبر من أصغر العددين.", True, "العامل المشترك الأكبر يقسم العددين، فلا يزيد عن أصغرهما.", 2))
    qs.append(tf("ع.م.أ للعددين 7 و13 هو 1.", True, "7 و13 عددان أوليان مختلفان، فلا يشتركان إلا في العامل 1.", 2))
    return qs[:9], "مثال محلول: ع.م.أ(24, 36): عوامل 24: 1،2،3،4،6،8،12،24 وعوامل 36: 1،2،3،4،6،9،12،18،36؛ أكبر مشترك 12."

def g_lcm(r):
    qs = []
    for _ in range(4):
        a, b = r.choice([(4, 6), (6, 8), (3, 5), (6, 9), (8, 12), (10, 15), (4, 10), (9, 12)])
        l = a * b // math.gcd(a, b)
        qs.append(mcq(r, f"ما م.م.أ للعددين {a} و{b}؟", l, [a * b if a * b != l else l + a, l + a, l - 1 if l > 1 else 3],
                      f"أول مضاعف مشترك لـ {a} و{b} هو {l}.", 1 if _ < 2 else 2))
    for a, b in [(6, 8), (10, 12)]:
        l = a * b // math.gcd(a, b)
        qs.append(mcq(r, f"يرن جرس كل {a} دقائق وجرس آخر كل {b} دقائق ويرنان معًا الآن. بعد كم دقيقة يرنان معًا مرة أخرى؟", l,
                      [a * b, l + a, a + b], f"نحتاج م.م.أ({a}, {b}) = {l}.", 3))
    qs.append(tf("م.م.أ لعددين لا يقل عن أكبرهما.", True, "المضاعف المشترك مضاعف للأكبر أيضًا فلا يقل عنه.", 2))
    qs.append(mcq(r, "أي ما يلي مضاعف مشترك للعددين 4 و6؟", 24, [18, 10, 14], "24 = 4 × 6 = 6 × 4.", 2))
    qs.append(tf("م.م.أ للعددين 5 و7 هو 35.", True, "5 و7 أوليان فم.م.أ = حاصل ضربهما.", 2))
    return qs[:9], "مثال محلول: م.م.أ(6, 8): مضاعفات 6: 6،12،18،24 ومضاعفات 8: 8،16،24؛ أول مشترك 24."

def g_numline(r):
    qs = []
    for _ in range(2):
        a, b = r.sample(range(-9, 10), 2)
        qs.append(mcq(r, f"أي العددين أكبر: {a} أم {b}؟", max(a, b), [min(a, b)], f"على خط الأعداد، العدد الأكبر يقع إلى اليمين: {max(a,b)}.", 1))
    for _ in range(2):
        a = r.randint(-9, -2); b = r.randint(-9, -2)
        while a == b: b = r.randint(-9, -2)
        qs.append(mcq(r, f"درجة الحرارة {a}° في مدينة و{b}° في أخرى. أيهما أبرد؟", min(a, b), [max(a, b)], f"العدد الأصغر ({min(a,b)}) أبعد نحو اليسار، فهو الأبرد.", 2))
    s = r.sample(range(-8, 9), 5)
    qs.append(order("رتّبي الأعداد من الأصغر إلى الأكبر:", sorted(s), "نرتبها حسب موقعها على خط الأعداد من اليسار لليمين.", 2))
    a = r.randint(-8, -2)
    qs.append(mcq(r, f"ما العدد الذي يقع بين {a} و{a+2} على خط الأعداد؟", a + 1, [a - 1, a + 3, a + 2], f"{a} < {a+1} < {a+2}.", 1))
    qs.append(tf("كل عدد سالب أصغر من أي عدد موجب.", True, "الأعداد السالبة تقع يسار الصفر والموجبة يمينه.", 1))
    qs.append(mcq(r, "ما بُعد العدد -6 عن الصفر؟", 6, [-6, 0, 12], "البعد دائمًا غير سالب: 6 وحدات.", 2))
    qs.append(tf("الصفر أكبر من -1.", True, "-1 يسار الصفر.", 1))
    return qs[:9], "مثال محلول: رتّبي 3 و-2 و0 و-5: -5 < -2 < 0 < 3."

def g_cmp(r):
    qs = []
    pairs = [(-3, -7), (5, -9), (-2, 0), (-8, -1), (0, -4), (6, 6)]
    for a, b in r.sample(pairs, 4):
        sym = ">" if a > b else "<" if a < b else "="
        qs.append(mcq(r, f"أي رمز يملأ الفراغ: {a} ___ {b}", sym, [s for s in "><=" if s != sym], f"{a} {'أكبر من' if sym=='>' else 'أصغر من' if sym=='<' else 'يساوي'} {b}.", 1))
    for a, b in [(Fraction(1, 2), Fraction(3, 5)), (Fraction(3, 4), Fraction(2, 3)), (Fraction(5, 8), Fraction(5, 6))]:
        sym = ">" if a > b else "<"
        qs.append(mcq(r, f"أي رمز يملأ الفراغ: {fr(a)} ___ {fr(b)}", sym, [s for s in "><=" if s != sym], f"نوحّد المقامين فنجد أن {fr(a)} {'أكبر من' if sym=='>' else 'أصغر من'} {fr(b)}.", 2))
    qs.append(tf("-0.5 = -1/2", True, "نصف = 0.5 فالسالب كذلك.", 2))
    qs.append(tf("-9 > -2", False, "-9 يقع يسار -2 فهو أصغر.", 2))
    return qs[:9], "مثال محلول: قارني -4 و-1: على خط الأعداد -4 يسار -1 فـ -4 < -1."

def g_rational(r):
    qs = []
    for n, d in r.sample([(1, 2), (3, 4), (1, 5), (7, 10), (3, 8), (9, 20)], 3):
        v = Fraction(n, d)
        qs.append(mcq(r, f"اكتبي {n}/{d} على صورة عدد عشري.", num(v), [num(Fraction(n, d) + Fraction(1, 10)), num(Fraction(d, n)), num(Fraction(n, d) / 10)],
                      f"{n} ÷ {d} = {num(v)}.", 1))
    for n, d in r.sample([(1, 4), (3, 5), (1, 2), (7, 20)], 2):
        qs.append(mcq(r, f"اكتبي {n}/{d} كنسبة مئوية.", f"{int(Fraction(n,d)*100)}٪", [f"{int(Fraction(n,d)*100)+10}٪", f"{int(Fraction(n,d)*10)}٪", f"{d}٪"], f"{n}/{d} = {int(Fraction(n,d)*100)}/100.", 2))
    qs.append(tf("العدد -3 عدد نسبي.", True, "يمكن كتابته -3/1.", 1))
    qs.append(tf("العدد 0.25 عدد نسبي.", True, "0.25 = 1/4.", 1))
    qs.append(mcq(r, "أي مما يلي يساوي 3/4؟", "0.75", ["0.34", "7.5", "0.43"], "3 ÷ 4 = 0.75.", 2))
    qs.append(mcq(r, "أي كسر يساوي 0.4؟", "2/5", ["4/5", "1/4", "2/4"], "0.4 = 4/10 = 2/5.", 2))
    return qs[:9], "مثال محلول: 3/8 = 3 ÷ 8 = 0.375."

def g_orderrat(r):
    qs = []
    sets = [[Fraction(1, 2), Fraction(3, 10), Fraction(7, 10), Fraction(1, 4)],
            [Fraction(-1, 2), Fraction(-3, 4), Fraction(1, 5), Fraction(0)],
            [Fraction(3, 5), Fraction(1, 2), Fraction(4, 5), Fraction(7, 10)],
            [Fraction(-9, 10), Fraction(-1, 10), Fraction(-1, 2), Fraction(-3, 10)]]
    for s in r.sample(sets, 3):
        qs.append(order("رتّبي من الأصغر إلى الأكبر:", [fr(x) for x in sorted(s)], "نحوّل كل عدد إلى عشري أو نوحد المقامات ثم نرتب.", 2))
    for a, b in [(Fraction(2, 5), Fraction(1, 3)), (Fraction(7, 8), Fraction(5, 6)), (Fraction(-1, 3), Fraction(-1, 4))]:
        big = max(a, b)
        qs.append(mcq(r, f"أي العددين أكبر: {fr(a)} أم {fr(b)}؟", fr(big), [fr(min(a, b))], "نوحّد المقامات ونقارن البسطين (مع الانتباه لإشارة السالب).", 2))
    qs.append(tf("-0.3 > -0.5", True, "-0.3 أقرب إلى الصفر فهو أكبر.", 2))
    qs.append(mcq(r, "أي عدد يقع بين 0.5 و0.7؟", "0.6", ["0.8", "0.45", "0.75"], "0.5 < 0.6 < 0.7.", 1))
    qs.append(tf("3/4 أصغر من 2/3.", False, "3/4 = 0.75 و2/3 ≈ 0.67 فـ 3/4 أكبر.", 3))
    return qs[:9], "مثال محلول: رتّبي 1/2 و0.3 و3/4: 0.3 < 0.5 < 0.75."

def g_abs(r):
    qs = []
    for _ in range(3):
        v = r.choice([-12, -7, -3, 5, 9, -15, 8])
        qs.append(mcq(r, f"ما قيمة |{v}|؟", abs(v), [v if v < 0 else -v, 0, abs(v) + 1], f"القيمة المطلقة هي بُعد العدد عن الصفر: {abs(v)}.", 1))
    for v in (-6, 4):
        qs.append(mcq(r, f"ما العددان اللذان قيمتهما المطلقة {abs(v)}؟", f"{abs(v)} و-{abs(v)}", [f"{abs(v)} فقط", f"-{abs(v)} فقط", f"0 و{abs(v)}"], f"عددان بنفس البعد عن الصفر: {abs(v)} و-{abs(v)}.", 2))
    qs.append(tf("القيمة المطلقة لأي عدد تكون غير سالبة.", True, "البعد لا يكون سالبًا.", 1))
    qs.append(tf("|-8| = -8", False, "|-8| = 8.", 1))
    a, b = r.choice([(-3, 4), (-8, 2), (5, -6)])
    qs.append(mcq(r, f"ما قيمة |{a}| + |{b}|؟", abs(a) + abs(b), [a + b, abs(a + b), abs(a) - abs(b)], f"{abs(a)} + {abs(b)} = {abs(a)+abs(b)}.", 3))
    qs.append(mcq(r, "ما المسافة بين -4 و3 على خط الأعداد؟", 7, [1, -7, 12], "4 + 3 = 7 وحدات.", 3))
    return qs[:9], "مثال محلول: |-9| = 9 لأن بُعد -9 عن الصفر 9 وحدات."

def g_cmpabs(r):
    qs = []
    for a, b in [(-8, 5), (-3, 7), (-10, -4), (6, -9), (-2, 2), (-7, -9)]:
        A, B = abs(a), abs(b)
        ans = ">" if A > B else "<" if A < B else "="
        qs.append(mcq(r, f"أي رمز يملأ الفراغ: |{a}| ___ |{b}|", ans, [s for s in "><=" if s != ans], f"|{a}| = {A} و|{b}| = {B}.", 1 if len(qs) < 2 else 2))
    qs.append(tf("إذا كان -9 < 4 فإن |-9| < |4|.", False, "|-9| = 9 أكبر من |4| = 4 رغم أن -9 < 4.", 3))
    qs.append(mcq(r, "أي عدد قيمته المطلقة الأكبر؟", "-15", ["10", "-12", "9"], "|-15| = 15 هو الأكبر.", 2))
    qs.append(order("رتّبي حسب القيمة المطلقة من الأصغر:", ["-1", "2", "-4", "7"], "القيم المطلقة 1 ثم 2 ثم 4 ثم 7.", 2))
    return qs[:9], "مثال محلول: قارني |-5| و|3|: 5 > 3 إذن |-5| > |3|."

def g_form(r):
    qs = []
    items = [("مجموع عدد وخمسة", "ن + 5", ["ن × 5", "5 - ن", "ن ÷ 5"]),
             ("ضعف عدد", "2 × ن", ["ن + 2", "ن ÷ 2", "2 - ن"]),
             ("ثلاثة أمثال عدد مطروحًا منها 4", "3ن - 4", ["3 - 4ن", "ن - 12", "3ن + 4"]),
             ("نصف عدد", "ن ÷ 2", ["2ن", "ن - 2", "ن + 2"]),
             ("عدد مطروحًا منه 7", "ن - 7", ["7 - ن", "ن + 7", "7ن"]),
             ("حاصل ضرب عدد في 6 ثم إضافة 1", "6ن + 1", ["6 + ن", "7ن", "6ن - 1"])]
    for t, a, w in r.sample(items, 5):
        qs.append(mcq(r, f"أي تعبير يمثل «{t}»؟", a, w, f"نترجم الكلمات إلى رموز: {a}.", 1 if len(qs) < 3 else 2))
    qs.append(mcq(r, "عمر سارة ع سنة. ما عمرها بعد 8 سنوات؟", "ع + 8", ["ع - 8", "8ع", "ع ÷ 8"], "بعد 8 سنوات نضيف 8.", 1))
    qs.append(mcq(r, "ثمن القلم س جنيهات. ما ثمن 5 أقلام؟", "5س", ["س + 5", "س - 5", "س ÷ 5"], "الضرب لتكرار الثمن.", 1))
    qs.append(tf("«أقل من عدد بـ 3» تعني ن - 3.", True, "أقل من ن بمقدار 3 فنطرح 3 من ن.", 3))
    qs.append(mcq(r, "أي تعبير يمثل «ضعف مجموع عدد و3»؟", "2(ن + 3)", ["2ن + 3", "2 + ن + 3", "(ن + 3) ÷ 2"], "المجموع بين قوسين أولًا ثم نضاعفه.", 3))
    return qs[:9], "مثال محلول: «ثلاثة أمثال عدد زائد 2» تُكتب 3ن + 2."

def g_analyze(r):
    qs = []
    for a, b in [(3, 5), (4, 9), (7, 2)]:
        qs.append(mcq(r, f"في التعبير {a}س + {b} ما معامل س؟", a, [b, 1, a + b], f"المعامل هو العدد المضروب في المتغير: {a}.", 1))
    for a, b in [(5, 8), (2, 6)]:
        qs.append(mcq(r, f"في التعبير {a}ص + {b} ما الحد الثابت؟", b, [a, 0, a + b], f"الحد الثابت لا يتغير: {b}.", 1))
    qs.append(mcq(r, "كم حدًّا في التعبير 4س + 3ص - 7؟", 3, [2, 4, 7], "الحدود: 4س، 3ص، -7.", 2))
    qs.append(tf("في التعبير 9 + 2م الحد 2م يحتوي على متغير.", True, "2م حاصل ضرب 2 في المتغير م.", 1))
    qs.append(mcq(r, "أي عبارة تحتوي على متغيرين؟", "5أ + 2ب", ["7 + 3", "4ن", "10 - 2"], "فيها أ وب.", 2))
    qs.append(tf("الحدان 3س و5س متشابهان.", True, "لهما نفس المتغير بنفس القوة.", 3))
    return qs[:9], "مثال محلول: في 6س - 4: المعامل 6، والحد الثابت -4، وعدد الحدود 2."

def g_alg(r):
    qs = []
    for t, a, w in [("مجموع ضعف س و7", "2س + 7", ["2(س + 7)", "س + 14", "2س - 7"]),
                    ("الفرق بين 10 و3 أمثال ص", "10 - 3ص", ["3ص - 10", "10 + 3ص", "(10 - 3)ص"]),
                    ("ربع عدد ن", "ن ÷ 4", ["4ن", "ن - 4", "ن + 4"]),
                    ("زيادة 9 على ثلاثة أمثال م", "3م + 9", ["3(م + 9)", "9م + 3", "3م - 9"])]:
        qs.append(mcq(r, f"اكتبي المقدار الجبري: {t}", a, w, f"نترجم الجملة بالترتيب: {a}.", 1 if len(qs) < 2 else 2))
    for k, c in [(4, 6), (5, 3)]:
        qs.append(mcq(r, f"تشتري ليلى {k} كراسات بسعر ك لكل واحد وتدفع {c} جنيهات رسوم توصيل. ما المقدار الذي يمثل المبلغ؟", f"{k}ك + {c}", [f"{c}ك + {k}", f"{k + c}ك", f"{k}ك - {c}"], "ثمن الكراسات + رسوم التوصيل.", 2))
    qs.append(tf("المقدار 5 + س يساوي س + 5.", True, "الجمع إبدالي.", 1))
    qs.append(tf("المقدار س - 5 يساوي 5 - س.", False, "الطرح ليس إبداليًا.", 2))
    qs.append(mcq(r, "أي مقدار يمثل «محيط مربع طول ضلعه ل»؟", "4ل", ["ل²", "ل + 4", "2ل"], "المحيط = 4 × طول الضلع.", 2))
    return qs[:9], "مثال محلول: «أكبر من عدد بـ 5» تُكتب ن + 5."

def g_ops(r):
    qs = []
    for a, b, c in [(2, 3, 4), (5, 2, 3), (6, 4, 2)]:
        qs.append(mcq(r, f"ما ناتج {a} + {b} × {c}؟", a + b * c, [(a + b) * c, a + b + c, a * b + c], f"الضرب أولًا: {b*c} ثم الجمع: {a + b*c}.", 1))
    for a, b in [(3, 2), (4, 2), (5, 2)]:
        qs.append(mcq(r, f"ما قيمة {a}^{b}؟", a ** b, [a * b, a + b, a ** b + a], f"{a}^{b} = {' × '.join([str(a)]*b)} = {a**b}.", 2))
    qs.append(mcq(r, "ما ناتج 18 ÷ (3 + 3) × 2؟", 6, [3, 12, 9], "الأقواس: 6، ثم 18 ÷ 6 = 3، ثم × 2 = 6.", 3))
    qs.append(mcq(r, "ما ناتج 2 + 3² × 2؟", 20, [50, 13, 25], "الأس: 9، ثم الضرب 18، ثم الجمع 20.", 3))
    qs.append(order("رتّبي أولويات العمليات:", ["الأقواس", "الأسس", "الضرب والقسمة", "الجمع والطرح"], "ننفذ ما بين الأقواس ثم الأسس ثم الضرب والقسمة ثم الجمع والطرح.", 2))
    return qs[:9], "مثال محلول: 5 + 2 × 3² = 5 + 2 × 9 = 5 + 18 = 23."

def g_eval(r):
    qs = []
    for a, b, x in [(3, 2, 4), (5, 1, 3), (2, 7, 5), (4, 3, 6)]:
        qs.append(mcq(r, f"احسبي قيمة {a}س + {b} عندما س = {x}.", a * x + b, [a + x + b, (a + b) * x, a * x - b], f"{a} × {x} + {b} = {a*x+b}.", 1 if len(qs) < 2 else 2))
    for x in (3, 5):
        qs.append(mcq(r, f"ما قيمة س² + 1 عندما س = {x}؟", x * x + 1, [2 * x + 1, x + 1, x * x], f"{x}² + 1 = {x*x+1}.", 2))
    qs.append(mcq(r, "قيمة 10 - 2ن عندما ن = 3 هي", 4, [8, 24, 16], "10 - 6 = 4.", 2))
    qs.append(mcq(r, "قيمة (م + 2) × 3 عندما م = 4 هي", 18, [10, 14, 12], "(4 + 2) × 3 = 18.", 3))
    qs.append(tf("قيمة 2س عندما س = 0 تساوي 0.", True, "2 × 0 = 0.", 1))
    return qs[:9], "مثال محلول: قيمة 4س - 1 عندما س = 5 هي 4 × 5 - 1 = 19."

def g_apps(r):
    qs = []
    for a, b, n in [(5, 10, 4), (8, 5, 3), (12, 6, 5)]:
        qs.append(mcq(r, f"تدفع سلمى {b} جنيهات اشتراكًا و{a} جنيهات عن كل كتاب. كم تدفع عند شراء {n} كتب؟", a * n + b, [(a + b) * n, a * n, a + b + n], f"{a} × {n} + {b} = {a*n+b}.", 2))
    for v, t in [(60, 3), (45, 4)]:
        qs.append(mcq(r, f"تقطع سيارة {v} كم كل ساعة. ما المسافة بعد {t} ساعات؟", v * t, [v + t, v * t + v, v - t], f"{v} × {t} = {v*t} كم.", 1))
    qs.append(mcq(r, "تكلفة حفلة 30 جنيهًا للحجز و15 جنيهًا للفرد. ما المقدار الذي يعبر عن تكلفة ن أفراد؟", "15ن + 30", ["30ن + 15", "45ن", "15 + 30ن"], "تكلفة ثابتة + تكلفة الفرد × العدد.", 2))
    qs.append(tf("إذا زاد عدد الأفراد زادت التكلفة في المسألة السابقة.", True, "المعامل 15 موجب فالتكلفة تزداد مع ن.", 2))
    qs.append(mcq(r, "مقدار يمثل الباقي من 100 جنيه بعد شراء ق قطع ثمن الواحدة 8 جنيهات:", "100 - 8ق", ["8 - 100ق", "100 + 8ق", "(100 - 8)ق"], "المبلغ - ثمن القطع.", 3))
    qs.append(mcq(r, "إذا كان ن = 6 فما قيمة 7ن - 2 في مسألة تكلفة؟", 40, [42, 5, 48], "7 × 6 - 2 = 40.", 3))
    return qs[:9], "مثال محلول: 5 جنيهات لكل كتاب + 3 رسوم، لشراء 4 كتب: 5 × 4 + 3 = 23 جنيهًا."

def g_equiv(r):
    qs = []
    for a, b in [(3, 4), (2, 5), (5, 2)]:
        qs.append(mcq(r, f"أي مقدار يكافئ {a}(س + {b})؟", f"{a}س + {a*b}", [f"{a}س + {b}", f"{a + b}س", f"{a}س + {a + b}"], f"نوزّع {a} على الحدين: {a}س + {a*b}.", 1 if len(qs) < 1 else 2))
    qs.append(tf("المقداران 2س + 3س و5س متكافئان.", True, "نجمع الحدود المتشابهة: 2س + 3س = 5س.", 1))
    qs.append(tf("المقداران س + 4 و4س متكافئان.", False, "عند س = 2: 6 و8، مختلفان.", 2))
    qs.append(mcq(r, "أي مقدار يكافئ 4س + 8؟", "4(س + 2)", ["4(س + 8)", "12س", "س(4 + 8)"], "نخرج العامل المشترك 4.", 2))
    qs.append(mcq(r, "أي مقدار يكافئ 6ص - 9؟", "3(2ص - 3)", ["3(2ص - 9)", "6(ص - 9)", "3(2ص + 3)"], "العامل المشترك 3.", 3))
    qs.append(mcq(r, "أي عدد س يثبت أن س + س ≠ س × س؟", 3, [2, 0, 4], "عند 3: 6 و9 مختلفان (عند 2 يتساويان).", 3))
    qs.append(tf("المقداران ن + ن + ن و3ن متكافئان.", True, "الجمع المتكرر ضرب.", 1))
    return qs[:9], "مثال محلول: 5(س + 2) = 5س + 10 (خاصية التوزيع)."

def g_eq(r):
    qs = []
    for a, b in [(4, 9), (7, 15), (12, 20)]:
        x = b - a
        qs.append(mcq(r, f"حلّي: س + {a} = {b}", x, [b + a, x + 1, x - 1], f"نطرح {a} من الطرفين: س = {x}.", 1))
    for a, x in [(3, 6), (5, 4), (7, 3)]:
        qs.append(mcq(r, f"حلّي: {a}س = {a*x}", x, [a * x, a, x + 1], f"نقسم الطرفين على {a}: س = {x}.", 1 if len(qs) < 4 else 2))
    for a, b, x in [(2, 3, 5), (3, 4, 4)]:
        qs.append(mcq(r, f"حلّي: {a}س + {b} = {a*x+b}", x, [a * x + b, x + 1, x - 1], f"نطرح {b} ثم نقسم على {a}: س = {x}.", 3))
    qs.append(tf("س = 5 حل للمعادلة س + 3 = 8.", True, "5 + 3 = 8.", 1))
    return qs[:9], "مثال محلول: س - 7 = 10 ← س = 10 + 7 = 17."

def g_ineq1(r):
    qs = []
    for ineq, v, ok in [("س > 3", 5, True), ("س < 2", 4, False), ("س ≥ 6", 6, True), ("س ≤ 1", 2, False), ("س + 2 > 7", 6, True), ("2س < 8", 5, False)]:
        qs.append(tf(f"العدد {v} حل للمتباينة {ineq}.", ok, f"نعوّض س = {v} فنجد أن المتباينة {'صحيحة' if ok else 'غير صحيحة'}.", 1 if len(qs) < 3 else 2))
    qs.append(mcq(r, "أي عدد حل للمتباينة س < 4؟", 1, [4, 6, 9], "1 < 4 فقط.", 1))
    qs.append(mcq(r, "أي رمز يعني «أكبر من أو يساوي»؟", "≥", ["≤", ">", "<"], "الخط تحت الرمز يعني «أو يساوي».", 1))
    qs.append(tf("المتباينة قد يكون لها أكثر من حل واحد.", True, "مثل س > 3 لها حلول كثيرة.", 2))
    return qs[:9], "مثال محلول: هل 4 حل للمتباينة س + 1 > 4؟ 4 + 1 = 5 > 4 نعم."

def g_ineq2(r):
    qs = []
    for a, b in [(3, 7), (5, 12), (2, 9)]:
        qs.append(mcq(r, f"حلّي المتباينة: س + {a} > {b}", f"س > {b - a}", [f"س < {b - a}", f"س > {b + a}", f"س ≥ {b - a}"], f"نطرح {a} من الطرفين: س > {b - a}.", 1))
    for a, c in [(2, 10), (3, 12)]:
        qs.append(mcq(r, f"حلّي المتباينة: {a}س < {c}", f"س < {c // a}", [f"س > {c // a}", f"س < {c * a}", f"س ≤ {c // a}"], f"نقسم على {a}: س < {c // a}.", 2))
    qs.append(mcq(r, "أي عدد صحيح موجب هو أصغر حل لـ س > 3؟", 4, [3, 2, 5], "الأعداد الأكبر من 3: أصغرها صحيحًا 4.", 2))
    qs.append(tf("حل المتباينة س - 2 ≥ 5 هو س ≥ 7.", True, "نضيف 2 للطرفين.", 2))
    qs.append(mcq(r, "أي مما يلي يمثل س ≤ 3 على خط الأعداد؟", "دائرة مغلقة عند 3 وسهم لليسار", ["دائرة مفتوحة عند 3 وسهم لليمين", "دائرة مفتوحة عند 3 وسهم لليسار", "دائرة مغلقة عند 3 وسهم لليمين"], "المغلقة تعني «يساوي» واليسار يعني «أصغر».", 3))
    qs.append(tf("إذا ضربنا طرفي متباينة في عدد موجب فلا يتغير اتجاهها.", True, "الاتجاه يتغير فقط عند الضرب في عدد سالب.", 3))
    return qs[:9], "مثال محلول: س + 5 > 9 ← س > 4."

SCEN = [("المسافة التي تقطعها سيارة", "الزمن", "المسافة"), ("ثمن البرتقال", "عدد الكيلوجرامات", "الثمن"),
        ("المبلغ المدخر", "عدد الأسابيع", "المبلغ"), ("درجة الحرارة داخل الفرن", "الزمن", "درجة الحرارة"),
        ("ارتفاع النبتة", "عدد الأيام", "الارتفاع"), ("فاتورة الهاتف", "عدد الدقائق", "قيمة الفاتورة")]

def g_var1(r):
    qs = []
    for t, ind, dep in r.sample(SCEN, 4):
        qs.append(mcq(r, f"في «{t}» أي متغير هو المستقل؟", ind, [dep, "كلاهما", "لا شيء"], f"المستقل هو الذي نغيّره ({ind}) فتتغير {dep} تبعًا له.", 1))
    for t, ind, dep in r.sample(SCEN, 2):
        qs.append(mcq(r, f"في «{t}» أي متغير هو التابع؟", dep, [ind, "كلاهما", "لا شيء"], f"التابع ({dep}) تتوقف قيمته على {ind}.", 1))
    qs.append(tf("المتغير التابع تتغير قيمته بتغير المتغير المستقل.", True, "هذا هو معنى التبعية.", 1))
    qs.append(mcq(r, "كلما زاد عدد الكتب زاد الثمن. ما المتغير المستقل؟", "عدد الكتب", ["الثمن", "اللون", "المكتبة"], "عدد الكتب هو ما نختاره.", 2))
    qs.append(tf("في العلاقة بين الزمن والمسافة، الزمن هو التابع.", False, "المسافة تعتمد على الزمن فهي التابع.", 2))
    return qs[:9], "مثال محلول: كلما زاد عدد الساعات زاد الأجر؛ الساعات مستقلة والأجر تابع."

def g_var2(r):
    qs = []
    for a, b in [(3, 2), (5, 0), (4, 1)]:
        for x in r.sample([1, 2, 3, 4, 5], 1 if len(qs) < 3 else 2):
            qs.append(mcq(r, f"في القاعدة ص = {a}س + {b} ما قيمة ص عندما س = {x}؟", a * x + b, [a + x + b, (a + b) * x, a * x - b - 1], f"{a} × {x} + {b} = {a*x+b}.", 1))
    qs = qs[:6]
    qs.append(mcq(r, "يربح محل 7 جنيهات عن كل قطعة. ما الربح عند بيع 6 قطع؟", 42, [13, 36, 49], "7 × 6 = 42.", 1))
    qs.append(mcq(r, "جدول: س = 1، 2، 3 وص = 4، 8، 12. ما قيمة ص عندما س = 5؟", 20, [16, 24, 9], "القاعدة ص = 4س فـ 4 × 5 = 20.", 2))
    qs.append(tf("إذا كانت ص = 2س فإن ص تتضاعف عندما تتضاعف س.", True, "العلاقة طردية.", 3))
    return qs[:9], "مثال محلول: ص = 2س + 1: عندما س = 3 فإن ص = 7."

def g_var3(r):
    qs = []
    for k in (2, 3, 4, 5):
        xs = [1, 2, 3, 4]
        qs.append(mcq(r, f"جدول: س = 1،2،3،4 وص = {'،'.join(str(k*x) for x in xs)}. ما القاعدة؟", f"ص = {k}س", [f"ص = س + {k}", f"ص = {k + 1}س", f"ص = {k}"], f"كل قيمة لـ ص = {k} × س.", 1 if k < 4 else 2))
    for k, c in [(2, 1), (3, 2)]:
        xs = [0, 1, 2, 3]
        qs.append(mcq(r, f"جدول: س = 0،1،2،3 وص = {'،'.join(str(k*x + c) for x in xs)}. ما القاعدة؟", f"ص = {k}س + {c}", [f"ص = {k}س", f"ص = {k + c}س", f"ص = س + {c}"], f"عند س = 0 نجد ص = {c} والفرق {k}.", 2))
    qs.append(tf("إذا زادت س بمقدار 1 زادت ص بمقدار 3 في ص = 3س + 2.", True, "المعامل 3.", 2))
    qs.append(mcq(r, "إذا كانت ص = 5س فما قيمة س عندما ص = 35؟", 7, [30, 40, 175], "35 ÷ 5 = 7.", 3))
    qs.append(tf("العلاقة ص = 4 ثابتة لا تتأثر بـ س.", True, "ص لا تتغير.", 3))
    return qs[:9], "مثال محلول: س = 1،2،3 وص = 3،6،9 ← ص = 3س."

def g_var4(r):
    qs = []
    for a, x in [(2, 3), (3, 2), (1, 5)]:
        qs.append(mcq(r, f"أي نقطة تقع على التمثيل البياني للعلاقة ص = {a}س؟", f"({x}, {a*x})", [f"({x}, {a*x+1})", f"({a*x}, {x})", f"({x + 1}, {a*x})"], f"نعوّض: ص = {a} × {x} = {a*x}.", 1))
    qs.append(mcq(r, "في الزوج المرتب (4, 9) أي عدد هو الإحداثي الأفقي (س)؟", 4, [9, 13, 5], "الأول س.", 1))
    qs.append(mcq(r, "عند تمثيل الزمن (مستقل) والمسافة (تابع) أي محور نضع عليه الزمن؟", "الأفقي", ["الرأسي", "لا فرق", "كلاهما"], "المستقل على المحور الأفقي.", 2))
    qs.append(tf("المستقيم الصاعد يعني أن ص تزيد بزيادة س.", True, "ميل موجب.", 2))
    qs.append(tf("النقطة (0, 0) تقع على ص = 3س.", True, "3 × 0 = 0.", 2))
    qs.append(mcq(r, "جدول: (1,5) (2,10) (3,15). ما قيمة ص عند س = 6؟", 30, [20, 25, 11], "ص = 5س.", 3))
    qs.append(tf("النقطة (2, 7) تقع على ص = 3س.", False, "3 × 2 = 6 وليس 7.", 3))
    return qs[:9], "مثال محلول: من ص = 2س نحصل على النقاط (1,2) (2,4) (3,6) ونصل بينها."

def g_stat1(r):
    qs = []
    bank = [("كم عدد الإخوة لدى طلاب صفك؟", True, "الإجابات تختلف من طالب لآخر."),
            ("كم عمرك؟", False, "إجابة واحدة ثابتة، فليس سؤالًا إحصائيًا."),
            ("ما أطوال لاعبي فريق كرة السلة في مدرستك؟", True, "الأطوال متباينة."),
            ("كم عدد أيام الأسبوع؟", False, "إجابة ثابتة."),
            ("كم دقيقة يذاكر طلاب مدرستك يوميًا؟", True, "تتغير من طالب لآخر."),
            ("ما اسم مدرستك؟", False, "إجابة واحدة.")]
    for t, ok, e in bank:
        qs.append(tf(f"«{t}» سؤال إحصائي.", ok, e, 1))
    qs.append(mcq(r, "ما الذي يميز السؤال الإحصائي؟", "تتوقع له إجابات مختلفة", ["له إجابة واحدة فقط", "لا يمكن جمع بيانات له", "يتعلق بشخص واحد"], "السؤال الإحصائي يتوقع تباين البيانات.", 2))
    qs.append(mcq(r, "أي البيانات عددية (كمية)؟", "أطوال الطلاب", ["ألوان العيون", "أسماء المدن", "أنواع الفاكهة المفضلة"], "الأطوال أعداد.", 2))
    qs.append(tf("جمع البيانات يسبق تمثيلها بيانيًا.", True, "نجمع ثم ننظم ثم نمثل.", 1))
    return qs[:9], "مثال محلول: «كم كتابًا قرأ طلاب الفصل هذا الشهر؟» سؤال إحصائي لأن الإجابات تختلف."

def g_hist(r):
    qs = []
    for ivs in [[("0-9", 3), ("10-19", 7), ("20-29", 5)], [("1-5", 4), ("6-10", 9), ("11-15", 2)], [("0-4", 6), ("5-9", 2), ("10-14", 8)]]:
        top = max(ivs, key=lambda x: x[1])
        tbl = "، ".join(f"{a}: {b}" for a, b in ivs)
        qs.append(mcq(r, f"جدول تكراري ({tbl}). أي فئة تكرارها أكبر؟", top[0], [a for a, b in ivs if a != top[0]] + ["لا يمكن معرفة ذلك"], f"أعلى عمود هو {top[0]} بتكرار {top[1]}.", 1))
        qs.append(mcq(r, f"في الجدول نفسه ({tbl}) ما مجموع عدد القيم؟", sum(b for a, b in ivs), [sum(b for a, b in ivs) + 2, max(b for a, b in ivs), len(ivs)], f"نجمع التكرارات: {sum(b for a,b in ivs)}.", 2))
    qs.append(tf("في المدرج التكراري تتلامس الأعمدة لأن الفئات متصلة.", True, "الفئات متصلة بلا فراغات.", 2))
    qs.append(tf("ارتفاع العمود في المدرج يمثل تكرار الفئة.", True, "التكرار = عدد القيم في الفئة.", 1))
    qs.append(mcq(r, "عمودان ارتفاعهما 5 و8، ما الفرق بين تكراريهما؟", 3, [13, 5, 8], "8 - 5 = 3.", 2))
    return qs[:9], "مثال محلول: التكرارات 3 و7 و5 معناها أن عدد القيم الكلي 15."

def g_hist2(r):
    qs = []
    for _ in range(3):
        d = sorted(r.sample(range(1, 30), 10))
        lo, hi = r.choice([(1, 10), (11, 20), (21, 30)])
        c = sum(lo <= v <= hi for v in d)
        qs.append(mcq(r, f"البيانات: {'، '.join(map(str, d))}. كم قيمة في الفئة {lo}-{hi}؟", c, [c + 1, c + 2, max(0, c - 1)], f"نعد القيم من {lo} إلى {hi}: {c}.", 1 if _ < 2 else 2))
    qs.append(mcq(r, "لتمثيل أعمار 30 طفلًا بمدرج تكراري ما أول خطوة؟", "تحديد الفئات", ["رسم الأعمدة مباشرة", "ترتيب الأسماء", "حساب المتوسط"], "نحدد فئات متساوية العرض أولًا.", 2))
    qs.append(tf("يجب أن تكون عروض الفئات متساوية في المدرج.", True, "لتكون المقارنة عادلة.", 2))
    qs.append(mcq(r, "كم عدد القيم إذا كانت التكرارات 4 و6 و10؟", 20, [10, 4, 24], "4 + 6 + 10 = 20.", 1))
    qs.append(tf("المدرج التكراري يناسب بيانات عددية مستمرة مثل الأطوال.", True, "نعم.", 2))
    qs.append(order("رتّبي خطوات رسم مدرج تكراري:", ["نجمع البيانات", "نحدد الفئات", "نحسب تكرار كل فئة", "نرسم الأعمدة"], "جمع ثم فئات ثم تكرارات ثم رسم.", 2))
    return qs[:9], "مثال محلول: القيم 2،5،7،11،12 بفئات 1-5 و6-10 و11-15 تكراراتها 2 و1 و2."

def quart(a):
    a = sorted(a); n = len(a)
    low = a[: n // 2]; up = a[(n + 1) // 2:]
    return a[0], median(low), median(a), median(up), a[-1]

def g_box(r):
    qs = []
    for _ in range(3):
        d = sorted(r.sample(range(2, 40), 9))
        mn, q1, md, q3, mx = quart(d)
        s = "، ".join(map(str, d))
        qs.append(mcq(r, f"البيانات: {s}. ما الوسيط؟", num(md), [num(Fraction(d[3])), num(Fraction(d[5])), num(Fraction(sum(d), len(d)))], f"القيمة الوسطى بعد الترتيب هي {num(md)}.", 1 if _ < 1 else 2))
        qs.append(mcq(r, f"في البيانات نفسها ({s}) ما الربيع الأدنى Q1؟", num(q1), [num(md), num(mn), num(q3)], f"وسيط النصف الأدنى (دون احتساب الوسيط) = {num(q1)}.", 2))
    d = sorted(r.sample(range(2, 40), 9)); mn, q1, md, q3, mx = quart(d)
    qs.append(mcq(r, f"في مخطط صندوقي: Q1 = {num(q1)} و Q3 = {num(q3)}. ما المدى الربيعي؟", num(q3 - q1), [num(q3 + q1), num(mx - mn), num(q3)], "المدى الربيعي = Q3 - Q1.", 3))
    qs.append(tf("الصندوق في المخطط يحتوي نحو نصف البيانات.", True, "بين Q1 وQ3 يقع 50٪ من القيم.", 2))
    qs.append(order("رتّبي مكونات الملخص الخماسي:", ["أصغر قيمة", "الربيع الأدنى", "الوسيط", "الربيع الأعلى", "أكبر قيمة"], "من الأصغر إلى الأكبر.", 2))
    return qs[:9], "مثال محلول: 3،5،6،8،9،12،14: الوسيط 8، Q1 = 5، Q3 = 12."

def g_stat5(r):
    qs = []
    for tot, part in [(20, 5), (40, 10), (50, 25)]:
        qs.append(mcq(r, f"في فصل {tot} طالبًا، منهم {part} يحبون الرياضيات. ما النسبة المئوية؟", f"{part*100//tot}٪", [f"{part}٪", f"{tot - part}٪", f"{part*100//tot + 10}٪"], f"{part}/{tot} = {part*100//tot}٪.", 2))
    qs.append(mcq(r, "أي تمثيل يناسب مقارنة تكرارات فئات متصلة؟", "المدرج التكراري", ["الجدول فقط", "القصة", "الصورة"], "يظهر شكل التوزيع.", 1))
    qs.append(mcq(r, "أي تمثيل يوضح الوسيط والربيعين مباشرة؟", "المخطط الصندوقي", ["المدرج التكراري", "جدول الأسماء", "الخريطة"], "يعرض الملخص الخماسي.", 2))
    qs.append(tf("نجمع البيانات ثم نختار التمثيل المناسب.", True, "ترتيب منطقي.", 1))
    qs.append(tf("يمكن لتمثيلين مختلفين أن يعرضا نفس البيانات.", True, "لكل تمثيل نقاط قوة.", 1))
    qs.append(mcq(r, "عمود أعلى في المدرج يعني", "تكرارًا أكبر", ["قيمة أكبر دائمًا", "أخطاء", "لا شيء"], "العمود الأعلى فئة أكثر ظهورًا.", 2))
    qs.append(mcq(r, "ما سبب اختلاف شكلي مدرجين لنفس البيانات؟", "اختلاف عرض الفئات", ["اختلاف الألوان", "اختلاف الورق", "لا يختلفان"], "الفئات تغيّر الشكل.", 3))
    return qs[:9], "مثال محلول: 12 طالبًا من 48 يحبون الرسم = 25٪."

def g_balance(r):
    qs = []
    for _ in range(3):
        n = r.choice([4, 5]); m = r.randint(4, 12)
        d = [m + r.randint(-3, 3) for _ in range(n - 1)]
        d.append(m * n - sum(d))
        qs.append(mcq(r, f"ما متوسط الأعداد {'، '.join(map(str,d))}؟", m, [m + 1, m - 1, max(d)], f"المجموع {sum(d)} ÷ {n} = {m}.", 1 if _ < 2 else 2))
    qs.append(mcq(r, "الوسط الحسابي لـ 6 و8 و10 هو", 8, [6, 10, 24], "24 ÷ 3 = 8.", 1))
    qs.append(tf("الوسط الحسابي هو نقطة التوازن لمجموعة البيانات.", True, "مجموع الانحرافات عنه = صفر.", 2))
    qs.append(mcq(r, "إذا كان وسط 3 أعداد 5 وعددان 4 و6 فالعدد الثالث", 5, [4, 6, 15], "المجموع 15 - 10 = 5.", 3))
    qs.append(tf("إضافة قيمة تساوي الوسط لا تغيّر الوسط.", True, "المجموع والعدد يزيدان بالنسبة نفسها.", 3))
    qs.append(tf("الوسط الحسابي لا يتغير بتغيير كل القيم.", False, "يتغير بتغير القيم.", 2))
    return qs[:9], "مثال محلول: متوسط 2 و4 و9 = 15 ÷ 3 = 5."

def g_mean(r):
    qs = []
    for _ in range(4):
        n = r.choice([3, 4, 5, 6]); m = r.randint(5, 20)
        d = [max(1, m + r.randint(-4, 4)) for _ in range(n - 1)]
        last = m * n - sum(d)
        if last < 1: d = [m] * (n - 1); last = m
        d.append(last)
        qs.append(mcq(r, f"أوجدي الوسط الحسابي: {'، '.join(map(str,d))}", m, [m + 1, m - 1, m + 2], f"({' + '.join(map(str,d))}) ÷ {n} = {m}.", 1 if _ < 2 else 2))
    for _ in range(2):
        n = 4; m = r.randint(6, 15); d = [m + r.randint(-3, 3) for _ in range(3)]; x = m * n - sum(d)
        qs.append(mcq(r, f"وسط 4 أعداد {m}، وثلاثة منها {'، '.join(map(str,d))}. ما العدد الرابع؟", x, [m, x + 1, x - 2], f"المجموع {m*n} - {sum(d)} = {x}.", 3))
    qs.append(tf("الوسط الحسابي قد لا يكون عددًا من قيم البيانات.", True, "مثل 2 و4 وسطهما 3.", 2))
    qs.append(mcq(r, "درجات: 70، 80، 90. إذا زادت كل درجة 5 فالوسط", 85, [80, 90, 75], "الوسط الأصلي 80 + 5.", 3))
    return qs[:9], "مثال محلول: درجات 12 و15 و18 ← (12 + 15 + 18) ÷ 3 = 15."

def g_med(r):
    qs = []
    for _ in range(3):
        d = r.sample(range(3, 40), 7)
        qs.append(mcq(r, f"ما وسيط القيم: {'، '.join(map(str,d))}؟", median(d), [sorted(d)[2], sorted(d)[4], d[3] if d[3] != median(d) else d[0]], "نرتبها فنأخذ القيمة الوسطى.", 1 if _ < 2 else 2))
    for _ in range(2):
        a = r.randint(2, 9); d = [a, a + 1, a, a + 3, a, a + 2]
        qs.append(mcq(r, f"ما المنوال: {'، '.join(map(str,d))}؟", a, [a + 1, a + 2, a + 3], f"{a} هو الأكثر تكرارًا.", 1))
    d = [4, 5, 6, 5, 4, 48]
    qs.append(mcq(r, f"في القيم {'، '.join(map(str,d))} أي قيمة متطرفة؟", 48, [4, 5, 6], "48 بعيدة جدًا عن الباقي.", 2))
    qs.append(tf("القيمة المتطرفة تؤثر في الوسط الحسابي أكثر من الوسيط.", True, "الوسيط أقل تأثرًا.", 3))
    qs.append(mcq(r, "وسيط 2، 4، 6، 8 هو", 5, [4, 6, 20], "(4 + 6) ÷ 2 = 5.", 2))
    return qs[:9], "مثال محلول: 3،9،4،7،5: بعد الترتيب 3،4،5،7،9 الوسيط 5."

def g_range(r):
    qs = []
    for _ in range(4):
        d = r.sample(range(1, 60), 6)
        rg = max(d) - min(d)
        qs.append(mcq(r, f"ما مدى البيانات: {'، '.join(map(str,d))}؟", rg, [max(d), rg + 2, rg - 1 if rg > 1 else 3], f"{max(d)} - {min(d)} = {rg}.", 1 if _ < 2 else 2))
    qs.append(tf("المدى يقيس مدى انتشار البيانات.", True, "الفرق بين الأكبر والأصغر.", 1))
    qs.append(mcq(r, "أي مجموعتين بياناتهما أكثر تقاربًا؟", "مدى 3", ["مدى 10", "مدى 25", "مدى 40"], "المدى الأصغر يعني تقاربًا أكثر.", 2))
    qs.append(mcq(r, "إذا كان المدى 12 وأصغر قيمة 5 فأكبر قيمة", 17, [7, 12, 60], "5 + 12 = 17.", 3))
    qs.append(tf("مدى مجموعة تتساوى قيمها كلها يساوي صفرًا.", True, "الأكبر = الأصغر.", 2))
    qs.append(mcq(r, "مدى 8، 3، 15، 10 هو", 12, [15, 7, 18], "15 - 3 = 12.", 2))
    return qs[:9], "مثال محلول: 14، 6، 20، 9 ← المدى = 20 - 6 = 14."

MATH_GEN = [g_div, g_prime, g_gcf, g_lcm, g_numline, g_cmp, g_rational, g_orderrat, g_abs, g_cmpabs,
            g_form, g_analyze, g_alg, g_ops, g_eval, g_apps, g_equiv, g_eq, g_ineq1, g_ineq2,
            g_var1, g_var2, g_var3, g_var4, g_stat1, g_hist, g_hist2, g_box, g_stat5, g_balance, g_mean, g_med, g_range]
assert len(MATH_GEN) == 33

# ---------------------------------------------------------------- derived practice (all subjects)
def derive(r, lesson, tag):
    base = [q for q in lesson["questions"] if "-x" not in q["id"]]
    out = []
    for q in base:
        if q["type"] == "mcq" and len(q["options"]) >= 3:
            ans = q["options"][q["answer"]]
            wrong = [o for i, o in enumerate(q["options"]) if i != q["answer"]]
            out.append(tf(f"الإجابة الصحيحة عن «{q['text'].strip()}» هي «{ans}».", True, q["explanation"], 2))
            out.append(tf(f"الإجابة الصحيحة عن «{q['text'].strip()}» هي «{r.choice(wrong)}».", False, q["explanation"], 2))
    return out

def summary_card(lesson):
    objs = lesson.get("objectives") or []
    if not objs: return ""
    return "\n\nتذكّري:\n" + "\n".join(f"✔ {o}" for o in objs)

def reset(lesson):
    lesson["questions"] = [q for q in lesson["questions"] if "-x" not in q["id"]]
    for marker in ("\n\nمثال محلول:", "\n\nتذكّري:"):
        if marker in lesson["body"]:
            lesson["body"] = lesson["body"].split(marker)[0]

stats = {}
math_titles = [l["title"] for l in next(s for s in data["subjects"] if s["id"] == "math_ar")["lessons"]]
for s in data["subjects"]:
    rng = random.Random(hash(s["id"]) & 0xFFFF if False else sum(map(ord, s["id"])))
    is_math = s["id"] in ("math_ar", "math_en", "math_fr")
    for idx, l in enumerate(s["lessons"]):
        reset(l)
        n0 = len(l["questions"])
        new = []
        if is_math and idx < 33 and l["title"] == math_titles[idx]:
            qs, ex = MATH_GEN[idx](random.Random(idx * 7919 + 13))
            new += qs
            l["body"] += "\n\n" + ex
        else:
            new += derive(rng, l, s["id"])
        l["body"] += summary_card(l)
        seen = set(q["text"] + "|".join(q["options"]) for q in l["questions"])
        k = 1
        for q in new:
            key = q["text"] + "|".join(q["options"])
            if key in seen: continue
            seen.add(key)
            q["id"] = f"{l['id']}-x{k}"; k += 1
            l["questions"].append(q)
        stats[s["id"]] = stats.get(s["id"], 0) + len(l["questions"]) - n0
        l["version"] = max(l.get("version", 1), 2)

data["contentNote"] = data.get("contentNote", "")
P.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
print("added per subject:", stats)
print("total questions:", sum(len(l["questions"]) for s in data["subjects"] for l in s["lessons"]))
