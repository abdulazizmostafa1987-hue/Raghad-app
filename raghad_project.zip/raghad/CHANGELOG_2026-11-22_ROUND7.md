# Round 7 – Flutter analyzer fixes

- Based strictly on `raghad_upgrade_round6_2026-11-22.zip`.
- Fixed the fatal analyzer error in `screens2.dart`: `Wrap` does not accept `mainAxisSize`.
- Added braces to asynchronous type branches in `progress_store.dart`.
- Marked initialized schedule/CMS state fields final where applicable.
- Added a mounted guard after clipboard retrieval before opening the restore dialog.
- Bumped app version to 0.6.1+7.

The remaining analyzer messages about deprecated Flutter APIs and style are infos, not compile errors. Flutter/Dart SDK was not available in the editing environment, so `flutter analyze`, tests, and APK build were not executed here.
