# رغد – رحلتي نحو التفوق

تطبيق Flutter عربي للصف السادس الابتدائي بهوية بنفسجية/وردية وشخصية رغد.

## التحديث الحالي على آخر نسخة
- إعادة تصميم مكتبة التعلم على هيئة «مدينة المعرفة» ببطاقات ملونة وحركات دخول خفيفة.
- إضافة فتح مباشر لمكتبة وزارة التربية والتعليم، ورابط كتاب الرياضيات الرسمي للفصل الأول 2026/2027، ورابط كتاب مهارات إدارة الأسرة وريادة الأعمال.
- إضافة شروح وأنشطة وأسئلة أصلية لـ33 درسًا مساندًا تغطي عناوين الوحدات السبع في رياضيات الفصل الأول.
- إضافة خريطة وحدات الرياضيات للفصل الأول حسب فهرس كتاب الوزارة.
- إضافة جلسة مذاكرة بمؤقت قابل للضبط، مع تسجيل مدة الجلسات وعددها في تقارير ولي الأمر.
- إضافة أدوات إثرائية تفاعلية: معمل حساب العامل المشترك الأكبر والمضاعف المشترك الأصغر، نموذج تعليمي آمن لدورة الماء، وبطاقات استكشاف القارات، وتدريبات لغوية قصيرة، ولعبة ترتيب أوامر روبوت للتفكير الخوارزمي.
- تسجيل إنهاء لعبة الذاكرة ضمن سجل الإنجاز.
- تحسين سلامة استعادة النسخ الاحتياطية بالتحقق من كامل البيانات قبل تطبيقها، وتوسيع سجل نسخ الدروس ليحفظ الأسئلة والأهداف أيضًا.
- منع نشر درس CMS قبل وجود شرح كافٍ وثلاثة أسئلة على الأقل.
- تحسين مؤثرات الإجابة الصوتية واللمسية، وإصلاح مؤشر حالة القراءة الصوتية عند انتهاء النطق.
- الحفاظ على شاشة البداية والهوية والشخصية والألعاب والتقدم والمراجعة المتباعدة ولوحة ولي الأمر والإعدادات السابقة.
- دعم اختيار Connect / Connect Plus والمنهج الديني من الإعدادات.

## حالة المحتوى – شفافية ضرورية
الفهرس يضم مسارات الكتب المنشورة للفصل الأول للصف السادس، مع عرض Connect Plus كبديل لمسار اللغة الإنجليزية في مدارس اللغات. لا يعني ذلك أن جميعها تحولت إلى دروس تفاعلية داخل التطبيق. المحتوى الدراسي المساند الذي أُضيف في الجولة الثالثة هو 33 درس رياضيات تغطي عناوين الوحدات السبع للفصل الأول. أدوات معمل العلوم ومستكشف الجغرافيا إثرائية عامة وليست تحويلًا كاملًا لمقرر العلوم أو الدراسات. بقية الكتب تُفتح من بوابة الوزارة الرسمية، ويجب استكمال تحويل كل كتاب إلى وحدات ودروس وأنشطة واختبارات بعد مراجعة مصدره الرسمي. لا يوجد ادعاء باكتمال المنهج الدراسي كله.

المصادر:
- مكتبة الكتب الرسمية: https://ellibrary.moe.gov.eg/books/
- كتاب الرياضيات الرسمي، الصف السادس، الفصل الأول 2026/2027: https://elearnningcontent.blob.core.windows.net/elearnningcontent/2026_2027/Primary/Primary6/Term1/StudentBook/Math_Primary6_T1.pdf
- كتاب مهارات إدارة الأسرة وريادة الأعمال، الفصل الأول: https://elearnningcontent.blob.core.windows.net/elearnningcontent/2026_2027/Primary/Primary6/Term1/StudentBook/Family_management_Prim6_TR1.pdf


## تدقيق الأعمال المتبقية

| المجال | الحالة في هذه النسخة |
|---|---|
| الهوية والشاشة الرئيسية والمكتبة والإعدادات | منفذ |
| الألعاب البسيطة: الذاكرة والتوصيل واكتشف الخطأ والبطاقات والحساب الذهني وترتيب الخطوات | منفذ؛ ترتبط الأسئلة بالمحتوى المتاح فقط |
| معمل الرياضيات والعلوم والجغرافيا والتدريب اللغوي والتفكير البرمجي | أدوات إثرائية منفذة؛ ليست بديلًا عن وحدات الكتب الرسمية |
| جلسات المذاكرة والجدول والمراجعة المتباعدة والتقارير | منفذ |
| لوحة ولي الأمر وإدارة الدروس ومسار المراجعة والاعتماد والنشر | منفذ مع شرط اكتمال الدرس قبل النشر |
| النسخ الاحتياطي والاستعادة وتحديث حزم المحتوى | منفذ؛ التحديث يتطلب رابط HTTPS وملف manifest وحزمًا صحيحة |
| تحويل جميع كتب الصف السادس إلى دروس واختبارات تفاعلية | غير مكتمل؛ الموجود 33 درسًا مساندًا في رياضيات الفصل الأول، وبقية المواد لم تُحوّل بعد |
| محتوى الفصل الدراسي الثاني | ينتظر نشر/التحقق من المصادر الرسمية |
| أداة Android Home Screen Widget مستقلة | غير مضافة في هذه النسخة |
| تحليل Dart والاختبارات وبناء APK | غير متحقق لعدم توفر Flutter/Dart SDK في بيئة العمل |

## ملاحظات قبل النشر
- تمت إضافة `url_launcher` لفتح الكتب من خارج التطبيق.
- المصدر المستلم لا يحتوي مجلد Android أو ملفات Gradle أو workflow سابقًا، كما لم يتوفر Flutter/Dart SDK في بيئة التعديل. أُضيف workflow ينشئ مجلد Android على GitHub Actions ثم يشغّل التنسيق والتحليل والاختبارات والبناء. لم تُنفذ هذه الخطوات بعد في هذه البيئة، لذلك لا توجد شهادة نجاح بناء حتى يكتمل تشغيل workflow.
- لا يمكن اعتماد APK نهائي قبل تشغيل Flutter SDK وتنفيذ `flutter pub get`, `dart format lib test`, `flutter analyze`, `flutter test` و`flutter build apk --release`.
- مفتاح Gemini لا ينبغي تضمينه في تطبيق عام؛ استخدم وسيطًا خلفيًا آمنًا مع حدود استخدام وحماية مناسبة للأطفال.
- راجع سياسة الخصوصية وموافقة ولي الأمر قبل نشر التطبيق.

## البناء
```bash
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --release
```

## Round 3 status (2026-11-22)

- Term 1 Mathematics now contains 33 original supplementary lessons mapped to the seven units in the official Grade 6 2026/2027 contents list. These are learning explanations and practice questions, not copied textbook content and not a claim that the official book has been fully reproduced.
- Other subjects remain listed in the library but are not marked as interactive-complete until their exact official 2026/2027 books and tracks have been reviewed and converted.
- Term 2 for 2026/2027 is intentionally marked as awaiting official publication. Older 2025/2026 Term 2 material must not be presented as the current year's curriculum.
- Android home-screen widget support is implemented with `home_widget`; the CI workflow creates the Android host project, installs the native widget resources/provider, then builds the app. The widget displays recent learning progress and opens Raghad when tapped.
- A successful APK build/analyze/test result has not yet been observed in this editing environment because Flutter/Dart SDK is unavailable here. Run the GitHub Actions workflow to validate the generated Android project and plugin integration.


## تحديث المحتوى – جولة 4 (22 نوفمبر 2026)
- إضافة 6 دروس تفاعلية مساندة لمهارات إدارة الأسرة وريادة الأعمال، وفق عناوين كتاب الوزارة للفصل الأول 2026/2027.
- إضافة 10 دروس علوم مساندة مستندة إلى فهرس كتاب Science للصف السادس (مسار اللغات) للفصل الأول 2026/2027، مع شروح عربية أصلية.
- إضافة بيانات أرشيف الفصل الثاني 2025/2026 مع تنبيه واضح بأنه منهج العام السابق وليس منهج 2026/2027.
- لم تُنشأ دروس للفصل الثاني من مصادر لم يتم فحص محتواها؛ وجود رابط PDF وحده لا يكفي لنسب شرح إلى الكتاب.
- التغطية التفاعلية الحالية: 33 رياضيات + 10 علوم مسار لغات + 6 مهارات إدارة الأسرة = 49 درسًا. بقية الكتب ما زالت غير مكتملة تفاعليًا.


## Round 5 content expansion (2026-11-22)
The latest Round 4 project was expanded with interactive supplementary lessons and quizzes for all listed curriculum subjects. The library cards now open in-app lesson lists. The 2025/2026 second-term archive includes Arabic and Christian Religious Education lesson outlines based on official book contents pages. All generated teaching text and questions are original supplementary material, not copied textbook passages. Language-track Math/Science lessons remain Arabic-support content, not official translations. See `CHANGELOG_2026-11-22_ROUND5.md`.
\n\n## Round 6 – curriculum quality gate\n\nRun `python3 tool/audit_curriculum.py` to validate the lesson packages and question integrity. Lesson counts are package counts, not proof of page-by-page textbook coverage. Archived 2025/2026 Term 2 content remains clearly separated from the 2026/2027 curriculum. Flutter build/test must be run in CI before release.\n