import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models.dart';
import '../progress_store.dart';
import '../quiz_engine.dart';
import 'brand.dart';
import 'fx.dart';
import 'lesson_flow.dart';
import 'practice_gen.dart';
import 'practice_runner.dart';
import 'rewards.dart';
import 'sfx.dart';

const bossEmojis = ['👹', '🐉', '🦖', '👾', '🧟', '🦑', '🤖', '🦂'];

/// أسئلة اختيار فقط (اختيار من متعدد/صح-خطأ): مزيج من الرياضيات المتجددة وأسئلة الدروس.
List<Question> choicePool(Random r, int n, {List<Question> content = const [], int level = 1, double mathShare = .6}) {
  bool ok(Question q) => (q.type == 'mcq' || q.type == 'tf') && q.options.length >= 2;
  final math = MathPractice.generate(r, count: n * 3, level: level).where(ok).toList();
  final pool = content.where(ok).toList()..shuffle(r);
  final nm = content.isEmpty ? n : (n * mathShare).round();
  final out = <Question>[...math.take(nm), ...pool.take(n - nm)];
  var i = nm;
  while (out.length < n && i < math.length) {
    out.add(math[i++]);
  }
  out.shuffle(r);
  return out.take(n).toList();
}

/// نافذة اختيار الإجابة المشتركة بين الألعاب.
class ChoiceBlock extends StatelessWidget {
  const ChoiceBlock({super.key, required this.q, required this.onPick, this.picked, this.reveal = false, this.accent = Brand.violet});
  final Question q;
  final void Function(int) onPick;
  final int? picked;
  final bool reveal;
  final Color accent;
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(children: [
      for (var i = 0; i < q.options.length; i++)
        Pressable(
          onTap: reveal ? null : () => onPick(i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            width: double.infinity,
            margin: const EdgeInsets.symmetric(vertical: 5),
            padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: reveal && i == q.answer
                  ? const Color(0xFFD7F5E3)
                  : reveal && i == picked
                      ? const Color(0xFFFFE1D6)
                      : cs.surface,
              border: Border.all(
                  width: 2,
                  color: reveal && i == q.answer
                      ? const Color(0xFF2EAD6B)
                      : reveal && i == picked
                          ? const Color(0xFFE5703F)
                          : accent.withValues(alpha: .25)),
              boxShadow: [BoxShadow(color: accent.withValues(alpha: .15), offset: const Offset(0, 4))],
            ),
            child: Text(q.options[i],
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: reveal && (i == q.answer || i == picked) ? Brand.ink : null)),
          ),
        ),
    ]);
  }
}

class GameOverView extends StatelessWidget {
  const GameOverView({
    super.key,
    required this.win,
    required this.title,
    required this.lines,
    required this.coins,
    required this.onAgain,
    this.gems = 0,
  });
  final bool win;
  final String title;
  final List<String> lines;
  final int coins;
  final int gems;
  final VoidCallback onAgain;
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Stack(children: [
          Container(
            decoration: BoxDecoration(
                gradient: win ? Brand.gradient : const LinearGradient(colors: [Color(0xFF6B6B8D), Color(0xFF3F3A66)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
            child: SafeArea(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    PopIn(child: Text(win ? '🏆' : '💪', style: const TextStyle(fontSize: 96))),
                    Text(title, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    for (final l in lines) Text(l, style: const TextStyle(color: Colors.white, fontSize: 17)),
                    const SizedBox(height: 16),
                    Wrap(spacing: 10, children: [
                      StatPill('🪙', '+$coins'),
                      if (gems > 0) StatPill('💎', '+$gems'),
                    ]),
                    const SizedBox(height: 22),
                    FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Brand.violet),
                        onPressed: onAgain,
                        child: const Text('العبي مرة أخرى')),
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('رجوع', style: TextStyle(color: Colors.white))),
                  ]),
                ),
              ),
            ),
          ),
          if (win) const Positioned.fill(child: ParticleBurst(count: 28, emojis: ['🎉', '⭐', '✨', '🪙'])),
        ]),
      );
}

Future<void> _payout(ProgressStore s, int coins, {int gems = 0, int correct = 0, int? total}) async {
  await s.addCoins(coins);
  if (gems > 0) await s.addGems(gems);
  if (correct > 0) {
    await s.putInt('totalCorrect', s.totalCorrect + correct);
    await s.bumpQuest('correct', correct);
  }
  if ((total ?? correct) > 0) await s.logDay(correct, total ?? correct);
}

// ======================================================================
// معركة الزعيم
// ======================================================================
class BossBattlePage extends StatefulWidget {
  const BossBattlePage({
    super.key,
    required this.store,
    required this.questions,
    required this.bossName,
    this.bossEmoji = '👹',
    this.accent = Brand.violet,
    this.nodeId,
  });
  final ProgressStore store;
  final List<Question> questions;
  final String bossName;
  final String bossEmoji;
  final Color accent;
  final String? nodeId;
  @override
  State<BossBattlePage> createState() => _BossBattlePageState();
}

class _BossBattlePageState extends State<BossBattlePage> {
  late final List<Question> _qs = QuizEngine.prepare(
      widget.questions.where((q) => q.type == 'mcq' || q.type == 'tf').toList().isNotEmpty
          ? widget.questions.where((q) => q.type == 'mcq' || q.type == 'tf').take(10).toList()
          : choicePool(Random(), 10));
  late final int _bossMax = max(3, (_qs.length * .7).ceil());
  int _n = 0, _hearts = 3, _hits = 0, _correct = 0;
  int? _picked;
  bool _revealed = false;
  bool _done = false;
  final List<AnswerRecord> _recs = [];
  LessonReward? _reward;

  int get _bossHp => _bossMax - _correct;

  void _pick(int i) {
    final q = _qs[_n];
    final ok = i == q.answer;
    setState(() {
      _picked = i;
      _revealed = true;
      _recs.add(AnswerRecord(q, ok));
      if (ok) {
        _correct++;
        _hits++;
      } else {
        _hearts--;
      }
    });
    if (ok) {
      Sfx.play('hit');
      Future<void>.delayed(const Duration(milliseconds: 200), () => Sfx.correct());
    } else {
      Sfx.wrong();
    }
  }

  Future<void> _next() async {
    if (_bossHp <= 0 || _hearts <= 0 || _n + 1 >= _qs.length) {
      await _finish();
      return;
    }
    setState(() {
      _n++;
      _picked = null;
      _revealed = false;
    });
  }

  Future<void> _finish() async {
    final s = widget.store;
    final win = _bossHp <= 0;
    final right = {for (final r in _recs) if (r.ok) r.q.id};
    final wrong = {for (final r in _recs) if (!r.ok) r.q.id};
    await s.recordAttempt(lessonId: widget.nodeId ?? 'boss', correct: right.length, total: _recs.length, wrong: wrong, right: right);
    LessonReward? reward;
    if (widget.nodeId != null) {
      // الفوز يعني على الأقل 70٪ من الأسئلة؛ نحسب النسبة على كامل الأسئلة.
      reward = await s.rewardNode(nodeId: widget.nodeId!, correct: win ? max(right.length, (_qs.length * .7).ceil()) : right.length, total: _qs.length, boss: true);
    } else {
      await _payout(s, win ? 30 : 8, gems: win ? 1 : 0, correct: right.length, total: _recs.length);
    }
    Sfx.play(win ? 'win' : 'lose');
    if (!mounted) return;
    setState(() {
      _done = true;
      _reward = reward;
    });
  }

  @override
  Widget build(BuildContext context) {
    final win = _bossHp <= 0;
    if (_done) {
      if (_reward != null) {
        return NodeResultView(
          reward: _reward!,
          correct: win ? max(_correct, (_qs.length * .7).ceil()) : _correct,
          total: _qs.length,
          store: widget.store,
          accent: widget.accent,
          onClose: () => Navigator.pop(context),
        );
      }
      return GameOverView(
        win: win,
        title: win ? 'هزمتِ ${widget.bossName}!' : 'الزعيم ما زال واقفًا',
        lines: ['إجابات صحيحة: $_correct من ${_recs.length}'],
        coins: win ? 30 : 8,
        gems: win ? 1 : 0,
        onAgain: () => Navigator.pushReplacement(
            context,
            MaterialPageRoute<void>(
                builder: (_) => BossBattlePage(store: widget.store, questions: widget.questions, bossName: widget.bossName, bossEmoji: widget.bossEmoji, accent: widget.accent))),
      );
    }
    final q = _qs[_n];
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Container(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [widget.accent.withValues(alpha: .85), widget.accent.withValues(alpha: .45)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(32)),
            ),
            child: Column(children: [
              Row(children: [
                IconButton(onPressed: () => Navigator.maybePop(context), icon: const Icon(Icons.close_rounded, color: Colors.white)),
                Expanded(child: Text(widget.bossName, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900))),
                Row(children: [for (var i = 0; i < 3; i++) Text(i < _hearts ? '❤️' : '🖤', style: const TextStyle(fontSize: 20))]),
              ]),
              Shake(trigger: _hits, child: Text(widget.bossEmoji, style: const TextStyle(fontSize: 82))),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: TweenAnimationBuilder<double>(
                    tween: Tween(begin: 1, end: max(0, _bossHp) / _bossMax),
                    duration: const Duration(milliseconds: 400),
                    builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 14, color: const Color(0xFFFF5E5E), backgroundColor: Colors.white30),
                  ),
                ),
              ),
              Text('طاقة الزعيم: ${max(0, _bossHp)}/$_bossMax', style: const TextStyle(color: Colors.white, fontSize: 12)),
            ]),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                Text(q.text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, height: 1.6)),
                const SizedBox(height: 10),
                ChoiceBlock(q: q, onPick: _pick, picked: _picked, reveal: _revealed, accent: widget.accent),
                if (_revealed) ...[
                  Text(_picked == q.answer ? '💥 ضربة قوية!' : '😬 الزعيم صدّ الضربة', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  if (q.explanation.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(q.explanation, textAlign: TextAlign.center)),
                  const SizedBox(height: 10),
                  FilledButton(style: FilledButton.styleFrom(backgroundColor: widget.accent), onPressed: _next, child: Text(_bossHp <= 0 || _hearts <= 0 ? 'النتيجة' : 'التالي')),
                ],
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

// ======================================================================
// بالونات الأرقام
// ======================================================================
class BalloonPopPage extends StatefulWidget {
  const BalloonPopPage({super.key, required this.store, this.content = const []});
  final ProgressStore store;
  final List<Question> content;
  @override
  State<BalloonPopPage> createState() => _BalloonPopPageState();
}

class _BalloonPopPageState extends State<BalloonPopPage> with SingleTickerProviderStateMixin {
  late List<Question> _qs = QuizEngine.prepare(choicePool(Random(), 8, content: widget.content));
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 9));
  final Set<int> _popped = {};
  int _n = 0, _lives = 3, _score = 0;
  bool _over = false;
  static const _cols = [Color(0xFFFF6B6B), Color(0xFF4CC9F0), Color(0xFFFFC83D), Color(0xFF43CBA0)];

  @override
  void initState() {
    super.initState();
    _c.addStatusListener((st) {
      if (st == AnimationStatus.completed && !_over) _missed();
    });
    _c.forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _round() {
    _popped.clear();
    if (_lives <= 0 || _n + 1 >= _qs.length) {
      _end();
      return;
    }
    setState(() => _n++);
    _c.forward(from: 0);
  }

  void _missed() {
    Sfx.wrong();
    setState(() => _lives--);
    _round();
  }

  void _tap(int i) {
    if (_popped.contains(i) || _over) return;
    Sfx.play('pop');
    setState(() => _popped.add(i));
    if (i == _qs[_n].answer) {
      _score++;
      Sfx.correct();
      _c.stop();
      _round();
    } else {
      Sfx.wrong();
      setState(() => _lives--);
      if (_lives <= 0) {
        _c.stop();
        _end();
      }
    }
  }

  Future<void> _end() async {
    _over = true;
    _c.stop();
    final coins = _score * 3 + (_score == _qs.length ? 10 : 0);
    await _payout(widget.store, coins, correct: _score);
    Sfx.play(_score >= 5 ? 'win' : 'lose');
    if (mounted) setState(() {});
  }

  void _again() {
    setState(() {
      _qs = QuizEngine.prepare(choicePool(Random(), 8, content: widget.content));
      _n = 0;
      _lives = 3;
      _score = 0;
      _over = false;
      _popped.clear();
    });
    _c.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    if (_over) {
      return GameOverView(
        win: _score >= 5,
        title: 'فقّعتِ $_score من ${_qs.length}',
        lines: const ['كل بالونة صحيحة = 3 عملات'],
        coins: _score * 3 + (_score == _qs.length ? 10 : 0),
        onAgain: _again,
      );
    }
    final q = _qs[_n];
    return Scaffold(
      appBar: AppBar(
        title: Text('🎈 بالونات الأرقام  ${'❤️' * _lives}'),
        backgroundColor: const Color(0xFF8EE3F5).withValues(alpha: .4),
      ),
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF8EE3F5), Color(0xFFE8F9FF)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Text('${_n + 1}/${_qs.length}  •  ${q.text}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Brand.ink, height: 1.5)),
          ),
          Expanded(
            child: LayoutBuilder(builder: (context, box) {
              final w = box.maxWidth, h = box.maxHeight;
              final cnt = q.options.length;
              return AnimatedBuilder(
                animation: _c,
                builder: (_, __) => Stack(children: [
                  for (var i = 0; i < cnt; i++)
                    if (!_popped.contains(i))
                      Positioned(
                        left: (w / cnt) * i + 4,
                        top: h * (1.05 - (_c.value * 1.25 + i * .05).clamp(0.0, 1.5)) - 20,
                        width: w / cnt - 8,
                        child: GestureDetector(
                          onTap: () => _tap(i),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Container(
                              height: 92,
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: _cols[i % 4],
                                borderRadius: const BorderRadius.vertical(top: Radius.circular(60), bottom: Radius.circular(46)),
                                boxShadow: [BoxShadow(color: _cols[i % 4].withValues(alpha: .4), blurRadius: 10, offset: const Offset(0, 6))],
                              ),
                              child: Text(q.options[i], textAlign: TextAlign.center, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
                            ),
                            Container(width: 2, height: 26, color: Colors.black26),
                          ]),
                        ),
                      ),
                ]),
              );
            }),
          ),
        ]),
      ),
    );
  }
}

// ======================================================================
// تحدي الوقت (60 ثانية)
// ======================================================================
class TimeAttackPage extends StatefulWidget {
  const TimeAttackPage({super.key, required this.store, this.content = const []});
  final ProgressStore store;
  final List<Question> content;
  @override
  State<TimeAttackPage> createState() => _TimeAttackPageState();
}

class _TimeAttackPageState extends State<TimeAttackPage> {
  final Random _r = Random();
  late List<Question> _qs = QuizEngine.prepare(choicePool(_r, 60, content: widget.content, level: 1, mathShare: .8));
  int _i = 0, _left = 60, _score = 0, _wrong = 0, _streak = 0;
  int? _flash;
  Timer? _t;
  bool _over = false;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_left <= 1) {
        _end();
      } else {
        setState(() => _left--);
      }
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  int get _coins => _score * 2 + (_streak >= 5 ? 5 : 0);

  void _pick(int i) {
    if (_flash != null || _over) return;
    final ok = i == _qs[_i].answer;
    setState(() {
      _flash = i;
      if (ok) {
        _score++;
        _streak++;
      } else {
        _wrong++;
        _streak = 0;
      }
    });
    ok ? Sfx.correct(combo: _streak) : Sfx.wrong();
    Future<void>.delayed(const Duration(milliseconds: 260), () {
      if (!mounted || _over) return;
      setState(() {
        _flash = null;
        _i = (_i + 1) % _qs.length;
      });
    });
  }

  Future<void> _end() async {
    _t?.cancel();
    _over = true;
    await _payout(widget.store, _coins, correct: _score);
    Sfx.play(_score >= 10 ? 'win' : 'lose');
    if (mounted) setState(() => _left = 0);
  }

  void _again() {
    setState(() {
      _qs = QuizEngine.prepare(choicePool(_r, 60, content: widget.content, mathShare: .8));
      _i = 0;
      _left = 60;
      _score = 0;
      _wrong = 0;
      _streak = 0;
      _over = false;
      _flash = null;
    });
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_left <= 1) {
        _end();
      } else {
        setState(() => _left--);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_over) {
      return GameOverView(
        win: _score >= 10,
        title: '$_score إجابة صحيحة!',
        lines: ['أخطاء: $_wrong', _score >= 10 ? 'سرعة رائعة ⚡' : 'جرّبي كسر رقمك'],
        coins: _coins,
        onAgain: _again,
      );
    }
    final q = _qs[_i];
    return Scaffold(
      appBar: AppBar(title: const Text('⏱️ تحدي الوقت')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            StatPill('⏱️', '$_left ث', light: false),
            StatPill('✅', '$_score', light: false),
            StatPill('🔥', '$_streak', light: false),
          ]),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: _left / 60, minHeight: 10, borderRadius: BorderRadius.circular(8)),
          const SizedBox(height: 24),
          Text(q.text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, height: 1.5)),
          const SizedBox(height: 16),
          ChoiceBlock(q: q, onPick: _pick, picked: _flash, reveal: _flash != null),
        ]),
      ),
    );
  }
}

// ======================================================================
// سباق الأرقام
// ======================================================================
class NumberRacePage extends StatefulWidget {
  const NumberRacePage({super.key, required this.store, this.content = const []});
  final ProgressStore store;
  final List<Question> content;
  @override
  State<NumberRacePage> createState() => _NumberRacePageState();
}

class _NumberRacePageState extends State<NumberRacePage> {
  static const _steps = 8;
  late List<Question> _qs = QuizEngine.prepare(choicePool(Random(), 24, content: widget.content));
  int _i = 0, _me = 0, _rival = 0, _correct = 0;
  int? _picked;
  bool _over = false;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _startRival();
  }

  void _startRival() {
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 7), (_) {
      if (_over) return;
      setState(() => _rival++);
      if (_rival >= _steps) _end();
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _pick(int i) {
    if (_picked != null || _over) return;
    final ok = i == _qs[_i].answer;
    setState(() {
      _picked = i;
      if (ok) {
        _me++;
        _correct++;
      } else {
        _rival++;
      }
    });
    ok ? Sfx.correct() : Sfx.wrong();
    Future<void>.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      if (_me >= _steps || _rival >= _steps) {
        _end();
      } else {
        setState(() {
          _picked = null;
          _i = (_i + 1) % _qs.length;
        });
      }
    });
  }

  bool get _win => _me >= _steps && _me >= _rival;

  Future<void> _end() async {
    if (_over) return;
    _t?.cancel();
    _over = true;
    await _payout(widget.store, _win ? 25 : 8, gems: _win ? 1 : 0, correct: _correct);
    Sfx.play(_win ? 'win' : 'lose');
    if (mounted) setState(() {});
  }

  void _again() {
    setState(() {
      _qs = QuizEngine.prepare(choicePool(Random(), 24, content: widget.content));
      _i = 0;
      _me = 0;
      _rival = 0;
      _correct = 0;
      _picked = null;
      _over = false;
    });
    _startRival();
  }

  Widget _lane(String car, int pos, Color c) => LayoutBuilder(builder: (context, box) {
        final w = box.maxWidth - 50;
        return Container(
          height: 54,
          margin: const EdgeInsets.symmetric(vertical: 4),
          decoration: BoxDecoration(color: c.withValues(alpha: .15), borderRadius: BorderRadius.circular(14)),
          child: Stack(children: [
            const Positioned(left: 8, top: 14, child: Text('🏁', style: TextStyle(fontSize: 22))),
            AnimatedPositioned(
              duration: const Duration(milliseconds: 450),
              curve: Curves.easeOut,
              right: 4 + w * (min(pos, _steps) / _steps),
              top: 6,
              child: Text(car, style: const TextStyle(fontSize: 34)),
            ),
          ]),
        );
      });

  @override
  Widget build(BuildContext context) {
    if (_over) {
      return GameOverView(
        win: _win,
        title: _win ? 'فزتِ بالسباق!' : 'المنافس سبقكِ',
        lines: ['إجابات صحيحة: $_correct'],
        coins: _win ? 25 : 8,
        gems: _win ? 1 : 0,
        onAgain: _again,
      );
    }
    final q = _qs[_i];
    return Scaffold(
      appBar: AppBar(title: const Text('🏎️ سباق الأرقام')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          _lane('🏎️', _me, Brand.violet),
          _lane('🚙', _rival, const Color(0xFFE5703F)),
          const Text('كل إجابة صحيحة تقدّمك، وكل خطأ يقدّم المنافس!', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 14),
          Text(q.text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, height: 1.5)),
          const SizedBox(height: 10),
          ChoiceBlock(q: q, onPick: _pick, picked: _picked, reveal: _picked != null),
        ]),
      ),
    );
  }
}

// ======================================================================
// حفر الكنز
// ======================================================================
class TreasureDigPage extends StatefulWidget {
  const TreasureDigPage({super.key, required this.store, this.content = const []});
  final ProgressStore store;
  final List<Question> content;
  @override
  State<TreasureDigPage> createState() => _TreasureDigPageState();
}

class _TreasureDigPageState extends State<TreasureDigPage> {
  final Random _r = Random();
  late List<Question> _qs = QuizEngine.prepare(choicePool(_r, 8, content: widget.content));
  late List<String> _tiles = _mkTiles();
  final Set<int> _dug = {};
  int _i = 0, _coins = 0, _gems = 0, _correct = 0;
  bool _canDig = false;
  bool _answered = false;
  int? _picked;
  bool _over = false;

  List<String> _mkTiles() {
    final t = <String>['💎', '💎', ...List.filled(4, '🪙20'), ...List.filled(5, '🪙10'), ...List.filled(3, '🪙5'), '💣', '💣'];
    t.shuffle(_r);
    return t;
  }

  void _pick(int i) {
    if (_answered) return;
    final ok = i == _qs[_i].answer;
    setState(() {
      _picked = i;
      _answered = true;
      _canDig = ok;
      if (ok) _correct++;
    });
    ok ? Sfx.correct() : Sfx.wrong();
    if (!ok) Future<void>.delayed(const Duration(milliseconds: 900), _nextQ);
  }

  void _dig(int k) {
    if (!_canDig || _dug.contains(k)) return;
    final t = _tiles[k];
    Sfx.play(t == '💣' ? 'hit' : t == '💎' ? 'star' : 'coin');
    setState(() {
      _dug.add(k);
      _canDig = false;
      if (t == '💎') {
        _gems++;
      } else if (t == '💣') {
        _coins = max(0, _coins - 5);
      } else {
        _coins += int.parse(t.substring(2));
      }
    });
    Future<void>.delayed(const Duration(milliseconds: 700), _nextQ);
  }

  Future<void> _nextQ() async {
    if (!mounted) return;
    if (_i + 1 >= _qs.length) {
      await _payout(widget.store, _coins, gems: _gems, correct: _correct);
      Sfx.play(_coins >= 40 ? 'win' : 'lose');
      if (mounted) setState(() => _over = true);
      return;
    }
    setState(() {
      _i++;
      _answered = false;
      _picked = null;
      _canDig = false;
    });
  }

  void _again() {
    setState(() {
      _qs = QuizEngine.prepare(choicePool(_r, 8, content: widget.content));
      _tiles = _mkTiles();
      _dug.clear();
      _i = 0;
      _coins = 0;
      _gems = 0;
      _correct = 0;
      _answered = false;
      _picked = null;
      _canDig = false;
      _over = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_over) {
      return GameOverView(win: _coins >= 40, title: 'غنيمتك: $_coins عملة', lines: ['إجابات صحيحة: $_correct من ${_qs.length}'], coins: _coins, gems: _gems, onAgain: _again);
    }
    final q = _qs[_i];
    return Scaffold(
      appBar: AppBar(title: const Text('⛏️ حفر الكنز')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('سؤال ${_i + 1}/${_qs.length}', style: const TextStyle(fontWeight: FontWeight.w800)),
            StatPill('🪙', '$_coins', light: false),
            StatPill('💎', '$_gems', light: false),
          ]),
          const SizedBox(height: 10),
          Text(q.text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, height: 1.5)),
          ChoiceBlock(q: q, onPick: _pick, picked: _picked, reveal: _answered, accent: const Color(0xFF8D6A44)),
          const SizedBox(height: 8),
          Text(_canDig ? 'صحيح! اختاري مربعًا للحفر ⛏️' : 'أجيبي صح لتحفري مربعًا', style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            children: [
              for (var k = 0; k < 16; k++)
                GestureDetector(
                  onTap: () => _dig(k),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: _dug.contains(k) ? const Color(0xFFFFF1C9) : (_canDig ? const Color(0xFFC49A6C) : const Color(0xFFA98462)),
                      border: Border.all(color: _canDig && !_dug.contains(k) ? Brand.gold : Colors.transparent, width: 3),
                    ),
                    child: Text(_dug.contains(k) ? _tiles[k] : '🟫', style: const TextStyle(fontSize: 22)),
                  ),
                ),
            ],
          ),
        ]),
      ),
    );
  }
}
