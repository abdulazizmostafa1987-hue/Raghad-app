import 'dart:math';
import 'package:flutter/material.dart';

/// انفجار جسيمات (نجوم/عملات) عند الإجابة الصحيحة أو الفوز.
class ParticleBurst extends StatefulWidget {
  const ParticleBurst({super.key, this.emojis = const ['⭐', '✨', '🌟'], this.count = 16, this.seed = 1});
  final List<String> emojis;
  final int count;
  final int seed;
  @override
  State<ParticleBurst> createState() => _ParticleBurstState();
}

class _ParticleBurstState extends State<ParticleBurst> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
  late final List<_P> _ps = () {
    final r = Random(widget.seed);
    return List.generate(widget.count, (i) {
      final a = r.nextDouble() * 2 * pi;
      return _P(a, 70 + r.nextDouble() * 120, 14 + r.nextDouble() * 14, widget.emojis[r.nextInt(widget.emojis.length)]);
    });
  }();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) {
            final t = Curves.easeOut.transform(_c.value);
            return Stack(alignment: Alignment.center, children: [
              for (final p in _ps)
                Transform.translate(
                  offset: Offset(cos(p.a) * p.d * t, sin(p.a) * p.d * t + 60 * t * t),
                  child: Opacity(
                    opacity: (1 - _c.value).clamp(0.0, 1.0),
                    child: Text(p.e, style: TextStyle(fontSize: p.s)),
                  ),
                ),
            ]);
          },
        ),
      );
}

class _P {
  _P(this.a, this.d, this.s, this.e);
  final double a, d, s;
  final String e;
}

/// اهتزاز أفقي قصير عند الخطأ. غيّري [trigger] لتشغيله.
class Shake extends StatelessWidget {
  const Shake({super.key, required this.trigger, required this.child});
  final int trigger;
  final Widget child;
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        key: ValueKey(trigger),
        tween: Tween(begin: 0, end: trigger == 0 ? 0 : 1),
        duration: const Duration(milliseconds: 420),
        builder: (_, v, c) => Transform.translate(offset: Offset(sin(v * pi * 6) * 10 * (1 - v), 0), child: c),
        child: child,
      );
}

/// عدّاد أرقام متصاعد.
class CountUp extends StatelessWidget {
  const CountUp(this.value, {super.key, this.style, this.prefix = '', this.suffix = ''});
  final int value;
  final TextStyle? style;
  final String prefix;
  final String suffix;
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: value.toDouble()),
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOut,
        builder: (_, v, __) => Text('$prefix${v.round()}$suffix', style: style),
      );
}

/// ظهور من الأسفل مع تلاشٍ، بتأخير اختياري.
class PopIn extends StatelessWidget {
  const PopIn({super.key, required this.child, this.delayMs = 0});
  final Widget child;
  final int delayMs;
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: 450 + delayMs),
        curve: Interval(delayMs / (450 + delayMs), 1, curve: Curves.easeOutBack),
        builder: (_, v, c) => Opacity(
          opacity: v.clamp(0.0, 1.0),
          child: Transform.translate(offset: Offset(0, (1 - v) * 24), child: c),
        ),
        child: child,
      );
}
