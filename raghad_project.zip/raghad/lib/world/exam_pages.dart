import 'dart:math';
import 'package:flutter/material.dart';
import '../models.dart';
import '../progress_store.dart';
import 'brand.dart';
import 'lesson_flow.dart';
import 'practice_gen.dart';
import 'practice_runner.dart';
import 'rewards.dart';
import 'world_data.dart';

/// امتحان كامل: مقدمة ← أسئلة بمؤقت وبدون تلميحات ← نتيجة بتقدير ومراجعة.
/// إن مُرّر [nodeId] فهو «تحدي وحدة» ويمنح نجومًا ومكافآت المحطات.
class ExamPage extends StatefulWidget {
  const ExamPage({
    super.key,
    required this.title,
    required this.questions,
    required this.store,
    required this.seconds,
    this.accent = Brand.violet,
    this.nodeId,
  });
  final String title;
  final List<Question> questions;
  final ProgressStore store;
  final int seconds;
  final Color accent;
  final String? nodeId;
  @override
  State<ExamPage> createState() => _ExamPageState();
}

class _ExamPageState extends State<ExamPage> {
  int _stage = 0; // 0 مقدمة، 1 أسئلة، 2 نتيجة
  List<AnswerRecord> _records = const [];
  int _used = 0;
  LessonReward? _reward;

  Future<void> _done(List<AnswerRecord> recs, int used) async {
    final right = {for (final r in recs) if (r.ok) r.q.id};
    final wrong = {for (final r in recs) if (!r.ok) r.q.id};
    final correct = right.length;
    await widget.store.recordAttempt(
        lessonId: widget.nodeId ?? 'exam',
        correct: correct,
        total: recs.length,
        wrong: wrong,
        right: right);
    LessonReward? reward;
    if (widget.nodeId != null) {
      reward = await widget.store.rewardNode(
          nodeId: widget.nodeId!, correct: correct, total: recs.length, boss: true);
    } else {
      final pct = recs.isEmpty ? 0 : (correct * 100 / recs.length).round();
      await widget.store.logExam(widget.title, pct, correct, recs.length);
      await widget.store.putInt('totalCorrect', widget.store.totalCorrect + correct);
      await widget.store.bumpQuest('correct', correct);
    }
    if (!mounted) return;
    setState(() {
      _records = recs;
      _used = used;
      _reward = reward;
      _stage = 2;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_stage == 1) {
      return Scaffold(
        body: SafeArea(
          child: PracticeRunner(
            questions: widget.questions,
            store: widget.store,
            allowHints: false,
            seconds: widget.seconds,
            accent: widget.accent,
            onFinished: _done,
          ),
        ),
      );
    }
    if (_stage == 2) {
      final ok = _records.where((r) => r.ok).length;
      if (_reward != null) {
        return NodeResultView(
          reward: _reward!,
          correct: ok,
          total: _records.length,
          store: widget.store,
          accent: widget.accent,
          onClose: () => Navigator.pop(context),
        );
      }
      return ExamResultView(
          title: widget.title,
          records: _records,
          seconds: _used,
          accent: widget.accent,
          onClose: () => Navigator.pop(context));
    }
    final mins = (widget.seconds / 60).round();
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const SizedBox(height: 10),
          const Center(child: Text('📝', style: TextStyle(fontSize: 72))),
          const SizedBox(height: 10),
          Text(widget.title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          _Rule('❓', '${widget.questions.length} سؤال'),
          _Rule('⏱️', '$mins دقيقة، والمؤقت يظهر فوق'),
          const _Rule('🚫', 'لا توجد تلميحات في الامتحان'),
          const _Rule('📊', 'ستحصلين على تقدير ومراجعة لأخطائك'),
          const Spacer(),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: widget.accent),
              onPressed: widget.questions.isEmpty ? null : () => setState(() => _stage = 1),
              child: const Text('ابدئي الامتحان')),
        ]),
      ),
    );
  }
}

class _Rule extends StatelessWidget {
  const _Rule(this.emoji, this.text);
  final String emoji;
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600))),
        ]),
      );
}

class ExamResultView extends StatelessWidget {
  const ExamResultView({
    super.key,
    required this.title,
    required this.records,
    required this.seconds,
    required this.accent,
    required this.onClose,
  });
  final String title;
  final List<AnswerRecord> records;
  final int seconds;
  final Color accent;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final ok = records.where((r) => r.ok).length;
    final pct = records.isEmpty ? 0 : (ok * 100 / records.length).round();
    final wrong = records.where((r) => !r.ok).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('نتيجة الامتحان')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        GradientCard(
          colors: pct >= 65
              ? const [Brand.violetLight, Brand.violet]
              : const [Color(0xFFFFA26B), Color(0xFFE5703F)],
          child: Column(children: [
            Text(title, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
            Text('$pct٪', key: const ValueKey('exam-percent'),
                style: const TextStyle(color: Colors.white, fontSize: 60, fontWeight: FontWeight.w900)),
            Text(gradeLabel(pct),
                style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              StatPill('✅', '$ok صحيحة'),
              StatPill('❌', '${records.length - ok} خاطئة'),
              StatPill('⏱️', '${seconds ~/ 60}:${(seconds % 60).toString().padLeft(2, '0')}'),
              StatPill('🪙', '+${(pct / 5).round()}'),
            ]),
          ]),
        ),
        if (wrong.isEmpty)
          const Card(
              child: Padding(
                  padding: EdgeInsets.all(18),
                  child: Text('لا أخطاء! أداء كامل 🏆',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))))
        else ...[
          const Padding(
              padding: EdgeInsets.only(top: 12, bottom: 4),
              child: Text('مراجعة الأخطاء', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
          for (final r in wrong)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(r.q.text, style: const TextStyle(fontWeight: FontWeight.w800, height: 1.5)),
                  const SizedBox(height: 6),
                  Text('الإجابة الصحيحة: ${correctText(r.q)}',
                      style: const TextStyle(color: Color(0xFF2EAD6B), fontWeight: FontWeight.w800)),
                  if (r.q.explanation.isNotEmpty)
                    Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(r.q.explanation, style: const TextStyle(height: 1.5))),
                ]),
              ),
            ),
        ],
        const SizedBox(height: 12),
        FilledButton(onPressed: onClose, child: const Text('رجوع')),
      ]),
    );
  }
}

/// تبويب الامتحانات: سريع، توليدي، شامل لكل جزيرة، مراجعة الأخطاء، والسجل.
class ExamHub extends StatefulWidget {
  const ExamHub({super.key, required this.store, required this.content, required this.islands});
  final ProgressStore store;
  final Content content;
  final List<Island> islands;
  @override
  State<ExamHub> createState() => _ExamHubState();
}

class _ExamHubState extends State<ExamHub> {
  Future<void> _go(String title, List<Question> qs, int seconds, {Color? accent}) async {
    await Navigator.push(
        context,
        MaterialPageRoute<void>(
            builder: (_) => ExamPage(
                title: title,
                questions: qs,
                store: widget.store,
                seconds: seconds,
                accent: accent ?? Brand.violet)));
    if (mounted) setState(() {});
  }

  List<Question> _take(List<Question> src, int n) =>
      ([...src]..shuffle(Random())).take(n).toList();

  @override
  Widget build(BuildContext context) {
    final all = widget.content.allQuestions;
    final wrongIds = widget.store.wrongIds;
    final wrong = all.where((q) => wrongIds.contains(q.id)).toList();
    final log = widget.store.examLog.reversed.take(8).toList();
    final primary = widget.islands.where((i) => !i.archive && i.nodes.isNotEmpty).toList();
    return ListView(padding: const EdgeInsets.all(14), children: [
      GradientCard(
        colors: const [Color(0xFF3A86FF), Color(0xFF5B3CC4)],
        onTap: all.isEmpty ? null : () => _go('امتحان سريع', _take(all, 10), 600),
        child: const _HubTile('⚡', 'امتحان سريع', '١٠ أسئلة متنوعة • ١٠ دقائق'),
      ),
      GradientCard(
        colors: const [Color(0xFFFFB347), Color(0xFFFF7E5F)],
        onTap: () => _go('امتحان الرياضيات المتجدد',
            MathPractice.generate(Random(), count: 15, level: 2), 1200,
            accent: const Color(0xFFE5703F)),
        child: const _HubTile('🧮', 'امتحان رياضيات متجدد', '١٥ مسألة جديدة في كل مرة • ٢٠ دقيقة'),
      ),
      GradientCard(
        colors: const [Color(0xFF43CBA0), Color(0xFF1B9E77)],
        onTap: wrong.isEmpty ? null : () => _go('امتحان مراجعة أخطائي', _take(wrong, 10), 900),
        child: _HubTile('🩹', 'امتحان مراجعة أخطائي',
            wrong.isEmpty ? 'لا أخطاء محفوظة بعد' : '${wrong.length} سؤال تحتاج مراجعته'),
      ),
      const Padding(
          padding: EdgeInsets.only(top: 14, bottom: 4),
          child: Text('امتحانات شاملة للجزر', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
      for (final i in primary)
        if (i.subject.lessons.fold<int>(0, (a, l) => a + l.questions.length) >= 10)
          Card(
            child: ListTile(
              leading: Text(i.emoji, style: const TextStyle(fontSize: 30)),
              title: Text(i.name, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('٢٠ سؤالًا • ٢٥ دقيقة'),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: () => _go('امتحان شامل: ${i.name}',
                  _take([for (final l in i.subject.lessons) ...l.questions], 20), 1500,
                  accent: i.c2),
            ),
          ),
      if (log.isNotEmpty) ...[
        const Padding(
            padding: EdgeInsets.only(top: 14, bottom: 4),
            child: Text('سجل امتحاناتي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
        for (final e in log)
          Card(
            child: ListTile(
              leading: CircleAvatar(
                  backgroundColor: Brand.violet.withValues(alpha: .12),
                  child: Text('${e['percent']}٪', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900))),
              title: Text('${e['title']}'),
              subtitle: Text('${gradeLabel(e['percent'] as int)} • ${e['correct']}/${e['total']}'),
            ),
          ),
      ],
    ]);
  }
}

class _HubTile extends StatelessWidget {
  const _HubTile(this.emoji, this.title, this.sub);
  final String emoji;
  final String title;
  final String sub;
  @override
  Widget build(BuildContext context) => Row(children: [
        Text(emoji, style: const TextStyle(fontSize: 40)),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
            Text(sub, style: const TextStyle(color: Colors.white70)),
          ]),
        ),
        const Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 34),
      ]);
}
