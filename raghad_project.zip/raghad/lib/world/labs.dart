import 'dart:math';
import 'package:flutter/material.dart';
import 'brand.dart';

/// يختار معملًا تفاعليًا مناسبًا لعنوان الدرس (أو null).
Widget? labFor(String title, Color accent) {
  if (title.contains('قابلية القسمة')) return DivisibilityLab(accent: accent);
  if (title.contains('خط الأعداد') || title.contains('القيمة المطلقة')) return NumberLineLab(accent: accent);
  if (title.contains('الأعداد النسبية')) return FractionLab(accent: accent);
  if (title.contains('الوسط') || title.contains('توازن') || title.contains('الوسيط') || title.contains('المدى')) {
    return StatsLab(accent: accent);
  }
  return null;
}

class _LabShell extends StatelessWidget {
  const _LabShell({required this.title, required this.accent, required this.children});
  final String title;
  final Color accent;
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        padding: const EdgeInsets.all(4),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('🧪', style: TextStyle(fontSize: 44)),
          Text('جرّبي بنفسك: $title', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: accent)),
          const SizedBox(height: 10),
          ...children,
        ]),
      );
}

// ---------------------------------------------------------------- خط الأعداد
class NumberLineLab extends StatefulWidget {
  const NumberLineLab({super.key, required this.accent});
  final Color accent;
  @override
  State<NumberLineLab> createState() => _NumberLineLabState();
}

class _NumberLineLabState extends State<NumberLineLab> {
  double a = -4, b = 3;
  @override
  Widget build(BuildContext context) {
    final ai = a.round(), bi = b.round();
    final cmp = ai > bi ? '$ai أكبر من $bi' : ai < bi ? '$ai أصغر من $bi' : 'العددان متساويان';
    final abscmp = ai.abs() > bi.abs() ? '|$ai| أكبر من |$bi|' : ai.abs() < bi.abs() ? '|$ai| أصغر من |$bi|' : '|$ai| = |$bi|';
    return _LabShell(title: 'خط الأعداد', accent: widget.accent, children: [
      SizedBox(
        height: 90,
        width: double.infinity,
        child: CustomPaint(painter: _LinePainter(ai, bi, widget.accent)),
      ),
      Row(children: [
        const Text('أ', style: TextStyle(fontWeight: FontWeight.w900)),
        Expanded(child: Slider(value: a, min: -10, max: 10, divisions: 20, label: '$ai', onChanged: (v) => setState(() => a = v))),
        Text('$ai', style: const TextStyle(fontWeight: FontWeight.w900)),
      ]),
      Row(children: [
        const Text('ب', style: TextStyle(fontWeight: FontWeight.w900)),
        Expanded(child: Slider(value: b, min: -10, max: 10, divisions: 20, label: '$bi', onChanged: (v) => setState(() => b = v))),
        Text('$bi', style: const TextStyle(fontWeight: FontWeight.w900)),
      ]),
      Text('📏 $cmp', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      Text('🎯 بُعد أ عن الصفر = ${ai.abs()} وبُعد ب = ${bi.abs()}', style: const TextStyle(fontSize: 15)),
      Text('⚖️ $abscmp', style: const TextStyle(fontSize: 15)),
      Text('↔️ المسافة بين أ وب = ${(ai - bi).abs()}', style: const TextStyle(fontSize: 15)),
    ]);
  }
}

class _LinePainter extends CustomPainter {
  _LinePainter(this.a, this.b, this.color);
  final int a, b;
  final Color color;
  @override
  void paint(Canvas c, Size s) {
    final y = s.height * .55;
    final x0 = 16.0, x1 = s.width - 16;
    double px(num v) => x0 + (v + 10) / 20 * (x1 - x0);
    final line = Paint()..color = Colors.grey.shade600..strokeWidth = 3;
    c.drawLine(Offset(x0, y), Offset(x1, y), line);
    for (var v = -10; v <= 10; v++) {
      final h = v % 5 == 0 ? 12.0 : 6.0;
      c.drawLine(Offset(px(v), y - h), Offset(px(v), y + h), line);
      if (v % 5 == 0) {
        final tp = TextPainter(text: TextSpan(text: '$v', style: const TextStyle(color: Colors.grey, fontSize: 11)), textDirection: TextDirection.ltr)..layout();
        tp.paint(c, Offset(px(v) - tp.width / 2, y + 14));
      }
    }
    c.drawLine(Offset(px(0), y - 18), Offset(px(0), y + 18), Paint()..color = Brand.ink..strokeWidth = 4);
    void dot(int v, String name, Color col) {
      c.drawCircle(Offset(px(v), y), 11, Paint()..color = col);
      final tp = TextPainter(text: TextSpan(text: name, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w900)), textDirection: TextDirection.rtl)..layout();
      tp.paint(c, Offset(px(v) - tp.width / 2, y - tp.height / 2));
    }

    dot(a, 'أ', color);
    dot(b, 'ب', const Color(0xFFE5703F));
  }

  @override
  bool shouldRepaint(covariant _LinePainter o) => o.a != a || o.b != b;
}

// ---------------------------------------------------------------- الكسور
class FractionLab extends StatefulWidget {
  const FractionLab({super.key, required this.accent});
  final Color accent;
  @override
  State<FractionLab> createState() => _FractionLabState();
}

class _FractionLabState extends State<FractionLab> {
  double n = 3, d = 4;
  @override
  Widget build(BuildContext context) {
    final den = d.round();
    final num = min(n.round(), den);
    final v = num / den;
    return _LabShell(title: 'الكسر والعدد العشري والنسبة', accent: widget.accent, children: [
      Center(child: SizedBox(width: 150, height: 150, child: CustomPaint(painter: _PiePainter(num, den, widget.accent)))),
      Row(children: [
        const Text('البسط'),
        Expanded(child: Slider(value: min(n, den.toDouble()), min: 0, max: 12, divisions: 12, label: '$num', onChanged: (x) => setState(() => n = x))),
        Text('$num', style: const TextStyle(fontWeight: FontWeight.w900)),
      ]),
      Row(children: [
        const Text('المقام'),
        Expanded(child: Slider(value: d, min: 2, max: 12, divisions: 10, label: '$den', onChanged: (x) => setState(() => d = x))),
        Text('$den', style: const TextStyle(fontWeight: FontWeight.w900)),
      ]),
      Text('الكسر: $num/$den', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      Text('العدد العشري: ${v.toStringAsFixed(3).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '')}', style: const TextStyle(fontSize: 16)),
      Text('النسبة المئوية: ${(v * 100).toStringAsFixed(1).replaceFirst(RegExp(r'\.0$'), '')}٪', style: const TextStyle(fontSize: 16)),
    ]);
  }
}

class _PiePainter extends CustomPainter {
  _PiePainter(this.n, this.d, this.color);
  final int n, d;
  final Color color;
  @override
  void paint(Canvas c, Size s) {
    final r = Rect.fromLTWH(0, 0, s.width, s.height);
    for (var i = 0; i < d; i++) {
      final start = -pi / 2 + i * 2 * pi / d;
      c.drawArc(r, start, 2 * pi / d, true, Paint()..color = i < n ? color : color.withValues(alpha: .15));
      c.drawArc(r, start, 2 * pi / d, true, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white);
    }
  }

  @override
  bool shouldRepaint(covariant _PiePainter o) => o.n != n || o.d != d;
}

// ---------------------------------------------------------------- قابلية القسمة
class DivisibilityLab extends StatefulWidget {
  const DivisibilityLab({super.key, required this.accent});
  final Color accent;
  @override
  State<DivisibilityLab> createState() => _DivisibilityLabState();
}

class _DivisibilityLabState extends State<DivisibilityLab> {
  final TextEditingController _c = TextEditingController(text: '360');
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final n = int.tryParse(_c.text.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
    final digitSum = n.toString().split('').map(int.parse).fold<int>(0, (a, b) => a + b);
    final rules = <(int, String)>[
      (2, 'آخر رقم زوجي'),
      (3, 'مجموع الأرقام ($digitSum) يقبل 3'),
      (4, 'آخر رقمين (${n % 100}) يقبلان 4'),
      (5, 'آخر رقم 0 أو 5'),
      (6, 'يقبل 2 و3 معًا'),
      (9, 'مجموع الأرقام ($digitSum) يقبل 9'),
      (10, 'آخر رقم 0'),
    ];
    return _LabShell(title: 'قابلية القسمة', accent: widget.accent, children: [
      TextField(
        controller: _c,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
        decoration: const InputDecoration(labelText: 'اكتبي أي عدد'),
        onChanged: (_) => setState(() {}),
      ),
      const SizedBox(height: 8),
      for (final r in rules)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [
            Text(n % r.$1 == 0 ? '✅' : '❌', style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 8),
            Expanded(child: Text('يقبل القسمة على ${r.$1}؟  ${r.$2}', style: const TextStyle(fontSize: 15))),
          ]),
        ),
    ]);
  }
}

// ---------------------------------------------------------------- الإحصاء
class StatsLab extends StatefulWidget {
  const StatsLab({super.key, required this.accent});
  final Color accent;
  @override
  State<StatsLab> createState() => _StatsLabState();
}

class _StatsLabState extends State<StatsLab> {
  final List<double> v = [4, 8, 6, 10, 7];
  @override
  Widget build(BuildContext context) {
    final a = v.map((e) => e.round()).toList();
    final sorted = [...a]..sort();
    final mean = a.fold<int>(0, (x, y) => x + y) / a.length;
    final median = sorted[sorted.length ~/ 2];
    final range = sorted.last - sorted.first;
    return _LabShell(title: 'الوسط والوسيط والمدى', accent: widget.accent, children: [
      SizedBox(
        height: 110,
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          for (final x in a)
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                height: 8.0 + x * 7,
                decoration: BoxDecoration(color: widget.accent, borderRadius: BorderRadius.circular(8)),
                alignment: Alignment.topCenter,
                child: Text('$x', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
              ),
            ),
        ]),
      ),
      for (var i = 0; i < v.length; i++)
        Slider(value: v[i], min: 1, max: 15, divisions: 14, label: '${v[i].round()}', onChanged: (x) => setState(() => v[i] = x)),
      Text('الوسط الحسابي = ${mean.toStringAsFixed(1).replaceFirst(RegExp(r'\.0$'), '')}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      Text('الوسيط = $median', style: const TextStyle(fontSize: 16)),
      Text('المدى = $range', style: const TextStyle(fontSize: 16)),
    ]);
  }
}
