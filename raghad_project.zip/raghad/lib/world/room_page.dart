import 'dart:math';
import 'package:flutter/material.dart';
import '../progress_store.dart';
import '../widgets.dart' show MascotPainter, mascotColors;
import 'brand.dart';
import 'rewards.dart';
import 'sfx.dart';

/// رغد بملابسها: عباءة خلفية، الجسم، ثم القبعة والنظارة.
class StyledMascot extends StatefulWidget {
  const StyledMascot({super.key, required this.store, this.size = 200});
  final ProgressStore store;
  final double size;
  @override
  State<StyledMascot> createState() => _StyledMascotState();
}

class _StyledMascotState extends State<StyledMascot> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final eq = widget.store.equipped;
    final color = mascotColors[widget.store.mascot % mascotColors.length];
    final sz = Size(widget.size, widget.size);
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final v = _c.value;
        final blink = v > 0.9 ? (1 - ((v - 0.95).abs() / 0.05)).clamp(0.0, 1.0).toDouble() : 0.0;
        return Transform.translate(
          offset: Offset(0, sin(v * 2 * pi) * 5),
          child: SizedBox(
            width: widget.size,
            height: widget.size,
            child: Stack(children: [
              CustomPaint(size: sz, painter: _CapePainter(eq['cape'] as String?)),
              CustomPaint(size: sz, painter: MascotPainter(color, widget.store.level, blink)),
              CustomPaint(size: sz, painter: _AccPainter(eq['hat'] as String?, eq['glasses'] as String?)),
            ]),
          ),
        );
      },
    );
  }
}

class _CapePainter extends CustomPainter {
  _CapePainter(this.id);
  final String? id;
  @override
  void paint(Canvas c, Size s) {
    if (id == null) return;
    final w = s.width, h = s.height;
    final p = Path()
      ..moveTo(w * .22, h * .62)
      ..quadraticBezierTo(w * .02, h * .9, w * .14, h * 1.0)
      ..lineTo(w * .86, h * 1.0)
      ..quadraticBezierTo(w * .98, h * .9, w * .78, h * .62)
      ..close();
    if (id == 'cape_rainbow') {
      c.drawPath(
          p,
          Paint()
            ..shader = const LinearGradient(
                    colors: [Color(0xFFFF5E5E), Color(0xFFFFC83D), Color(0xFF4CD08A), Color(0xFF4C8DFF), Color(0xFFB36BFF)])
                .createShader(Rect.fromLTWH(0, 0, w, h)));
    } else {
      c.drawPath(p, Paint()..color = const Color(0xFFE5484D));
    }
  }

  @override
  bool shouldRepaint(covariant _CapePainter o) => o.id != id;
}

class _AccPainter extends CustomPainter {
  _AccPainter(this.hat, this.glasses);
  final String? hat;
  final String? glasses;

  Path _star(double cx, double cy, double r1, double r2) {
    final p = Path();
    for (var i = 0; i < 10; i++) {
      final a = (-90 + i * 36) * pi / 180;
      final r = i.isEven ? r1 : r2;
      final o = Offset(cx + r * cos(a), cy + r * sin(a));
      i == 0 ? p.moveTo(o.dx, o.dy) : p.lineTo(o.dx, o.dy);
    }
    return p..close();
  }

  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    switch (hat) {
      case 'hat_crown':
        final p = Path()
          ..moveTo(w * .30, h * .17)
          ..lineTo(w * .30, h * .04)
          ..lineTo(w * .40, h * .11)
          ..lineTo(w * .50, h * .0)
          ..lineTo(w * .60, h * .11)
          ..lineTo(w * .70, h * .04)
          ..lineTo(w * .70, h * .17)
          ..close();
        c.drawPath(p, Paint()..color = Brand.gold);
        c.drawCircle(Offset(w * .5, h * .12), w * .02, Paint()..color = Brand.pink);
      case 'hat_grad':
        c.drawPath(
            Path()
              ..moveTo(w * .5, h * .02)
              ..lineTo(w * .84, h * .12)
              ..lineTo(w * .5, h * .22)
              ..lineTo(w * .16, h * .12)
              ..close(),
            Paint()..color = const Color(0xFF2B2B3A));
        c.drawLine(Offset(w * .82, h * .13), Offset(w * .82, h * .30),
            Paint()..color = Brand.gold..strokeWidth = w * .015);
      case 'hat_wizard':
        c.drawPath(
            Path()
              ..moveTo(w * .5, -h * .04)
              ..lineTo(w * .74, h * .20)
              ..lineTo(w * .26, h * .20)
              ..close(),
            Paint()..color = const Color(0xFF6A3FD1));
        c.drawPath(_star(w * .5, h * .11, w * .04, w * .018), Paint()..color = Brand.gold);
      case 'hat_bow':
        final b = Paint()..color = Brand.pink;
        c.drawPath(
            Path()
              ..moveTo(w * .72, h * .14)
              ..lineTo(w * .86, h * .06)
              ..lineTo(w * .86, h * .22)
              ..close(),
            b);
        c.drawPath(
            Path()
              ..moveTo(w * .72, h * .14)
              ..lineTo(w * .58, h * .06)
              ..lineTo(w * .58, h * .22)
              ..close(),
            b);
        c.drawCircle(Offset(w * .72, h * .14), w * .025, Paint()..color = const Color(0xFFE5589A));
    }
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * .016
      ..color = const Color(0xFF2B2B3A);
    final eyes = [Offset(w * .32, h * .45), Offset(w * .68, h * .45)];
    switch (glasses) {
      case 'gl_round':
        for (final e in eyes) {
          c.drawCircle(e, w * .115, stroke);
        }
        c.drawLine(Offset(w * .435, h * .45), Offset(w * .565, h * .45), stroke);
      case 'gl_star':
        for (final e in eyes) {
          c.drawPath(_star(e.dx, e.dy, w * .13, w * .06), Paint()..color = Brand.gold.withValues(alpha: .9));
          c.drawPath(_star(e.dx, e.dy, w * .13, w * .06), stroke);
        }
      case 'gl_cool':
        for (final e in eyes) {
          c.drawRRect(
              RRect.fromRectAndRadius(Rect.fromCenter(center: e, width: w * .22, height: h * .15), Radius.circular(w * .05)),
              Paint()..color = const Color(0xFF1F1F2E));
        }
        c.drawLine(Offset(w * .43, h * .43), Offset(w * .57, h * .43), stroke);
    }
  }

  @override
  bool shouldRepaint(covariant _AccPainter o) => o.hat != hat || o.glasses != glasses;
}

class RoomPage extends StatefulWidget {
  const RoomPage({super.key, required this.store, required this.onChanged});
  final ProgressStore store;
  final VoidCallback onChanged;
  @override
  State<RoomPage> createState() => _RoomPageState();
}

class _RoomPageState extends State<RoomPage> {
  String _tab = 'hat';
  static const _tabs = {
    'hat': '🎩 قبعات',
    'glasses': '👓 نظارات',
    'cape': '🦸 عباءات',
    'color': '🎨 ألوان',
    'room': '🏠 غرف',
    'stickers': '🖼️ ملصقات',
    'chest': '🎁 صناديق',
  };

  ProgressStore get s => widget.store;

  void _refresh() {
    setState(() {});
    widget.onChanged();
  }

  List<Color> _roomColors() {
    switch (s.equipped['room']) {
      case 'room_stars':
        return const [Color(0xFF2B1B6B), Color(0xFF5B3CC4)];
      case 'room_garden':
        return const [Color(0xFFB7F0C1), Color(0xFF6FCF97)];
      case 'room_beach':
        return const [Color(0xFF8EE3F5), Color(0xFFFFE9A8)];
      default:
        return const [Color(0xFFEBDDFF), Color(0xFFFFD6E8)];
    }
  }

  String _roomDeco() {
    switch (s.equipped['room']) {
      case 'room_stars':
        return '✨ ⭐ 🌙 ✨ 🪐';
      case 'room_garden':
        return '🌷 🦋 🌼 🐝 🌸';
      case 'room_beach':
        return '🐚 ☀️ 🌴 🐠 🦀';
      default:
        return '💜 ☁️ 💗 ☁️ 💜';
    }
  }

  Future<void> _tapItem(ShopItem it) async {
    final eq = s.equipped[it.slot] == it.id;
    if (eq) {
      await s.unequip(it.slot);
    } else if (s.owned.contains(it.id)) {
      await s.equip(it);
    } else {
      final ok = await s.buy(it);
      if (!ok) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('تحتاجين ${it.price - s.coins} عملة إضافية. أكملي دروسًا لتجمعيها 🪙')));
        }
        return;
      }
      await s.equip(it);
    }
    _refresh();
  }

  Future<void> _openChest() async {
    final r = await s.openChest();
    if (r == null || !mounted) return;
    Sfx.play('chest');
    await showDialog<void>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('🎁 صندوق الكنز', textAlign: TextAlign.center),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('🪙 +${r.coins}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          if (r.gems > 0) const Text('💎 +1', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          if (r.sticker != null) ...[
            const SizedBox(height: 8),
            Text(r.sticker!, style: const TextStyle(fontSize: 64)),
            const Text('ملصق جديد في ألبومك!'),
          ],
        ]),
        actions: [FilledButton(onPressed: () => Navigator.pop(d), child: const Text('رائع!'))],
      ),
    );
    _refresh();
  }

  Widget _body() {
    if (_tab == 'stickers') {
      final own = s.stickers;
      return GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 4,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        children: [
          for (final st in stickerAlbum)
            Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  color: own.contains(st) ? Brand.gold.withValues(alpha: .2) : Colors.grey.withValues(alpha: .12)),
              child: Text(own.contains(st) ? st : '❔', style: const TextStyle(fontSize: 34)),
            ),
        ],
      );
    }
    if (_tab == 'chest') {
      return Column(children: [
        const Text('🎁', style: TextStyle(fontSize: 72)),
        Text('لديكِ ${s.chests} صندوق', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const Text('تحصلين على صناديق بنيل ٣ نجوم أو بإكمال مهام اليوم الثلاث.', textAlign: TextAlign.center),
        const SizedBox(height: 10),
        FilledButton(onPressed: s.chests > 0 ? _openChest : null, child: const Text('افتحي صندوقًا')),
      ]);
    }
    final items = shopItems.where((e) => e.slot == _tab).toList();
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.25,
      children: [
        for (final it in items)
          Builder(builder: (_) {
            final owned = s.owned.contains(it.id);
            final eq = s.equipped[it.slot] == it.id;
            return Pressable(
              onTap: () => _tapItem(it),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: eq ? Brand.violet.withValues(alpha: .14) : Theme.of(context).colorScheme.surface,
                  border: Border.all(color: eq ? Brand.violet : Brand.violet.withValues(alpha: .15), width: 2),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(it.emoji, style: const TextStyle(fontSize: 34)),
                  Text(it.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(eq ? 'مُرتدى ✓' : owned ? 'ملكك • اضغطي للبس' : '🪙 ${it.price}',
                      style: TextStyle(fontSize: 12, color: eq ? Brand.violet : null, fontWeight: FontWeight.w700)),
                ]),
              ),
            );
          }),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final rc = _roomColors();
    return ListView(padding: const EdgeInsets.all(14), children: [
      Container(
        height: 280,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: rc),
        ),
        child: Stack(alignment: Alignment.center, children: [
          Positioned(top: 16, child: Text(_roomDeco(), style: const TextStyle(fontSize: 26))),
          Positioned(top: 12, right: 12, child: StatPill('🪙', '${s.coins}', light: false)),
          Positioned(top: 12, left: 12, child: StatPill('💎', '${s.gems}', light: false)),
          Positioned(bottom: 6, child: StyledMascot(store: s, size: 220)),
        ]),
      ),
      const SizedBox(height: 8),
      Center(
          child: Text('${s.str('name') ?? 'رغد'} • ${levelTitle(s.level)}',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
      const SizedBox(height: 8),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          for (final e in _tabs.entries)
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 8),
              child: ChoiceChip(
                label: Text(e.value),
                selected: _tab == e.key,
                onSelected: (_) => setState(() => _tab = e.key),
              ),
            ),
        ]),
      ),
      const SizedBox(height: 10),
      _body(),
    ]);
  }
}
