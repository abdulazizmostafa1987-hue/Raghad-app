import 'dart:math';
import 'package:flutter/material.dart';
import '../models.dart';
import '../progress_store.dart';
import '../screens.dart' show AccountPage;
import '../screens2.dart' show StudySessionPage, TutorPage;
import 'brand.dart';
import 'challenges_page.dart';
import 'exam_pages.dart';
import 'fx.dart';
import 'games.dart';
import 'sfx.dart';
import 'island_pages.dart';
import 'lesson_flow.dart';
import 'rewards.dart';
import 'room_page.dart';
import 'world_data.dart';

/// الغلاف الجديد للتطبيق: خمس تبويبات بهوية «عالم رغد».
class WorldShell extends StatefulWidget {
  const WorldShell({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  State<WorldShell> createState() => _WorldShellState();
}

class _WorldShellState extends State<WorldShell> {
  int _i = 0;
  late Content _c = widget.content;

  @override
  void initState() {
    super.initState();
    Sfx.attach(widget.store);
    Sfx.refresh();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _askName();
      await _checkLevel();
    });
  }

  @override
  void dispose() {
    Sfx.stopMusic();
    super.dispose();
  }

  Future<void> _checkLevel() async {
    final s = widget.store;
    final seen = s.getInt('seenLevel', 1);
    if (s.level > seen && mounted) {
      await s.putInt('seenLevel', s.level);
      Sfx.play('levelup');
      await showDialog<void>(
        context: context,
        builder: (d) => Stack(alignment: Alignment.center, children: [
          AlertDialog(
            title: const Text('🎉 مستوى جديد!', textAlign: TextAlign.center),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('المستوى ${s.level}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
              Text(levelTitle(s.level), style: const TextStyle(fontSize: 18)),
            ]),
            actions: [FilledButton(onPressed: () => Navigator.pop(d), child: const Text('رائع!'))],
          ),
          const IgnorePointer(child: ParticleBurst(count: 26, emojis: ['🎉', '⭐', '✨'])),
        ]),
      );
    } else if (s.level != seen) {
      await s.putInt('seenLevel', s.level);
    }
  }

  Future<void> _askName() async {
    if (widget.store.str('name') != null || !mounted) return;
    final c = TextEditingController();
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (d) => AlertDialog(
        title: const Row(children: [RaghadLogo(size: 40), SizedBox(width: 10), Expanded(child: Text('مرحبًا في عالم رغد!'))]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('ما اسمك أيتها المغامِرة؟'),
          const SizedBox(height: 10),
          TextField(controller: c, decoration: const InputDecoration(hintText: 'اسمك')),
        ]),
        actions: [FilledButton(onPressed: () => Navigator.pop(d), child: const Text('يلا نبدأ! 🚀'))],
      ),
    );
    final n = c.text.trim();
    c.dispose();
    await widget.store.putStr('name', n.isEmpty ? 'رغد' : n);
    if (mounted) setState(() {});
  }

  void _refresh() {
    setState(() {});
    _checkLevel();
  }

  Future<void> _toggleSound() async {
    final s = widget.store;
    await s.putFlag('soundOn', !s.flag('soundOn', def: true));
    await Sfx.refresh();
    if (mounted) setState(() {});
  }

  Future<void> _reload() async {
    final c = await Content.load(widget.store);
    if (mounted) setState(() => _c = c);
  }

  void _select(int v) {
    final s = widget.store;
    if (s.flag('focusMode') && (v == 2 || v == 3)) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('وضع التركيز مفعّل؛ التحديات والمكافآت متوقفة مؤقتًا.')));
      return;
    }
    Sfx.tap();
    setState(() => _i = v);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final islands = buildIslands(_c, s);
    final pages = <Widget>[
      HomeTab(store: s, content: _c, islands: islands, onChanged: _refresh, onGoTo: _select, onToggleSound: _toggleSound),
      IslandsPage(store: s, islands: islands, onChanged: _refresh),
      ChallengesPage(store: s, content: _c, islands: islands, onChanged: _refresh),
      RoomPage(store: s, onChanged: _refresh),
      AccountPage(store: s, content: _c, onChanged: _refresh, onReload: _reload),
    ];
    const titles = ['عالم رغد', 'خريطة المغامرة', 'التحديات', 'غرفة رغد', 'حسابي'];
    return Scaffold(
      appBar: _i == 0
          ? null
          : AppBar(
              title: Text(titles[_i]),
              actions: [
                Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Center(child: StatPill('🪙', '${s.coins}', light: false))),
                IconButton(
                  tooltip: 'الصوت',
                  icon: Icon(s.flag('soundOn', def: true) ? Icons.volume_up_rounded : Icons.volume_off_rounded),
                  onPressed: _toggleSound,
                ),
              ],
            ),
      body: SafeArea(top: _i == 0, child: pages[_i]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: _select,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map_rounded), label: 'الجزر'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events_rounded), label: 'التحديات'),
          NavigationDestination(icon: Icon(Icons.checkroom_outlined), selectedIcon: Icon(Icons.checkroom_rounded), label: 'رغد'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'حسابي'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({
    super.key,
    required this.store,
    required this.content,
    required this.islands,
    required this.onChanged,
    required this.onGoTo,
    required this.onToggleSound,
  });
  final ProgressStore store;
  final Content content;
  final List<Island> islands;
  final VoidCallback onChanged;
  final void Function(int) onGoTo;
  final VoidCallback onToggleSound;

  Future<void> _push(BuildContext c, Widget w) async {
    await Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));
    onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final s = store;
    final name = s.str('name') ?? 'رغد';
    final next = continuePoint(islands, s);
    final quests = s.todaysQuests();
    final all = content.allQuestions;
    final xpIn = s.xp % 100;
    return ListView(padding: const EdgeInsets.all(14), children: [
      // ---- الرأس ----
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: Brand.gradient,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [BoxShadow(color: Brand.violet.withValues(alpha: .35), blurRadius: 20, offset: const Offset(0, 10))],
        ),
        child: Column(children: [
          Row(children: [
            const Wordmark(size: 20),
            const Spacer(),
            StatPill('🔥', '${s.streak}'),
            IconButton(
              tooltip: 'الصوت',
              onPressed: onToggleSound,
              icon: Icon(s.flag('soundOn', def: true) ? Icons.volume_up_rounded : Icons.volume_off_rounded, color: Colors.white),
            ),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            SizedBox(width: 110, height: 110, child: StyledMascot(store: s, size: 110)),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('أهلًا يا $name 👋',
                    style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
                Text('المستوى ${s.level} • ${levelTitle(s.level)}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                      value: xpIn / 100, minHeight: 10, backgroundColor: Colors.white30, color: Brand.gold),
                ),
                Text('$xpIn / 100 للمستوى التالي', style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ]),
            ),
          ]),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            StatPill('🪙', '${s.coins}'),
            StatPill('💎', '${s.gems}'),
            StatPill('⭐', '${s.totalStars}'),
            StatPill('🎁', '${s.chests}'),
          ]),
        ]),
      ),
      const SizedBox(height: 8),
      // ---- كملي رحلتك ----
      if (next != null)
        GradientCard(
          colors: [next.island.c1, next.island.c2],
          onTap: () {
            final n = next.node;
            if (n.isBoss) {
              final qs = [...n.bossQuestions]..shuffle();
              _push(
                  context,
                  BossBattlePage(
                      store: s,
                      questions: qs,
                      bossName: 'زعيم ${next.island.name}',
                      bossEmoji: bossEmojis[next.island.id.hashCode.abs() % bossEmojis.length],
                      accent: next.island.c2,
                      nodeId: n.id));
            } else {
              _push(context, LessonFlowPage(lesson: n.lesson!, store: s, accent: next.island.c2, nodeId: n.id));
            }
          },
          child: Row(children: [
            Text(next.island.emoji, style: const TextStyle(fontSize: 40)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('كمّلي رحلتك', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
                Text(next.node.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                Text(next.island.name, style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ]),
            ),
            const Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 40),
          ]),
        ),
      // ---- مهام اليوم ----
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('🎯 مهام اليوم', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              const Spacer(),
              TextButton(onPressed: () => onGoTo(2), child: const Text('الكل')),
            ]),
            for (final q in quests)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(children: [
                  Text(s.questClaimed(q.id) ? '✅' : q.emoji, style: const TextStyle(fontSize: 20)),
                  const SizedBox(width: 8),
                  Expanded(child: Text(q.title)),
                  Text('${min(s.questProgress(q.id), q.goal)}/${q.goal}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ]),
              ),
          ]),
        ),
      ),
      // ---- أزرار سريعة ----
      Row(children: [
        Expanded(
          child: _Quick('⚡', 'تحدي اليوم', () {
            final d = DateTime.now();
            final qs = ([...all]..shuffle(Random(d.year * 10000 + d.month * 100 + d.day))).take(5).toList();
            _push(context, ExamPage(title: 'تحدي اليوم', questions: qs, store: s, seconds: 300));
          }, enabled: all.length >= 5),
        ),
        const SizedBox(width: 10),
        Expanded(child: _Quick('⏱️', 'جلسة مذاكرة', () => _push(context, StudySessionPage(store: s)))),
        const SizedBox(width: 10),
        Expanded(child: _Quick('🤖', 'اسألي رغد', () => _push(context, TutorPage(store: s, content: content)))),
      ]),
      const Padding(
          padding: EdgeInsets.only(top: 14, bottom: 6),
          child: Text('جزري', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18))),
      SizedBox(
        height: 128,
        child: ListView(scrollDirection: Axis.horizontal, children: [
          for (final i in islands.where((e) => !e.archive))
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 10),
              child: Pressable(
                onTap: () => _push(context, IslandPathPage(island: i, store: s)),
                child: Container(
                  width: 128,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [i.c1, i.c2]),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(i.emoji, style: const TextStyle(fontSize: 32)),
                    Text(i.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(value: i.progress(s), minHeight: 6, backgroundColor: Colors.white30, color: Colors.white),
                    ),
                  ]),
                ),
              ),
            ),
        ]),
      ),
      if (content.isSample)
        const Card(
          child: ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('المحتوى مساند وليس نسخة من الكتاب'),
            subtitle: Text('راجعي الكتب الرسمية للوزارة لاستكمال المنهج.'),
          ),
        ),
    ]);
  }
}

class _Quick extends StatelessWidget {
  const _Quick(this.emoji, this.label, this.onTap, {this.enabled = true});
  final String emoji;
  final String label;
  final VoidCallback onTap;
  final bool enabled;
  @override
  Widget build(BuildContext context) => Opacity(
        opacity: enabled ? 1 : .4,
        child: Pressable(
          onTap: enabled ? onTap : null,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: Brand.violet.withValues(alpha: .09),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Brand.violet.withValues(alpha: .18)),
            ),
            child: Column(children: [
              Text(emoji, style: const TextStyle(fontSize: 28)),
              const SizedBox(height: 4),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
            ]),
          ),
        ),
      );
}
