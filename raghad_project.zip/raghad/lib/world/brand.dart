import 'dart:math';
import 'package:flutter/material.dart';

/// الهوية البصرية لـ «عالم رغد»: ألوان، ثيم، شعار، ومكونات مشتركة.
class Brand {
  static const violet = Color(0xFF5B3CC4);
  static const violetLight = Color(0xFF8A5CF0);
  static const pink = Color(0xFFFF7EB6);
  static const gold = Color(0xFFFFC83D);
  static const mint = Color(0xFF2EC4B6);
  static const sky = Color(0xFF4CC9F0);
  static const ink = Color(0xFF241B4B);
  static const cream = Color(0xFFFFF8FD);

  static const gradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [violet, violetLight, pink],
  );

  static ThemeData theme(Brightness b) {
    final scheme = ColorScheme.fromSeed(seedColor: violet, brightness: b);
    final dark = b == Brightness.dark;
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF17122E) : cream,
      cardTheme: CardThemeData(
        elevation: 0,
        margin: const EdgeInsets.symmetric(vertical: 7),
        color: dark ? const Color(0xFF241D45) : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: scheme.primary.withValues(alpha: .10)),
        ),
      ),
      appBarTheme: const AppBarTheme(
          centerTitle: true, elevation: 0, scrolledUnderElevation: 0),
      navigationBarTheme: NavigationBarThemeData(
        height: 68,
        indicatorColor: scheme.primary.withValues(alpha: .16),
        labelTextStyle: WidgetStateProperty.all(
            const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(64, 52),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}

/// الشعار: كتاب مفتوح ونجمة ذهبية، مرسوم بالكود فيبقى حادًا بأي حجم.
class RaghadLogo extends StatelessWidget {
  const RaghadLogo({super.key, this.size = 96, this.withBackground = true});
  final double size;
  final bool withBackground;
  @override
  Widget build(BuildContext context) => CustomPaint(
      size: Size(size, size), painter: _LogoPainter(withBackground));
}

class _LogoPainter extends CustomPainter {
  _LogoPainter(this.bg);
  final bool bg;

  Path _shield(double w, double h, double inset) {
    final l = w * (.5 - .29) + inset, r = w * (.5 + .29) - inset;
    final top = h * .13 + inset, bot = h * .92 - inset * 1.4;
    return Path()
      ..moveTo(l, top + h * .05)
      ..quadraticBezierTo(w * .5, top - h * .06, r, top + h * .05)
      ..quadraticBezierTo(r + w * .01, h * .6, w * .5, bot)
      ..quadraticBezierTo(l - w * .01, h * .6, l, top + h * .05)
      ..close();
  }

  Path _star(double cx, double cy, double r1, double r2) {
    final p = Path();
    for (var i = 0; i < 10; i++) {
      final a = (-90 + i * 36) * pi / 180;
      final r = i.isEven ? r1 : r2;
      final o = Offset(cx + r * cos(a), cy + r * sin(a));
      i == 0 ? p.moveTo(o.dx, o.dy) : p.lineTo(o.dx, o.dy);
    }
    return p..close();
  }

  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    if (bg) {
      c.drawRRect(RRect.fromRectAndRadius(Offset.zero & s, Radius.circular(w * .225)),
          Paint()..shader = Brand.gradient.createShader(Offset.zero & s));
    }
    // الدرع
    c.drawPath(_shield(w, h, 0), Paint()..color = Brand.gold);
    c.drawPath(_shield(w, h, w * .03), Paint()..color = const Color(0xFFFFEC96));
    final inner = _shield(w, h, w * .055);
    c.drawPath(inner, Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF78CDFF), Color(0xFFBEA0FF)]).createShader(Offset.zero & s));
    c.save();
    c.clipPath(inner);
    // رغد
    final cx = w / 2, fy = h * .50, u = w / 1024 * .74;
    final hair = Paint()..color = const Color(0xFF462878);
    c.drawArc(Rect.fromLTWH(cx - 230 * u, fy + 120 * u, 460 * u, 400 * u), pi, pi, true, Paint()..color = const Color(0xFFFF5E8A));
    c.drawCircle(Offset(cx - 170 * u, fy - 205 * u), 80 * u, hair);
    c.drawCircle(Offset(cx + 170 * u, fy - 205 * u), 80 * u, hair);
    c.drawCircle(Offset(cx - 170 * u, fy - 205 * u), 45 * u, Paint()..color = Brand.pink);
    c.drawCircle(Offset(cx + 170 * u, fy - 205 * u), 45 * u, Paint()..color = Brand.pink);
    c.drawOval(Rect.fromLTRB(cx - 215 * u, fy - 240 * u, cx + 215 * u, fy + 190 * u), Paint()..color = const Color(0xFFFFDFC4));
    c.drawArc(Rect.fromLTRB(cx - 225 * u, fy - 260 * u, cx + 225 * u, fy + 60 * u), pi, pi, true, hair);
    c.drawPath(
        Path()
          ..moveTo(cx - 225 * u, fy - 100 * u)
          ..lineTo(cx - 120 * u, fy - 30 * u)
          ..lineTo(cx, fy - 110 * u)
          ..lineTo(cx + 120 * u, fy - 30 * u)
          ..lineTo(cx + 225 * u, fy - 100 * u)
          ..close(),
        hair);
    // التاج
    final crown = Path()
      ..moveTo(cx - 110 * u, fy - 235 * u)
      ..lineTo(cx - 110 * u, fy - 340 * u)
      ..lineTo(cx - 55 * u, fy - 290 * u)
      ..lineTo(cx, fy - 370 * u)
      ..lineTo(cx + 55 * u, fy - 290 * u)
      ..lineTo(cx + 110 * u, fy - 340 * u)
      ..lineTo(cx + 110 * u, fy - 235 * u)
      ..close();
    c.drawPath(crown, Paint()..color = Brand.gold);
    c.drawCircle(Offset(cx, fy - 370 * u), 16 * u, Paint()..color = Brand.sky);
    // العيون والابتسامة
    for (final ex in [cx - 95 * u, cx + 95 * u]) {
      c.drawOval(Rect.fromLTRB(ex - 42 * u, fy - 10 * u, ex + 42 * u, fy + 84 * u), Paint()..color = Colors.white);
      c.drawOval(Rect.fromLTRB(ex - 28 * u, fy + 4 * u, ex + 28 * u, fy + 78 * u), Paint()..color = const Color(0xFF3C236E));
      c.drawCircle(Offset(ex - 4 * u, fy + 24 * u), 10 * u, Paint()..color = Colors.white);
    }
    for (final bx in [cx - 150 * u, cx + 150 * u]) {
      c.drawOval(Rect.fromLTRB(bx - 38 * u, fy + 95 * u, bx + 38 * u, fy + 140 * u), Paint()..color = const Color(0xFFFFA0AF));
    }
    c.drawArc(Rect.fromLTRB(cx - 70 * u, fy + 70 * u, cx + 70 * u, fy + 170 * u), .35, 2.4, false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = 13 * u
          ..color = const Color(0xFFC8465A));
    c.drawPath(_star(cx, fy + 255 * u, 52 * u, 22 * u), Paint()..color = Brand.gold);
    c.restore();
  }

  @override
  bool shouldRepaint(covariant _LogoPainter o) => o.bg != bg;
}

/// اسم التطبيق مع الشعار.
class Wordmark extends StatelessWidget {
  const Wordmark({super.key, this.light = true, this.size = 22});
  final bool light;
  final double size;
  @override
  Widget build(BuildContext context) {
    final col = light ? Colors.white : Brand.violet;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      RaghadLogo(size: size * 1.5),
      const SizedBox(width: 8),
      Text('عالم رغد',
          style: TextStyle(
              color: col, fontSize: size, fontWeight: FontWeight.w900)),
    ]);
  }
}

/// ضغطة بتأثير ارتداد خفيف.
class Pressable extends StatefulWidget {
  const Pressable({super.key, required this.child, this.onTap});
  final Widget child;
  final VoidCallback? onTap;
  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _down = true),
        onTapCancel: () => setState(() => _down = false),
        onTapUp: (_) => setState(() => _down = false),
        onTap: widget.onTap,
        child: AnimatedScale(
            scale: _down ? .96 : 1,
            duration: const Duration(milliseconds: 110),
            child: widget.child),
      );
}

/// بطاقة ملونة بتدرج.
class GradientCard extends StatelessWidget {
  const GradientCard(
      {super.key,
      required this.colors,
      required this.child,
      this.onTap,
      this.padding = const EdgeInsets.all(16),
      this.radius = 26});
  final List<Color> colors;
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final double radius;
  @override
  Widget build(BuildContext context) => Pressable(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 7),
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: colors),
            boxShadow: [
              BoxShadow(
                  color: colors.last.withValues(alpha: .30),
                  blurRadius: 16,
                  offset: const Offset(0, 8))
            ],
          ),
          child: child,
        ),
      );
}

/// حبة إحصاء صغيرة (عملات، نجوم...).
class StatPill extends StatelessWidget {
  const StatPill(this.emoji, this.value, {super.key, this.light = true});
  final String emoji;
  final String value;
  final bool light;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
        decoration: BoxDecoration(
          color: light
              ? Colors.white.withValues(alpha: .20)
              : Brand.violet.withValues(alpha: .10),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text(emoji, style: const TextStyle(fontSize: 15)),
          const SizedBox(width: 5),
          Text(value,
              style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: light ? Colors.white : Brand.violet)),
        ]),
      );
}

/// نجوم صغيرة 0..3.
class StarRow extends StatelessWidget {
  const StarRow(this.stars, {super.key, this.size = 18});
  final int stars;
  final double size;
  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (var i = 0; i < 3; i++)
            Icon(i < stars ? Icons.star_rounded : Icons.star_outline_rounded,
                size: size,
                color: i < stars ? Brand.gold : Colors.grey.shade400),
        ],
      );
}

/// زر بنمط الألعاب: سميك بظل سفلي ينضغط عند اللمس.
class GameButton extends StatefulWidget {
  const GameButton({super.key, required this.label, required this.onPressed, this.color = Brand.violet, this.textColor = Colors.white, this.icon});
  final String label;
  final VoidCallback? onPressed;
  final Color color;
  final Color textColor;
  final IconData? icon;
  @override
  State<GameButton> createState() => _GameButtonState();
}

class _GameButtonState extends State<GameButton> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    final on = widget.onPressed != null;
    final base = on ? widget.color : Colors.grey.shade400;
    final dark = HSLColor.fromColor(base).withLightness((HSLColor.fromColor(base).lightness - .16).clamp(0.0, 1.0)).toColor();
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: on ? (_) => setState(() => _down = true) : null,
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onPressed,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        margin: EdgeInsets.only(top: _down ? 5 : 0, bottom: _down ? 0 : 5),
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        decoration: BoxDecoration(
          color: base,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: dark, offset: Offset(0, _down ? 0 : 5))],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          if (widget.icon != null) ...[Icon(widget.icon, color: widget.textColor), const SizedBox(width: 8)],
          Text(widget.label, style: TextStyle(color: widget.textColor, fontSize: 18, fontWeight: FontWeight.w900)),
        ]),
      ),
    );
  }
}
