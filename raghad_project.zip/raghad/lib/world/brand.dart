import 'dart:math';
import 'package:flutter/material.dart';

/// الهوية البصرية لـ «عالم رغد»: ألوان، ثيم، شعار، ومكونات مشتركة.
class Brand {
  static const violet = Color(0xFF5B3CC4);
  static const violetLight = Color(0xFF8A5CF0);
  static const pink = Color(0xFFFF7EB6);
  static const gold = Color(0xFFFFC83D);
  static const mint = Color(0xFF2EC4B6);
  static const sky = Color(0xFF4CC9F0);
  static const ink = Color(0xFF241B4B);
  static const cream = Color(0xFFFFF8FD);

  static const gradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [violet, violetLight, pink],
  );

  static ThemeData theme(Brightness b) {
    final scheme = ColorScheme.fromSeed(seedColor: violet, brightness: b);
    final dark = b == Brightness.dark;
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF17122E) : cream,
      cardTheme: CardThemeData(
        elevation: 0,
        margin: const EdgeInsets.symmetric(vertical: 7),
        color: dark ? const Color(0xFF241D45) : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: scheme.primary.withValues(alpha: .10)),
        ),
      ),
      appBarTheme: const AppBarTheme(
          centerTitle: true, elevation: 0, scrolledUnderElevation: 0),
      navigationBarTheme: NavigationBarThemeData(
        height: 68,
        indicatorColor: scheme.primary.withValues(alpha: .16),
        labelTextStyle: WidgetStateProperty.all(
            const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(64, 52),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}

/// الشعار: كتاب مفتوح ونجمة ذهبية، مرسوم بالكود فيبقى حادًا بأي حجم.
class RaghadLogo extends StatelessWidget {
  const RaghadLogo({super.key, this.size = 96, this.withBackground = true});
  final double size;
  final bool withBackground;
  @override
  Widget build(BuildContext context) => CustomPaint(
      size: Size(size, size), painter: _LogoPainter(withBackground));
}

class _LogoPainter extends CustomPainter {
  _LogoPainter(this.bg);
  final bool bg;

  Path _star(double cx, double cy, double r1, double r2) {
    final p = Path();
    for (var i = 0; i < 10; i++) {
      final a = (-90 + i * 36) * pi / 180;
      final r = i.isEven ? r1 : r2;
      final o = Offset(cx + r * cos(a), cy + r * sin(a));
      i == 0 ? p.moveTo(o.dx, o.dy) : p.lineTo(o.dx, o.dy);
    }
    return p..close();
  }

  @override
  void paint(Canvas c, Size s) {
    final u = s.width / 1024;
    if (bg) {
      final rr = RRect.fromRectAndRadius(
          Offset.zero & s, Radius.circular(s.width * .225));
      c.drawRRect(
          rr,
          Paint()
            ..shader = Brand.gradient.createShader(Offset.zero & s));
    }
    final cx = s.width / 2;
    // الكتاب
    final left = Path()
      ..moveTo(cx - 10 * u, 630 * u)
      ..lineTo(cx - 330 * u, 570 * u)
      ..lineTo(cx - 350 * u, 740 * u)
      ..lineTo(cx - 10 * u, 830 * u)
      ..close();
    final right = Path()
      ..moveTo(cx + 10 * u, 630 * u)
      ..lineTo(cx + 330 * u, 570 * u)
      ..lineTo(cx + 350 * u, 740 * u)
      ..lineTo(cx + 10 * u, 830 * u)
      ..close();
    c.drawPath(left, Paint()..color = Colors.white);
    c.drawPath(right, Paint()..color = const Color(0xFFEBE1FF));
    c.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTRB(cx - 12 * u, 626 * u, cx + 12 * u, 834 * u),
            Radius.circular(8 * u)),
        Paint()..color = const Color(0xFFC8B4F0));
    // النجمة
    c.drawPath(_star(cx, 400 * u, 250 * u, 112 * u),
        Paint()..color = Brand.gold);
    c.drawPath(_star(cx, 400 * u, 190 * u, 84 * u),
        Paint()..color = const Color(0xFFFFDE6E));
    // لمعات
    final sp = Paint()..color = Colors.white.withValues(alpha: .93);
    for (final t in const [
      [250.0, 300.0, 34.0],
      [790.0, 250.0, 26.0],
      [820.0, 520.0, 22.0],
      [210.0, 520.0, 20.0],
    ]) {
      final x = t[0] * u, y = t[1] * u, r = t[2] * u;
      c.drawPath(
          Path()
            ..moveTo(x, y - r * 2)
            ..lineTo(x + r * .5, y - r * .5)
            ..lineTo(x + r * 2, y)
            ..lineTo(x + r * .5, y + r * .5)
            ..lineTo(x, y + r * 2)
            ..lineTo(x - r * .5, y + r * .5)
            ..lineTo(x - r * 2, y)
            ..lineTo(x - r * .5, y - r * .5)
            ..close(),
          sp);
    }
  }

  @override
  bool shouldRepaint(covariant _LogoPainter o) => o.bg != bg;
}

/// اسم التطبيق مع الشعار.
class Wordmark extends StatelessWidget {
  const Wordmark({super.key, this.light = true, this.size = 22});
  final bool light;
  final double size;
  @override
  Widget build(BuildContext context) {
    final col = light ? Colors.white : Brand.violet;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      RaghadLogo(size: size * 1.5),
      const SizedBox(width: 8),
      Text('عالم رغد',
          style: TextStyle(
              color: col, fontSize: size, fontWeight: FontWeight.w900)),
    ]);
  }
}

/// ضغطة بتأثير ارتداد خفيف.
class Pressable extends StatefulWidget {
  const Pressable({super.key, required this.child, this.onTap});
  final Widget child;
  final VoidCallback? onTap;
  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _down = true),
        onTapCancel: () => setState(() => _down = false),
        onTapUp: (_) => setState(() => _down = false),
        onTap: widget.onTap,
        child: AnimatedScale(
            scale: _down ? .96 : 1,
            duration: const Duration(milliseconds: 110),
            child: widget.child),
      );
}

/// بطاقة ملونة بتدرج.
class GradientCard extends StatelessWidget {
  const GradientCard(
      {super.key,
      required this.colors,
      required this.child,
      this.onTap,
      this.padding = const EdgeInsets.all(16),
      this.radius = 26});
  final List<Color> colors;
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final double radius;
  @override
  Widget build(BuildContext context) => Pressable(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 7),
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: colors),
            boxShadow: [
              BoxShadow(
                  color: colors.last.withValues(alpha: .30),
                  blurRadius: 16,
                  offset: const Offset(0, 8))
            ],
          ),
          child: child,
        ),
      );
}

/// حبة إحصاء صغيرة (عملات، نجوم...).
class StatPill extends StatelessWidget {
  const StatPill(this.emoji, this.value, {super.key, this.light = true});
  final String emoji;
  final String value;
  final bool light;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
        decoration: BoxDecoration(
          color: light
              ? Colors.white.withValues(alpha: .20)
              : Brand.violet.withValues(alpha: .10),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text(emoji, style: const TextStyle(fontSize: 15)),
          const SizedBox(width: 5),
          Text(value,
              style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: light ? Colors.white : Brand.violet)),
        ]),
      );
}

/// نجوم صغيرة 0..3.
class StarRow extends StatelessWidget {
  const StarRow(this.stars, {super.key, this.size = 18});
  final int stars;
  final double size;
  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (var i = 0; i < 3; i++)
            Icon(i < stars ? Icons.star_rounded : Icons.star_outline_rounded,
                size: size,
                color: i < stars ? Brand.gold : Colors.grey.shade400),
        ],
      );
}
