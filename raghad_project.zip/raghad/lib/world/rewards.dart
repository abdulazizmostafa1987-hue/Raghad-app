import 'dart:convert';
import 'dart:math';
import '../progress_store.dart';

/// عناصر المتجر: slot = hat | glasses | cape | room | color
class ShopItem {
  const ShopItem(this.id, this.name, this.slot, this.price, this.emoji);
  final String id;
  final String name;
  final String slot;
  final int price;
  final String emoji;
}

const shopItems = <ShopItem>[
  ShopItem('hat_bow', 'فيونكة', 'hat', 40, '🎀'),
  ShopItem('hat_grad', 'قبعة التخرج', 'hat', 60, '🎓'),
  ShopItem('hat_wizard', 'قبعة الساحرة', 'hat', 90, '🧙'),
  ShopItem('hat_crown', 'التاج الملكي', 'hat', 140, '👑'),
  ShopItem('gl_round', 'نظارة العالمة', 'glasses', 50, '👓'),
  ShopItem('gl_star', 'نظارة النجوم', 'glasses', 80, '🤩'),
  ShopItem('gl_cool', 'نظارة شمس', 'glasses', 70, '😎'),
  ShopItem('cape_hero', 'عباءة البطلة', 'cape', 100, '🦸'),
  ShopItem('cape_rainbow', 'عباءة قوس قزح', 'cape', 160, '🌈'),
  ShopItem('room_stars', 'غرفة النجوم', 'room', 80, '🌌'),
  ShopItem('room_garden', 'حديقة الزهور', 'room', 100, '🌷'),
  ShopItem('room_beach', 'شاطئ الأحلام', 'room', 120, '🏖️'),
  ShopItem('color_1', 'لون وردي', 'color', 30, '🩷'),
  ShopItem('color_2', 'لون تركواز', 'color', 30, '🩵'),
  ShopItem('color_3', 'لون ذهبي', 'color', 45, '💛'),
  ShopItem('color_4', 'لون أخضر', 'color', 30, '💚'),
];

const stickerAlbum = <String>[
  '🦄', '🐬', '🦋', '🌟', '🚀', '🎨', '🧪', '📚', '🔭', '🧩', '🎻', '🌍',
  '🐼', '🦊', '🐙', '🍉', '🏆', '💎', '🎈', '🪁', '🧁', '🌺', '🐢', '🦉',
];

const levelTitles = <String>[
  'مستكشفة مبتدئة',
  'مستكشفة نشيطة',
  'رحّالة المعرفة',
  'صائدة النجوم',
  'عالمة صغيرة',
  'مغامرة ذكية',
  'بطلة الجزر',
  'قائدة الفريق',
  'حكيمة المدينة',
  'أسطورة رغد',
];

String levelTitle(int level) =>
    levelTitles[min(max(level - 1, 0) ~/ 2, levelTitles.length - 1)];

class QuestDef {
  const QuestDef(this.id, this.title, this.goal, this.coins, this.emoji);
  final String id;
  final String title;
  final int goal;
  final int coins;
  final String emoji;
}

const questPool = <QuestDef>[
  QuestDef('lessons', 'أكملي درسين', 2, 20, '📘'),
  QuestDef('correct', 'أجيبي ١٠ إجابات صحيحة', 10, 25, '✅'),
  QuestDef('stars', 'اجمعي ٤ نجوم', 4, 20, '⭐'),
  QuestDef('games', 'العبي لعبة واحدة', 1, 15, '🎮'),
  QuestDef('practice', 'حلّي ٥ مسائل تدريب', 5, 20, '🧮'),
  QuestDef('exam', 'ادخلي امتحانًا واحدًا', 1, 30, '📝'),
];

class LessonReward {
  const LessonReward(
      {required this.stars,
      required this.coins,
      required this.gems,
      required this.chest,
      required this.firstTime,
      required this.newStars});
  final int stars;
  final int coins;
  final int gems;
  final bool chest;
  final bool firstTime;
  final int newStars;
}

class ChestResult {
  const ChestResult(this.coins, this.gems, this.sticker);
  final int coins;
  final int gems;
  final String? sticker;
}

class Achievement {
  const Achievement(this.title, this.hint, this.emoji, this.test);
  final String title;
  final String hint;
  final String emoji;
  final bool Function(ProgressStore s) test;
}

String _today() {
  final d = DateTime.now();
  return '${d.year}-${d.month}-${d.day}';
}

int starsForPercent(int p) => p >= 90 ? 3 : p >= 70 ? 2 : p >= 50 ? 1 : 0;

String gradeLabel(int p) {
  if (p >= 90) return 'ممتاز';
  if (p >= 80) return 'جيد جدًا';
  if (p >= 65) return 'جيد';
  if (p >= 50) return 'مقبول';
  return 'تحتاج مراجعة';
}

extension WorldState on ProgressStore {
  // ---- العملات والجواهر ----
  int get coins => getInt('coins', 0);
  int get gems => getInt('gems', 0);
  Future<void> addCoins(int n) => putInt('coins', coins + n);
  Future<void> addGems(int n) => putInt('gems', gems + n);
  Future<bool> spendCoins(int n) async {
    if (coins < n) return false;
    await putInt('coins', coins - n);
    return true;
  }

  // ---- النجوم لكل محطة ----
  int starsOf(String nodeId) => (map('nodeStars')[nodeId] as int?) ?? 0;
  int get totalStars =>
      map('nodeStars').values.fold<int>(0, (a, b) => a + (b as int));
  int get completedNodes =>
      map('nodeStars').values.where((v) => (v as int) > 0).length;

  // ---- عدّادات عامة ----
  int get totalCorrect => getInt('totalCorrect', 0);
  int get gamesPlayed => getInt('gamesPlayed', 0);
  int get examsTaken => getInt('examsTaken', 0);
  int get chests => getInt('chests', 0);

  Future<void> noteGamePlayed() async {
    await putInt('gamesPlayed', gamesPlayed + 1);
    await bumpQuest('games', 1);
  }

  // ---- المهام اليومية ----
  List<QuestDef> todaysQuests() {
    final d = DateTime.now();
    final r = Random(d.year * 10000 + d.month * 100 + d.day);
    final pool = [...questPool]..shuffle(r);
    return pool.take(3).toList();
  }

  Map<String, dynamic> _questState() {
    final m = map('quests');
    if (m['date'] != _today()) {
      return {'date': _today(), 'progress': <String, dynamic>{}, 'claimed': <dynamic>[]};
    }
    return m;
  }

  int questProgress(String id) =>
      ((_questState()['progress'] as Map)[id] as int?) ?? 0;
  bool questClaimed(String id) =>
      (_questState()['claimed'] as List).contains(id);

  Future<void> bumpQuest(String id, int n) async {
    final m = _questState();
    final p = Map<String, dynamic>.from(m['progress'] as Map);
    p[id] = ((p[id] as int?) ?? 0) + n;
    m['progress'] = p;
    await putMap('quests', m);
  }

  Future<int> claimQuest(QuestDef q) async {
    if (questClaimed(q.id) || questProgress(q.id) < q.goal) return 0;
    final m = _questState();
    final c = List<dynamic>.from(m['claimed'] as List)..add(q.id);
    m['claimed'] = c;
    await putMap('quests', m);
    await addCoins(q.coins);
    // إتمام المهام الثلاث يمنح صندوقًا.
    final all = todaysQuests().every((x) => c.contains(x.id));
    if (all) await putInt('chests', chests + 1);
    return q.coins;
  }

  // ---- مكافأة إنهاء محطة ----
  Future<LessonReward> rewardNode({
    required String nodeId,
    required int correct,
    required int total,
    bool boss = false,
  }) async {
    final percent = total == 0 ? 0 : (correct * 100 / total).round();
    final stars = starsForPercent(percent);
    final old = starsOf(nodeId);
    final first = old == 0 && stars > 0;
    final newStars = max(0, stars - old);
    if (stars > old) {
      final m = map('nodeStars');
      m[nodeId] = stars;
      await putMap('nodeStars', m);
    }
    var coinsEarned = correct * 2 + stars * 5 + (first ? 10 : 0);
    if (boss) coinsEarned = (coinsEarned * 1.5).round();
    var gemsEarned = 0;
    var chest = false;
    if (stars == 3 && old < 3) {
      gemsEarned = boss ? 3 : 1;
      chest = true;
      await putInt('chests', chests + 1);
    }
    await addCoins(coinsEarned);
    if (gemsEarned > 0) await addGems(gemsEarned);
    await putInt('totalCorrect', totalCorrect + correct);
    await bumpQuest('correct', correct);
    await bumpQuest('lessons', 1);
    if (newStars > 0) await bumpQuest('stars', newStars);
    return LessonReward(
        stars: stars,
        coins: coinsEarned,
        gems: gemsEarned,
        chest: chest,
        firstTime: first,
        newStars: newStars);
  }

  // ---- صندوق الكنز ----
  Future<ChestResult?> openChest([Random? rng]) async {
    if (chests <= 0) return null;
    final r = rng ?? Random();
    await putInt('chests', chests - 1);
    final coinsWon = 15 + r.nextInt(36);
    final gemsWon = r.nextInt(4) == 0 ? 1 : 0;
    final owned = stickers;
    final free = stickerAlbum.where((s) => !owned.contains(s)).toList();
    String? sticker;
    if (free.isNotEmpty && r.nextInt(100) < 70) {
      sticker = free[r.nextInt(free.length)];
      await putStr('stickers', jsonEncode([...owned, sticker]));
    }
    await addCoins(coinsWon);
    if (gemsWon > 0) await addGems(gemsWon);
    return ChestResult(coinsWon, gemsWon, sticker);
  }

  Set<String> get stickers {
    final s = str('stickers');
    if (s == null) return <String>{};
    return (jsonDecode(s) as List).cast<String>().toSet();
  }

  // ---- المتجر والملابس ----
  Set<String> get owned => map('owned').keys.toSet();
  Map<String, dynamic> get equipped => map('equipped');
  Future<bool> buy(ShopItem it) async {
    if (owned.contains(it.id)) return true;
    if (!await spendCoins(it.price)) return false;
    final m = map('owned');
    m[it.id] = true;
    await putMap('owned', m);
    return true;
  }

  Future<void> equip(ShopItem it) async {
    if (!owned.contains(it.id)) return;
    final m = equipped;
    m[it.slot] = it.id;
    await putMap('equipped', m);
    if (it.slot == 'color') {
      await setMascot(int.tryParse(it.id.split('_').last) ?? 0);
    }
  }

  Future<void> unequip(String slot) async {
    final m = equipped..remove(slot);
    await putMap('equipped', m);
    if (slot == 'color') await setMascot(0);
  }

  // ---- سجل الامتحانات ----
  List<Map<String, dynamic>> get examLog {
    final s = str('examLog');
    if (s == null) return [];
    return (jsonDecode(s) as List).cast<Map<String, dynamic>>();
  }

  Future<void> logExam(String title, int percent, int correct, int total) async {
    final l = examLog
      ..add({
        'title': title,
        'percent': percent,
        'correct': correct,
        'total': total,
        'at': DateTime.now().toIso8601String(),
      });
    if (l.length > 60) l.removeRange(0, l.length - 60);
    await putStr('examLog', jsonEncode(l));
    await putInt('examsTaken', examsTaken + 1);
    await bumpQuest('exam', 1);
    final coinsWon = (percent / 5).round();
    await addCoins(coinsWon);
  }

  int get bestExam =>
      examLog.fold<int>(0, (a, e) => max(a, (e['percent'] as int)));
}

final achievementList = <Achievement>[
  Achievement('الخطوة الأولى', 'أكملي أول محطة', '👣', (s) => s.completedNodes >= 1),
  Achievement('مستكشفة', 'أكملي ٥ محطات', '🧭', (s) => s.completedNodes >= 5),
  Achievement('رحّالة', 'أكملي ١٥ محطة', '🗺️', (s) => s.completedNodes >= 15),
  Achievement('جامعة النجوم', 'اجمعي ١٠ نجوم', '⭐', (s) => s.totalStars >= 10),
  Achievement('سماء مرصّعة', 'اجمعي ٥٠ نجمة', '🌠', (s) => s.totalStars >= 50),
  Achievement('مجرّة كاملة', 'اجمعي ١٥٠ نجمة', '🌌', (s) => s.totalStars >= 150),
  Achievement('نشيطة', 'سلسلة ٣ أيام', '🔥', (s) => s.streak >= 3),
  Achievement('مثابرة', 'سلسلة ٧ أيام', '💪', (s) => s.streak >= 7),
  Achievement('لا تتوقف', 'سلسلة ١٤ يومًا', '🚀', (s) => s.streak >= 14),
  Achievement('مئة إجابة', '١٠٠ إجابة صحيحة', '💯', (s) => s.totalCorrect >= 100),
  Achievement('خمسمئة إجابة', '٥٠٠ إجابة صحيحة', '🧠', (s) => s.totalCorrect >= 500),
  Achievement('جامعة العملات', 'اجمعي ٢٠٠ عملة', '🪙', (s) => s.coins >= 200),
  Achievement('صائدة الجواهر', 'اجمعي ٥ جواهر', '💎', (s) => s.gems >= 5),
  Achievement('جامعة الملصقات', 'اجمعي ٦ ملصقات', '🖼️', (s) => s.stickers.length >= 6),
  Achievement('ألبوم كامل', 'اجمعي ١٢ ملصقًا', '📒', (s) => s.stickers.length >= 12),
  Achievement('أنيقة', 'اشتري ٣ عناصر للمتجر', '🛍️', (s) => s.owned.length >= 3),
  Achievement('لاعبة', 'العبي ٥ ألعاب', '🎮', (s) => s.gamesPlayed >= 5),
  Achievement('مختبِرة', 'ادخلي أول امتحان', '📝', (s) => s.examsTaken >= 1),
  Achievement('متفوقة', 'احصلي على ٩٠٪ في امتحان', '🏅', (s) => s.bestExam >= 90),
  Achievement('مستوى ٥', 'اوصلي للمستوى ٥', '🥇', (s) => s.level >= 5),
  Achievement('مستوى ١٠', 'اوصلي للمستوى ١٠', '🏆', (s) => s.level >= 10),
  Achievement('مجتهدة', 'ذاكري ٦٠ دقيقة', '⏱️', (s) => s.studyMinutes >= 60),
];
