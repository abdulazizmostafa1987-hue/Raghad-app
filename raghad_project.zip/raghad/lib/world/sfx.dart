import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import '../progress_store.dart';

/// مؤثرات صوتية وموسيقى. كل الاستدعاءات آمنة: أي خطأ في المشغّل يُتجاهل.
class Sfx {
  static bool disabled = false; // للاختبارات
  static ProgressStore? _store;
  static final Map<String, AudioPlayer> _pool = {};
  static AudioPlayer? _music;
  static bool _musicOn = false;

  static void attach(ProgressStore s) => _store = s;

  static bool get soundOn => _store?.flag('soundOn', def: true) ?? true;
  static bool get musicOn => _store?.flag('musicOn', def: true) ?? true;
  static bool get haptics => _store?.flag('hapticsOn', def: true) ?? true;

  static Future<void> play(String name, {double volume = 1}) async {
    if (disabled || !soundOn) return;
    try {
      final p = _pool.putIfAbsent(name, () {
        final a = AudioPlayer();
        a.setReleaseMode(ReleaseMode.stop);
        return a;
      });
      await p.stop();
      await p.play(AssetSource('audio/$name.wav'), volume: volume);
    } catch (_) {}
  }

  static void tap() {
    play('tap', volume: .6);
    if (!disabled && haptics) HapticFeedback.selectionClick();
  }

  static void correct({int combo = 0}) {
    play(combo >= 3 ? 'combo' : 'correct');
    if (!disabled && haptics) HapticFeedback.mediumImpact();
  }

  static void wrong() {
    play('wrong', volume: .8);
    if (!disabled && haptics) HapticFeedback.heavyImpact();
  }

  static Future<void> startMusic() async {
    if (disabled || !soundOn || !musicOn || _musicOn) return;
    try {
      _music ??= AudioPlayer();
      await _music!.setReleaseMode(ReleaseMode.loop);
      await _music!.setVolume(.22);
      await _music!.play(AssetSource('audio/music.wav'));
      _musicOn = true;
    } catch (_) {}
  }

  static Future<void> stopMusic() async {
    try {
      await _music?.stop();
    } catch (_) {}
    _musicOn = false;
  }

  /// يُستدعى عند تغيير إعدادات الصوت.
  static Future<void> refresh() async {
    if (soundOn && musicOn) {
      await startMusic();
    } else {
      await stopMusic();
    }
  }
}
