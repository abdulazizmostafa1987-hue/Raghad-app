import 'dart:math';
import '../models.dart';

int gcd(int a, int b) => b == 0 ? a : gcd(b, a % b);
int lcm(int a, int b) => a ~/ gcd(a, b) * b;

/// مولّد أسئلة رياضيات لا ينتهي: كل سؤال إجابته محسوبة بالكود وتفسيره خطوة بخطوة.
class MathPractice {
  static int _serial = 0;

  static String _id(String kind) => 'gen-$kind-${_serial++}';

  static Question _fill(String kind, String text, String answer, String expl,
      {List<String> extra = const [], int level = 1}) {
    return Question(
      id: _id(kind),
      type: 'fill',
      text: text,
      options: const [],
      answer: 0,
      difficulty: level,
      explanation: expl,
      accepted: [answer, ...extra],
    );
  }

  static Question _mcq(Random r, String kind, String text, int correct,
      String expl, {int level = 1, int spread = 4}) {
    final opts = <int>{correct};
    var guard = 0;
    while (opts.length < 4 && guard++ < 60) {
      final d = 1 + r.nextInt(spread);
      final v = r.nextBool() ? correct + d : correct - d;
      if (v > 0) opts.add(v);
    }
    final l = opts.toList()..shuffle(r);
    while (l.length < 4) {
      l.add(correct + l.length * 7);
    }
    return Question(
      id: _id(kind),
      type: 'mcq',
      text: text,
      options: l.map((e) => '$e').toList(),
      answer: l.indexOf(correct),
      difficulty: level,
      explanation: expl,
    );
  }

  static Question _tf(Random r, String kind, String text, bool truth, String expl,
      {int level = 1}) {
    return Question(
      id: _id(kind),
      type: 'tf',
      text: text,
      options: const ['صح', 'خطأ'],
      answer: truth ? 0 : 1,
      difficulty: level,
      explanation: expl,
    );
  }

  static List<int> _factorsOf(int n) =>
      [for (var i = 1; i <= n; i++) if (n % i == 0) i];

  /// نوع سؤال محدد بالرقم (0..11).
  static Question one(Random r, int kind, {int level = 1}) {
    final big = level >= 2;
    switch (kind) {
      case 0: // ع.م.أ
        final g = [2, 3, 4, 5, 6, 8, 9, 12][r.nextInt(8)];
        final a = g * (2 + r.nextInt(big ? 9 : 5));
        var b = g * (2 + r.nextInt(big ? 9 : 5));
        if (a == b) b += g;
        final res = gcd(a, b);
        return _fill('gcf', 'ما العامل المشترك الأكبر للعددين $a و $b ؟', '$res',
            'عوامل $a: ${_factorsOf(a).join("، ")}.\nعوامل $b: ${_factorsOf(b).join("، ")}.\nأكبر عامل مشترك هو $res.',
            level: level);
      case 1: // م.م.أ
        final a = 2 + r.nextInt(big ? 11 : 7);
        var b = 2 + r.nextInt(big ? 11 : 7);
        if (a == b) b += 1;
        final res = lcm(a, b);
        return _fill('lcm', 'ما المضاعف المشترك الأصغر للعددين $a و $b ؟', '$res',
            'نكتب مضاعفات $a و $b حتى نجد أول مضاعف مشترك، وهو $res.',
            level: level);
      case 2: // قابلية القسمة
        final d = [2, 3, 4, 5, 6, 9, 10][r.nextInt(7)];
        final n = (10 + r.nextInt(big ? 990 : 90));
        final truth = n % d == 0;
        return _tf(r, 'div', 'العدد $n يقبل القسمة على $d.', truth,
            truth
                ? '$n ÷ $d = ${n ~/ d} بدون باقٍ.'
                : '$n ÷ $d يعطي باقيًا ${n % d}، فلا يقبل القسمة.',
            level: level);
      case 3: // كسر إلى نسبة مئوية
        final dens = [2, 4, 5, 10, 20, 25, 50];
        final den = dens[r.nextInt(dens.length)];
        final nu = 1 + r.nextInt(den - 1);
        final pct = nu * 100 ~/ den;
        return _fill('pct', 'اكتبي الكسر $nu/$den على صورة نسبة مئوية (بدون علامة ٪).', '$pct',
            'نضرب البسط والمقام لنجعل المقام ١٠٠: $nu/$den = $pct/100 = $pct٪.',
            level: level);
      case 4: // نسبة من عدد
        final p = [10, 20, 25, 50, 75][r.nextInt(5)];
        final base = [20, 40, 60, 80, 100, 120, 200][r.nextInt(7)];
        final res = base * p ~/ 100;
        return _mcq(r, 'pof', 'ما قيمة $p٪ من $base ؟', res,
            '$p٪ من $base = $base × $p ÷ 100 = $res.',
            level: level, spread: 6);
      case 5: // كسر إلى عشري
        final opts = [
          [1, 2, '0.5'], [1, 4, '0.25'], [3, 4, '0.75'], [1, 5, '0.2'],
          [2, 5, '0.4'], [3, 5, '0.6'], [4, 5, '0.8'], [1, 10, '0.1'],
          [7, 10, '0.7'], [3, 20, '0.15'], [9, 20, '0.45'], [1, 8, '0.125'],
        ];
        final o = opts[r.nextInt(opts.length)];
        final dec = o[2] as String;
        final arabicVariant = dec.replaceAll('.', '٫');
        return _fill('dec', 'اكتبي الكسر ${o[0]}/${o[1]} على صورة عدد عشري.', dec,
            '${o[0]} ÷ ${o[1]} = $dec',
            extra: [arabicVariant, dec.replaceAll('.', ',')], level: level);
      case 6: // محيط مستطيل
        final w = 3 + r.nextInt(big ? 15 : 8), h = 2 + r.nextInt(big ? 12 : 6);
        final per = 2 * (w + h);
        return _mcq(r, 'per', 'مستطيل طوله $w سم وعرضه $h سم. ما محيطه بالسنتيمتر؟', per,
            'المحيط = ٢ × (الطول + العرض) = ٢ × ($w + $h) = $per سم.',
            level: level, spread: 8);
      case 7: // مساحة مستطيل
        final w = 3 + r.nextInt(big ? 15 : 8), h = 2 + r.nextInt(big ? 12 : 6);
        return _fill('area', 'ما مساحة مستطيل طوله $w سم وعرضه $h سم (بالسنتيمتر المربع)؟',
            '${w * h}', 'المساحة = الطول × العرض = $w × $h = ${w * h} سم².',
            level: level);
      case 8: // ترتيب العمليات
        final a = 2 + r.nextInt(9), b = 2 + r.nextInt(8), c = 2 + r.nextInt(8);
        final res = a + b * c;
        return _fill('ops', 'ما ناتج $a + $b × $c ؟', '$res',
            'الضرب قبل الجمع: $b × $c = ${b * c}، ثم $a + ${b * c} = $res.',
            level: level);
      case 9: // تحويل وحدات
        final km = 1 + r.nextInt(9);
        final half = r.nextBool();
        final m = km * 1000 + (half ? 500 : 0);
        return _fill('unit', 'كم متر في ${half ? "$km٫٥" : "$km"} كيلومتر؟', '$m',
            'الكيلومتر الواحد = ١٠٠٠ متر، فالناتج $m متر.',
            level: level);
      case 10: // عدد أولي؟
        final cand = [11, 13, 15, 17, 21, 23, 27, 29, 31, 33, 37, 39, 41, 49, 51, 53, 57, 59, 61, 91];
        final n = cand[r.nextInt(cand.length)];
        final prime = _factorsOf(n).length == 2;
        return _tf(r, 'prime', 'العدد $n عدد أولي.', prime,
            prime
                ? '$n لا يقبل القسمة إلا على ١ ونفسه.'
                : 'عوامل $n: ${_factorsOf(n).join("، ")}، فهو ليس أوليًا.',
            level: level);
      default: // متوسط حسابي
        final a = 4 + r.nextInt(20), s = 2 + r.nextInt(8);
        final nums = [a, a + s, a + 2 * s];
        final avg = a + s;
        return _mcq(r, 'avg', 'ما المتوسط الحسابي للأعداد ${nums.join("، ")} ؟', avg,
            'المجموع = ${nums.reduce((x, y) => x + y)}، ÷ ٣ = $avg.',
            level: level, spread: 5);
    }
  }

  /// يولّد [count] سؤالًا متنوعًا.
  static List<Question> generate(Random r, {int count = 10, int level = 1}) {
    final kinds = List<int>.generate(12, (i) => i)..shuffle(r);
    return [
      for (var i = 0; i < count; i++) one(r, kinds[i % kinds.length], level: level)
    ];
  }
}
