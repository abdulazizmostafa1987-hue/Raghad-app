import 'dart:math';
import 'package:flutter/material.dart';
import '../models.dart';
import '../progress_store.dart';
import '../screens.dart' show MentalMathPage, MemoryGamePage;
import '../screens3.dart' show FlashcardsPage, MatchGamePage, SpotErrorPage;
import 'brand.dart';
import 'exam_pages.dart';
import 'extras.dart';
import 'games.dart';
import 'sfx.dart';
import 'practice_gen.dart';
import 'practice_runner.dart';
import 'rewards.dart';
import 'world_data.dart';

String _day() {
  final d = DateTime.now();
  return '${d.year}-${d.month}-${d.day}';
}

/// تمرين رياضيات لا ينتهي: كل جولة ٨ مسائل جديدة، وتمنح عملات.
class EndlessPracticePage extends StatefulWidget {
  const EndlessPracticePage({super.key, required this.store, this.level = 1});
  final ProgressStore store;
  final int level;
  @override
  State<EndlessPracticePage> createState() => _EndlessPracticePageState();
}

class _EndlessPracticePageState extends State<EndlessPracticePage> {
  int _round = 0;
  int? _lastCorrect;
  int _lastTotal = 0;

  Future<void> _finished(List<AnswerRecord> recs, int secs) async {
    final ok = recs.where((r) => r.ok).length;
    final s = widget.store;
    await s.addCoins(ok * 2);
    await s.putInt('totalCorrect', s.totalCorrect + ok);
    await s.bumpQuest('practice', recs.length);
    await s.bumpQuest('correct', ok);
    await s.logDay(ok, recs.length);
    final right = {for (final r in recs) if (r.ok) r.q.id};
    final wrong = {for (final r in recs) if (!r.ok) r.q.id};
    await s.recordAttempt(lessonId: 'practice', correct: ok, total: recs.length, wrong: wrong, right: right);
    if (!mounted) return;
    setState(() {
      _lastCorrect = ok;
      _lastTotal = recs.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_lastCorrect != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('تمرين الرياضيات')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('🎉', style: TextStyle(fontSize: 70)),
              Text('$_lastCorrect من $_lastTotal صحيحة',
                  style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              StatPill('🪙', '+${_lastCorrect! * 2}', light: false),
              const SizedBox(height: 20),
              FilledButton(
                  onPressed: () => setState(() {
                        _lastCorrect = null;
                        _round++;
                      }),
                  child: const Text('جولة جديدة')),
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('رجوع')),
            ]),
          ),
        ),
      );
    }
    return Scaffold(
      body: SafeArea(
        child: PracticeRunner(
          key: ValueKey('practice-$_round'),
          questions: MathPractice.generate(Random(), count: 8, level: widget.level),
          store: widget.store,
          accent: const Color(0xFFE5703F),
          onFinished: _finished,
        ),
      ),
    );
  }
}

class ChallengesPage extends StatelessWidget {
  const ChallengesPage({
    super.key,
    required this.store,
    required this.content,
    required this.islands,
    required this.onChanged,
  });
  final ProgressStore store;
  final Content content;
  final List<Island> islands;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Column(children: [
        const TabBar(
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: [
            Tab(text: '🎯 مهام اليوم'),
            Tab(text: '🎮 ألعاب'),
            Tab(text: '📝 امتحانات'),
            Tab(text: '🏅 إنجازات'),
          ],
        ),
        Expanded(
          child: TabBarView(children: [
            QuestsTab(store: store, onChanged: onChanged),
            _GamesTab(store: store, content: content, onChanged: onChanged),
            ExamHub(store: store, content: content, islands: islands),
            AchievementsTab(store: store),
          ]),
        ),
      ]),
    );
  }
}

class QuestsTab extends StatefulWidget {
  const QuestsTab({super.key, required this.store, required this.onChanged});
  final ProgressStore store;
  final VoidCallback onChanged;
  @override
  State<QuestsTab> createState() => _QuestsTabState();
}

class _QuestsTabState extends State<QuestsTab> {
  ProgressStore get s => widget.store;

  @override
  Widget build(BuildContext context) {
    final quests = s.todaysQuests();
    final claimedAll = quests.every((q) => s.questClaimed(q.id));
    return ListView(padding: const EdgeInsets.all(14), children: [
      GradientCard(
        colors: const [Color(0xFFFF9A5B), Color(0xFFFF5E8A)],
        child: Row(children: [
          const Text('🔥', style: TextStyle(fontSize: 46)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('سلسلة ${s.streak} يوم',
                  style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
              const Text('ادخلي كل يوم وحلّي اختبارًا للحفاظ عليها',
                  style: TextStyle(color: Colors.white70)),
            ]),
          ),
        ]),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('🏆', style: TextStyle(fontSize: 30)),
              const SizedBox(width: 10),
              const Expanded(child: Text('التحدي الأسبوعي: اجمعي 12 نجمة', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
              s.weeklyClaimed
                  ? const Icon(Icons.check_circle_rounded, color: Color(0xFF2EAD6B), size: 30)
                  : FilledButton(
                      style: FilledButton.styleFrom(minimumSize: const Size(72, 40)),
                      onPressed: s.weeklyStars >= weeklyGoal
                          ? () async {
                              await s.claimWeekly();
                              Sfx.play('chest');
                              setState(() {});
                              widget.onChanged();
                            }
                          : null,
                      child: const Text('🪙50 💎2 🎁'),
                    ),
            ]),
            const SizedBox(height: 8),
            ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: min(s.weeklyStars, weeklyGoal) / weeklyGoal, minHeight: 10)),
            Text('${min(s.weeklyStars, weeklyGoal)} / $weeklyGoal نجمة هذا الأسبوع', style: const TextStyle(fontSize: 12)),
          ]),
        ),
      ),
      const Padding(
          padding: EdgeInsets.only(top: 10, bottom: 2),
          child: Text('مهام اليوم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
      for (final q in quests)
        Builder(builder: (_) {
          final p = min(s.questProgress(q.id), q.goal);
          final done = p >= q.goal;
          final claimed = s.questClaimed(q.id);
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Text(q.emoji, style: const TextStyle(fontSize: 32)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(q.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(value: p / q.goal, minHeight: 9),
                    ),
                    Text('$p / ${q.goal}', style: const TextStyle(fontSize: 12)),
                  ]),
                ),
                const SizedBox(width: 10),
                claimed
                    ? const Icon(Icons.check_circle_rounded, color: Color(0xFF2EAD6B), size: 30)
                    : FilledButton(
                        style: FilledButton.styleFrom(minimumSize: const Size(72, 40)),
                        onPressed: done
                            ? () async {
                                await s.claimQuest(q);
                                Sfx.play('coin');
                                setState(() {});
                                widget.onChanged();
                              }
                            : null,
                        child: Text('🪙 ${q.coins}'),
                      ),
              ]),
            ),
          );
        }),
      if (claimedAll)
        const Card(
            child: Padding(
                padding: EdgeInsets.all(14),
                child: Text('أنهيتِ كل مهام اليوم! حصلتِ على صندوق كنز 🎁 افتحيه من تبويب «رغد».',
                    textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800)))),
    ]);
  }
}

class _GameDef {
  const _GameDef(this.emoji, this.name, this.sub, this.c1, this.c2, this.build);
  final String emoji;
  final String name;
  final String sub;
  final Color c1;
  final Color c2;
  final Widget Function() build;
}

class _GamesTab extends StatelessWidget {
  const _GamesTab({required this.store, required this.content, required this.onChanged});
  final ProgressStore store;
  final Content content;
  final VoidCallback onChanged;

  static const _req = {
    'تمرين رياضيات صعب': 5,
    'معركة الزعيم': 5,
    'اكتشف الخطأ': 3,
    'بالونات الأرقام': 3,
    'تحدي الوقت': 6,
    'سباق الأرقام': 10,
    'حفر الكنز': 15,
  };

  Future<void> _play(BuildContext context, _GameDef g) async {
    final need = _req[g.name] ?? 0;
    if (store.totalStars < need) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('🔒 تُفتح هذه اللعبة عند جمع $need نجمة (معك ${store.totalStars})')));
      return;
    }
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => g.build()));
    // مكافأة صغيرة بحد أقصى ٥ ألعاب يوميًا حتى لا تتحول الألعاب إلى طريق سهل للعملات.
    final key = 'gc_${_day()}';
    final n = store.getInt(key, 0);
    await store.noteGamePlayed();
    if (n < 5) {
      await store.putInt(key, n + 1);
      await store.addCoins(5);
    }
    onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final all = content.allQuestions;
    final games = <_GameDef>[
      _GameDef('🔤', 'بناء الكلمات', 'رتّبي الحروف لتكوّني الكلمة', const Color(0xFFB57BEE), const Color(0xFF7B4FD1), () => WordBuilderPage(store: store)),
      _GameDef('👹', 'معركة الزعيم', 'اضربي الوحش بالإجابات الصحيحة', const Color(0xFFFF6B6B), const Color(0xFF8E2DE2),
          () => BossBattlePage(store: store, questions: choicePool(Random(), 10, content: all), bossName: 'وحش الأخطاء', bossEmoji: bossEmojis[Random().nextInt(bossEmojis.length)], accent: const Color(0xFF8E2DE2))),
      _GameDef('🎈', 'بالونات الأرقام', 'فقّعي البالونة الصحيحة قبل أن تطير', const Color(0xFF8EE3F5), const Color(0xFF3A86FF),
          () => BalloonPopPage(store: store, content: all)),
      _GameDef('⏱️', 'تحدي الوقت', 'أكبر عدد إجابات في ٦٠ ثانية', const Color(0xFFFFB347), const Color(0xFFE5703F),
          () => TimeAttackPage(store: store, content: all)),
      _GameDef('🏎️', 'سباق الأرقام', 'تقدّمي بالإجابات وسابقي المنافس', const Color(0xFF43CBA0), const Color(0xFF1B9E77),
          () => NumberRacePage(store: store, content: all)),
      _GameDef('⛏️', 'حفر الكنز', 'كل إجابة صحيحة تحفر مربعًا', const Color(0xFFC49A6C), const Color(0xFF8D6A44),
          () => TreasureDigPage(store: store, content: all)),
      _GameDef('🧮', 'تمرين رياضيات متجدد', 'مسائل جديدة في كل مرة', const Color(0xFFFFB347),
          const Color(0xFFFF7E5F), () => EndlessPracticePage(store: store)),
      _GameDef('🔥', 'تمرين رياضيات صعب', 'أعداد أكبر وتحدٍّ أعلى', const Color(0xFFFF6B6B),
          const Color(0xFFC44569), () => EndlessPracticePage(store: store, level: 2)),
      _GameDef('🧠', 'الحساب الذهني', '٨ مسائل سريعة', const Color(0xFF4CC9F0), const Color(0xFF3A86FF),
          () => MentalMathPage(store: store)),
      if (content.pairs.isNotEmpty) ...[
        _GameDef('🃏', 'لعبة الذاكرة', 'طابقي الكسر بقيمته', const Color(0xFFB57BEE),
            const Color(0xFF7B4FD1), () => MemoryGamePage(pairs: content.pairs, store: store)),
        _GameDef('🔗', 'لعبة التوصيل', 'وصّلي كل كسر بقيمته', const Color(0xFF43CBA0),
            const Color(0xFF1B9E77), () => MatchGamePage(pairs: content.pairs, store: store)),
      ],
      if (all.length >= 3)
        _GameDef('🕵️', 'اكتشف الخطأ', 'عبارة واحدة خاطئة', const Color(0xFFFFD166), const Color(0xFFEF8354),
            () => SpotErrorPage(questions: all, store: store)),
      if (all.isNotEmpty)
        _GameDef('🎴', 'بطاقات المراجعة', 'اقلبي وتأكدي', const Color(0xFF6C8CFF), const Color(0xFF3F51D8),
            () => FlashcardsPage(questions: all, store: store)),
    ];
    return ListView(padding: const EdgeInsets.all(14), children: [
      const Text('كل لعبة تمنحك ٥ عملات (حتى ٥ ألعاب يوميًا) وتُحتسب في مهام اليوم.',
          style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 6),
      for (final g in games)
        GradientCard(
          colors: [g.c1, g.c2],
          onTap: () => _play(context, g),
          child: Opacity(
            opacity: store.totalStars < (_req[g.name] ?? 0) ? .55 : 1,
            child: Row(children: [
            Text(g.emoji, style: const TextStyle(fontSize: 40)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(g.name, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                Text(store.totalStars < (_req[g.name] ?? 0) ? '🔒 تُفتح عند ${_req[g.name]} نجمة' : g.sub, style: const TextStyle(color: Colors.white70)),
              ]),
            ),
            Icon(store.totalStars < (_req[g.name] ?? 0) ? Icons.lock_rounded : Icons.play_circle_fill_rounded, color: Colors.white, size: 34),
          ]),
          ),
        ),
    ]);
  }
}

class AchievementsTab extends StatelessWidget {
  const AchievementsTab({super.key, required this.store});
  final ProgressStore store;
  @override
  Widget build(BuildContext context) {
    final unlocked = achievementList.where((a) => a.test(store)).length;
    return ListView(padding: const EdgeInsets.all(14), children: [
      Text('فتحتِ $unlocked من ${achievementList.length} إنجازًا',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 4),
      ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: LinearProgressIndicator(value: unlocked / achievementList.length, minHeight: 10),
      ),
      const SizedBox(height: 10),
      GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.35,
        children: [
          for (final a in achievementList)
            Builder(builder: (_) {
              final on = a.test(store);
              return Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: on ? Brand.gold.withValues(alpha: .18) : Colors.grey.withValues(alpha: .10),
                  border: Border.all(color: on ? Brand.gold : Colors.transparent, width: 2),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(on ? a.emoji : '🔒', style: const TextStyle(fontSize: 30)),
                  Text(a.title, style: const TextStyle(fontWeight: FontWeight.w900), textAlign: TextAlign.center),
                  Text(a.hint, style: const TextStyle(fontSize: 11), textAlign: TextAlign.center),
                ]),
              );
            }),
        ],
      ),
    ]);
  }
}
