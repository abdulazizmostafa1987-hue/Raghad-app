import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../progress_store.dart';
import 'brand.dart';
import 'rewards.dart';
import 'sfx.dart';

class Nasheed {
  const Nasheed(this.id, this.title, this.theme, this.emoji, this.lines, this.c1, this.c2);
  final String id;
  final String title;
  final String theme;
  final String emoji;
  final List<String> lines;
  final Color c1;
  final Color c2;
}

/// أناشيد أصلية من كلمات رغد (غير مأخوذة من أعمال أخرى). الألحان مولَّدة بسيطة،
/// ويمكن استبدال ملفات `assets/audio/n*_duff.wav` و`n*_full.wav` بتسجيلات بصوت منشدين.
const nasheeds = <Nasheed>[
  Nasheed('n1', 'بسم الله نبدأ', 'بداية اليوم والمذاكرة', '🌅', [
    'بسمِ اللهِ نبدأُ يومَنا',
    'والعلمُ نورٌ يُضيءُ دربَنا',
    'ربِّ زدني علمًا وفهمًا',
    'واجعلِ الخيرَ دائمًا رفيقَنا',
    'أذاكرُ بجدٍّ وإخلاصٍ',
    'وأسعى وأحلمُ بالنجاحِ',
    'أتوكلُ على اللهِ وأعملُ',
    'فمن جدَّ وجدَ ومن زرعَ حصدَ',
  ], Color(0xFFFFB347), Color(0xFFFF7E5F)),
  Nasheed('n2', 'الصدقُ أمان', 'الصدق والأمانة', '🤝', [
    'الصدقُ أمانٌ يا صغيري',
    'والكذبُ يُتعبُ ضميري',
    'أقولُ الحقَّ ولو كنتُ وحدي',
    'فاللهُ يرى ما في صدري',
    'الصدقُ يهدي إلى البرِّ',
    'والبرُّ يهدي إلى الخيرِ',
    'أكونُ صادقًا في قولي',
    'وأمينًا في كلِّ أمري',
  ], Color(0xFF43CBA0), Color(0xFF1B9E77)),
  Nasheed('n3', 'الحمدُ للهِ على النِّعَم', 'الشكر والعطاء', '🌸', [
    'الحمدُ للهِ على النِّعَمِ',
    'بصحتي وبيتي وبالقلمِ',
    'أشكرُ ربي في كلِّ حينٍ',
    'وأشكرُ أمي وأبي الكريمينِ',
    'أحفظُ النعمةَ ولا أُسرِفُ',
    'وأعطي المحتاجَ ولا أبخلُ',
    'بالشكرِ تدومُ النِّعَمُ',
    'وبالخيرِ تعلو الهِمَمُ',
  ], Color(0xFFFF9EC4), Color(0xFFE5589A)),
  Nasheed('n4', 'يدٌ بيدٍ', 'التعاون وحب الوطن', '🇪🇬', [
    'يدٌ بيدٍ نبني الوطنْ',
    'نتعاونُ في السرِّ والعلنْ',
    'أنا وأنتَ وكلُّ الأصدقاءْ',
    'نصنعُ الخيرَ ونزرعُ الوفاءْ',
    'إذا تعاونّا لانَ الصعبُ',
    'وسهلَ الطريقُ وزالَ التعبُ',
    'مصرُ بنا تعلو وترتفعُ',
    'وبالعلمِ والعملِ نجتمعُ',
  ], Color(0xFF4CC9F0), Color(0xFF3A86FF)),
  Nasheed('n5', 'اطلبِ العلمَ', 'طلب العلم', '📚', [
    'اطلبِ العلمَ يا صغيرُ',
    'فالعلمُ نورٌ ومَنارُ',
    'من سلكَ دربًا للعلمِ',
    'سهَّلَ اللهُ له طريقًا للجنةِ',
    'اقرأْ وتعلَّمْ وسلْ',
    'وكنْ بالأدبِ متحلِّي',
    'بالعلمِ ترتقي الأممُ',
    'وبالخلقِ تعلو القممُ',
  ], Color(0xFFB57BEE), Color(0xFF7B4FD1)),
  Nasheed('n6', 'ابدأ من جديد', 'المثابرة وعدم اليأس', '💪', [
    'إنْ تعثّرتَ فقمْ من جديدْ',
    'فبعدَ الليلِ صباحٌ سعيدْ',
    'ثقْ باللهِ وجدَّ السيرْ',
    'فمن يجتهدْ يرَ الخيرْ',
    'كلُّ خطأٍ درسٌ جميلْ',
    'يقودُ للنجاحِ الأصيلْ',
    'أبدأُ من جديدٍ بقلبي القويْ',
    'وأمضي بعزمٍ لا ينطفي',
  ], Color(0xFFFF6B6B), Color(0xFF8E2DE2)),
];

class NasheedPage extends StatefulWidget {
  const NasheedPage({super.key, required this.store, this.onChanged});
  final ProgressStore store;
  final VoidCallback? onChanged;
  @override
  State<NasheedPage> createState() => _NasheedPageState();
}

class _NasheedPageState extends State<NasheedPage> {
  final AudioPlayer _p = AudioPlayer();
  final FlutterTts _tts = FlutterTts();
  Nasheed? _cur;
  bool _playing = false;
  bool _withMelody = true;
  int _line = -1;
  Duration _pos = Duration.zero;
  StreamSubscription<Duration>? _sub;
  bool _rewarded = false;

  @override
  void initState() {
    super.initState();
    _withMelody = widget.store.flag('nasheedMelody', def: true);
    Sfx.stopMusic();
    _sub = _p.onPositionChanged.listen((d) {
      if (_cur == null || !mounted) return;
      final total = 20.0;
      final idx = ((d.inMilliseconds / 1000) / total * _cur!.lines.length).floor().clamp(0, _cur!.lines.length - 1);
      setState(() {
        _pos = d;
        _line = idx;
      });
      if (!_rewarded && d.inSeconds >= 15) _reward();
    });
    _p.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _p.dispose();
    _tts.stop();
    Sfx.refresh();
    super.dispose();
  }

  Future<void> _reward() async {
    _rewarded = true;
    final d = DateTime.now();
    final key = 'ns_${_cur!.id}_${d.year}-${d.month}-${d.day}';
    if (widget.store.getInt(key, 0) == 0) {
      await widget.store.putInt(key, 1);
      await widget.store.addCoins(3);
      widget.onChanged?.call();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('🪙 +3 مكافأة الاستماع للنشيد')));
      }
    }
  }

  Future<void> _play(Nasheed n) async {
    try {
      await _tts.stop();
      await _p.stop();
      _rewarded = false;
      setState(() {
        _cur = n;
        _line = 0;
        _playing = true;
      });
      await _p.setReleaseMode(ReleaseMode.stop);
      await _p.setVolume(.9);
      await _p.play(AssetSource('audio/${n.id}_${_withMelody ? 'full' : 'duff'}.wav'));
    } catch (_) {
      if (mounted) setState(() => _playing = false);
    }
  }

  Future<void> _toggle(Nasheed n) async {
    if (_cur?.id == n.id && _playing) {
      await _p.pause();
      setState(() => _playing = false);
    } else if (_cur?.id == n.id) {
      await _p.resume();
      setState(() => _playing = true);
    } else {
      await _play(n);
    }
  }

  Future<void> _read(String line) async {
    try {
      await _tts.setLanguage('ar');
      await _tts.setSpeechRate(.38);
      await _tts.speak(line);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🎵 أناشيد رغد')),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        Card(
          child: SwitchListTile(
            title: const Text('مع لحن الناي'),
            subtitle: const Text('أطفئيه لتسمعي إيقاع الدف فقط'),
            value: _withMelody,
            onChanged: (v) async {
              await widget.store.putFlag('nasheedMelody', v);
              setState(() => _withMelody = v);
              if (_cur != null && _playing) await _play(_cur!);
            },
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 4),
          child: Text('اقرئي الكلمات مع النشيد وتحفّظي ما تحبين. كلمات أصلية من تطبيق رغد، وألحانها مولَّدة ويمكن استبدالها بتسجيلات منشدين.',
              style: TextStyle(fontSize: 12)),
        ),
        for (final n in nasheeds)
          Builder(builder: (_) {
            final active = _cur?.id == n.id;
            return GradientCard(
              colors: [n.c1, n.c2],
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text(n.emoji, style: const TextStyle(fontSize: 34)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(n.title, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                      Text(n.theme, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    ]),
                  ),
                  IconButton.filled(
                    style: IconButton.styleFrom(backgroundColor: Colors.white, foregroundColor: n.c2),
                    onPressed: () => _toggle(n),
                    icon: Icon(active && _playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                  ),
                ]),
                if (active) ...[
                  const SizedBox(height: 8),
                  LinearProgressIndicator(value: (_pos.inMilliseconds / 20000).clamp(0.0, 1.0), color: Colors.white, backgroundColor: Colors.white30, minHeight: 6),
                  const SizedBox(height: 8),
                  for (var i = 0; i < n.lines.length; i++)
                    InkWell(
                      onTap: () => _read(n.lines[i]),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: AnimatedDefaultTextStyle(
                          duration: const Duration(milliseconds: 250),
                          style: TextStyle(
                              color: i == _line ? Colors.white : Colors.white70,
                              fontSize: i == _line ? 20 : 16,
                              fontWeight: i == _line ? FontWeight.w900 : FontWeight.w600,
                              height: 1.6),
                          child: Text(n.lines[i]),
                        ),
                      ),
                    ),
                  const Text('اضغطي على أي سطر ليُقرأ بصوت عالٍ', style: TextStyle(color: Colors.white60, fontSize: 11)),
                ],
              ]),
            );
          }),
      ]),
    );
  }
}
