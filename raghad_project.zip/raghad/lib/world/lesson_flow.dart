import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../models.dart';
import '../progress_store.dart';
import '../widgets.dart' show Confetti;
import 'brand.dart';
import 'practice_runner.dart';
import 'rewards.dart';

/// يقسّم نص الدرس إلى بطاقات قصيرة.
List<String> splitBody(String body) {
  final parts = body
      .replaceAll('\\n', '\n')
      .split(RegExp(r'\n\s*\n'))
      .map((e) => e.trim())
      .where((e) => e.isNotEmpty)
      .toList();
  // الفقرات الطويلة جدًا تُقسَّم على الأسطر لتبقى البطاقة مقروءة.
  final out = <String>[];
  for (final p in parts) {
    final lines = p.split('\n').where((l) => l.trim().isNotEmpty).toList();
    if (p.length > 260 && lines.length > 3) {
      for (var i = 0; i < lines.length; i += 3) {
        out.add(lines.skip(i).take(3).join('\n'));
      }
    } else {
      out.add(p);
    }
  }
  return out;
}

class LessonFlowPage extends StatefulWidget {
  const LessonFlowPage({
    super.key,
    required this.lesson,
    required this.store,
    required this.accent,
    this.nodeId,
  });
  final Lesson lesson;
  final ProgressStore store;
  final Color accent;
  final String? nodeId;
  @override
  State<LessonFlowPage> createState() => _LessonFlowPageState();
}

class _LessonFlowPageState extends State<LessonFlowPage> {
  late final List<String> _cards = splitBody(widget.lesson.body);
  final PageController _pc = PageController();
  final FlutterTts _tts = FlutterTts();
  int _page = 0;
  bool _speaking = false;
  bool _practice = false;
  LessonReward? _reward;
  int _correct = 0;
  int _total = 0;

  // الصفحات: الأهداف + البطاقات + بطاقة الاستعداد.
  int get _count => 2 + _cards.length;

  @override
  void initState() {
    super.initState();
    _tts.setCompletionHandler(() {
      if (mounted) setState(() => _speaking = false);
    });
    _tts.setCancelHandler(() {
      if (mounted) setState(() => _speaking = false);
    });
    widget.store.setLastLesson(widget.lesson.id, title: widget.lesson.title);
  }

  @override
  void dispose() {
    _tts.stop();
    _pc.dispose();
    super.dispose();
  }

  Future<void> _speak(String text) async {
    try {
      if (_speaking) {
        await _tts.stop();
        return;
      }
      await _tts.setLanguage('ar');
      await _tts.setSpeechRate(0.4);
      setState(() => _speaking = true);
      await _tts.speak(text);
    } catch (_) {
      if (mounted) setState(() => _speaking = false);
    }
  }

  Future<void> _finished(List<AnswerRecord> recs, int secs) async {
    final right = {for (final r in recs) if (r.ok) r.q.id};
    final wrong = {for (final r in recs) if (!r.ok) r.q.id};
    await widget.store.recordAttempt(
        lessonId: widget.lesson.id,
        correct: right.length,
        total: recs.length,
        wrong: wrong,
        right: right);
    final reward = await widget.store.rewardNode(
        nodeId: widget.nodeId ?? widget.lesson.id,
        correct: right.length,
        total: recs.length);
    if (!mounted) return;
    setState(() {
      _reward = reward;
      _correct = right.length;
      _total = recs.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_reward != null) {
      return NodeResultView(
        reward: _reward!,
        correct: _correct,
        total: _total,
        store: widget.store,
        accent: widget.accent,
        onRetry: () => setState(() {
          _reward = null;
          _practice = true;
        }),
        onClose: () => Navigator.pop(context),
      );
    }
    if (_practice) {
      return Scaffold(
        body: SafeArea(
          child: PracticeRunner(
            key: ValueKey('run-${widget.lesson.id}'),
            questions: widget.lesson.questions,
            store: widget.store,
            accent: widget.accent,
            onFinished: _finished,
          ),
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.lesson.title),
        actions: [
          IconButton(
            tooltip: 'استمعي',
            icon: Icon(_speaking ? Icons.stop_circle_rounded : Icons.volume_up_rounded),
            onPressed: () {
              if (_page == 0) {
                _speak(widget.lesson.objectives.join('. '));
              } else if (_page <= _cards.length) {
                _speak(_cards[_page - 1]);
              }
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Row(children: [
              for (var i = 0; i < _count; i++)
                Expanded(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    height: 7,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      color: i <= _page ? widget.accent : widget.accent.withValues(alpha: .15),
                    ),
                  ),
                ),
            ]),
          ),
          Expanded(
            child: PageView.builder(
              controller: _pc,
              itemCount: _count,
              onPageChanged: (v) {
                _tts.stop();
                setState(() {
                  _page = v;
                  _speaking = false;
                });
              },
              itemBuilder: (_, i) => _card(i),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
            child: Row(children: [
              if (_page > 0)
                IconButton.filledTonal(
                    onPressed: () => _pc.previousPage(
                        duration: const Duration(milliseconds: 300), curve: Curves.easeOut),
                    icon: const Icon(Icons.arrow_forward_rounded)),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: widget.accent),
                  onPressed: () {
                    if (_page < _count - 1) {
                      _pc.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                    } else if (widget.lesson.questions.isNotEmpty) {
                      setState(() => _practice = true);
                    } else {
                      Navigator.pop(context);
                    }
                  },
                  child: Text(_page < _count - 1 ? 'التالي' : 'يلا نتدرّب! 🚀'),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _card(int i) {
    final icons = ['🎯', '💡', '📐', '🔍', '✨', '🧩', '📝'];
    late final String emoji, heading, text;
    if (i == 0) {
      emoji = '🎯';
      heading = 'هدفنا اليوم';
      text = widget.lesson.objectives.map((o) => '✔ $o').join('\n\n');
    } else if (i <= _cards.length) {
      emoji = icons[i % icons.length];
      heading = 'فكرة $i';
      text = _cards[i - 1];
    } else {
      emoji = '🚀';
      heading = 'جاهزة؟';
      text = widget.lesson.questions.isEmpty
          ? 'أنهيتِ شرح الدرس. أحسنتِ!'
          : 'سنحلّ ${widget.lesson.questions.length} أسئلة قصيرة. استخدمي «تلميح» إن احتجتِ، ولا تقلقي من الخطأ فكل خطأ يعلّمنا!';
    }
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(32),
          gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [widget.accent.withValues(alpha: .14), widget.accent.withValues(alpha: .04)]),
          border: Border.all(color: widget.accent.withValues(alpha: .25), width: 2),
        ),
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(emoji, style: const TextStyle(fontSize: 54)),
            const SizedBox(height: 6),
            Text(heading, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: widget.accent)),
            const SizedBox(height: 12),
            Text(text, style: const TextStyle(fontSize: 21, height: 1.85, fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
    );
  }
}

/// شاشة النتيجة: نجوم، عملات، جواهر، وصندوق كنز.
class NodeResultView extends StatefulWidget {
  const NodeResultView({
    super.key,
    required this.reward,
    required this.correct,
    required this.total,
    required this.store,
    required this.accent,
    required this.onClose,
    this.onRetry,
  });
  final LessonReward reward;
  final int correct;
  final int total;
  final ProgressStore store;
  final Color accent;
  final VoidCallback onClose;
  final VoidCallback? onRetry;
  @override
  State<NodeResultView> createState() => _NodeResultViewState();
}

class _NodeResultViewState extends State<NodeResultView> {
  ChestResult? _chest;
  bool _opened = false;

  Future<void> _open() async {
    final r = await widget.store.openChest();
    if (mounted) {
      setState(() {
        _chest = r;
        _opened = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.reward;
    final pct = widget.total == 0 ? 0 : (widget.correct * 100 / widget.total).round();
    final msg = r.stars == 3
        ? 'مذهلة! درجة كاملة تقريبًا 🌟'
        : r.stars == 2
            ? 'رائع جدًا! أنتِ قريبة من الكمال'
            : r.stars == 1
                ? 'أحسنتِ! جرّبي مرة أخرى لنجوم أكثر'
                : 'محاولة جميلة! راجعي الدرس وجرّبي مجددًا 💪';
    return Scaffold(
      body: Stack(children: [
        Container(
          decoration: const BoxDecoration(gradient: Brand.gradient),
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const SizedBox(height: 10),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  for (var i = 0; i < 3; i++)
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: 1),
                      duration: Duration(milliseconds: 500 + i * 350),
                      curve: Curves.elasticOut,
                      builder: (_, v, child) => Transform.scale(scale: v, child: child),
                      child: Icon(i < r.stars ? Icons.star_rounded : Icons.star_outline_rounded,
                          size: i == 1 ? 96 : 72, color: i < r.stars ? Brand.gold : Colors.white38),
                    ),
                ]),
                const SizedBox(height: 8),
                Text('$pct٪', key: const ValueKey('quiz-final-percent'),
                    style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w900, color: Colors.white)),
                Text('أجبتِ ${widget.correct} من ${widget.total} بشكل صحيح',
                    style: const TextStyle(color: Colors.white, fontSize: 17)),
                const SizedBox(height: 6),
                Text(msg, textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26)),
                  child: Column(children: [
                    const Text('مكافآتك', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Brand.ink)),
                    const SizedBox(height: 10),
                    Wrap(spacing: 10, runSpacing: 8, alignment: WrapAlignment.center, children: [
                      StatPill('🪙', '+${r.coins}', light: false),
                      if (r.gems > 0) StatPill('💎', '+${r.gems}', light: false),
                      if (r.newStars > 0) StatPill('⭐', '+${r.newStars}', light: false),
                      StatPill('✨', '+${widget.correct * 10} خبرة', light: false),
                    ]),
                    if (r.chest && !_opened) ...[
                      const SizedBox(height: 14),
                      FilledButton.icon(
                          onPressed: _open,
                          icon: const Text('🎁', style: TextStyle(fontSize: 22)),
                          label: const Text('افتحي صندوق الكنز!')),
                    ],
                    if (_opened && _chest != null) ...[
                      const SizedBox(height: 14),
                      Text('وجدتِ ${_chest!.coins} عملة'
                          '${_chest!.gems > 0 ? " وجوهرة 💎" : ""}'
                          '${_chest!.sticker != null ? " وملصقًا جديدًا ${_chest!.sticker}" : ""}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontWeight: FontWeight.w800, color: Brand.ink)),
                    ],
                  ]),
                ),
                const SizedBox(height: 22),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Brand.violet),
                    onPressed: widget.onClose,
                    child: const Text('متابعة الرحلة'),
                  ),
                ),
                if (widget.onRetry != null && r.stars < 3)
                  TextButton(
                      onPressed: widget.onRetry,
                      child: const Text('حاولي مرة أخرى لنجوم أكثر', style: TextStyle(color: Colors.white))),
              ]),
            ),
          ),
        ),
        if (r.stars >= 2) const Positioned.fill(child: Confetti()),
      ]),
    );
  }
}
