import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models.dart';
import '../progress_store.dart';
import 'brand.dart';
import 'fx.dart';
import 'games.dart';
import 'practice_runner.dart';
import 'rewards.dart';
import 'sfx.dart';
import 'world_data.dart';

// ======================================================================
// مهمة الإنقاذ: تحويل الأخطاء القديمة إلى جولة تدريب تمنح عملات
// ======================================================================
class RescuePage extends StatefulWidget {
  const RescuePage({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  State<RescuePage> createState() => _RescuePageState();
}

class _RescuePageState extends State<RescuePage> {
  int? _saved;
  int _total = 0;

  List<Question> _pick() {
    final ids = widget.store.wrongIds;
    return (widget.content.allQuestions.where((q) => ids.contains(q.id)).toList()..shuffle()).take(10).toList();
  }

  late List<Question> _qs = _pick();

  Future<void> _finished(List<AnswerRecord> recs, int secs) async {
    final s = widget.store;
    final right = {for (final r in recs) if (r.ok) r.q.id};
    final wrong = {for (final r in recs) if (!r.ok) r.q.id};
    await s.recordAttempt(lessonId: 'rescue', correct: right.length, total: recs.length, wrong: wrong, right: right);
    await s.addCoins(right.length * 3);
    await s.putInt('totalCorrect', s.totalCorrect + right.length);
    await s.bumpQuest('practice', recs.length);
    await s.bumpQuest('correct', right.length);
    await s.logDay(right.length, recs.length);
    Sfx.play(right.length * 2 >= recs.length ? 'win' : 'star');
    if (!mounted) return;
    setState(() {
      _saved = right.length;
      _total = recs.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_qs.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('مهمة الإنقاذ')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('🎉', style: TextStyle(fontSize: 80)),
              Text('لا توجد أخطاء تحتاج إنقاذًا!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              Text('كل ما أخطأتِ فيه سيظهر هنا لتنقذيه.', textAlign: TextAlign.center),
            ]),
          ),
        ),
      );
    }
    if (_saved != null) {
      return GameOverView(
        win: _saved! * 2 >= _total,
        title: 'أنقذتِ $_saved من $_total',
        lines: const ['الأسئلة التي أجبتِ عنها صح خرجت من قائمة الأخطاء'],
        coins: _saved! * 3,
        onAgain: () => setState(() {
          _saved = null;
          _qs = _pick();
        }),
      );
    }
    return Scaffold(
      body: SafeArea(
        child: PracticeRunner(
          key: ValueKey(_qs.map((q) => q.id).join()),
          questions: _qs,
          store: widget.store,
          accent: const Color(0xFF2EAD6B),
          onFinished: _finished,
        ),
      ),
    );
  }
}

// ======================================================================
// التقرير الأسبوعي (لها ولولي الأمر)
// ======================================================================
class WeeklyReportPage extends StatelessWidget {
  const WeeklyReportPage({super.key, required this.store, required this.islands});
  final ProgressStore store;
  final List<Island> islands;

  @override
  Widget build(BuildContext context) {
    final days = store.last7Days();
    final c = days.fold<int>(0, (a, d) => a + d.$2);
    final t = days.fold<int>(0, (a, d) => a + d.$3);
    final acc = t == 0 ? 0 : (c * 100 / t).round();
    final active = days.where((d) => d.$3 > 0).length;
    final weak = <(Island, MapNode)>[];
    for (final i in islands.where((e) => !e.archive)) {
      for (final n in i.nodes) {
        if (store.starsOf(n.id) == 1) weak.add((i, n));
      }
    }
    final strong = [...islands.where((e) => !e.archive)]..sort((a, b) => b.starsEarned(store).compareTo(a.starsEarned(store)));
    final maxT = max(1, days.map((d) => d.$3).fold<int>(0, max));
    final advice = <String>[
      if (active < 3) 'حاولي المذاكرة 3 أيام على الأقل هذا الأسبوع؛ الاستمرار أهم من الكمية.',
      if (t > 0 && acc < 60) 'نسبة الدقة ${acc}٪؛ راجعي الدروس بنجمة واحدة وجرّبي مهمة الإنقاذ.',
      if (t > 0 && acc >= 85) 'أداء ممتاز! جرّبي تحدي الوقت ومعركة الزعيم.',
      if (store.wrongIds.isNotEmpty) 'لديكِ ${store.wrongIds.length} سؤالًا في قائمة الأخطاء؛ مهمة الإنقاذ تحوّلها إلى نجاح.',
      if (t == 0) 'لم يُسجَّل نشاط هذا الأسبوع بعد. ابدئي بدرس واحد اليوم!',
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('تقريري الأسبوعي')),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        GradientCard(
          colors: const [Brand.violetLight, Brand.violet],
          child: Wrap(alignment: WrapAlignment.spaceEvenly, spacing: 10, runSpacing: 8, children: [
            StatPill('📅', '$active/7 أيام'),
            StatPill('✅', '$c من $t'),
            StatPill('🎯', '$acc٪'),
            StatPill('🔥', '${store.streak} سلسلة'),
            StatPill('⭐', '${store.totalStars} نجمة'),
          ]),
        ),
        const Padding(padding: EdgeInsets.only(top: 10, bottom: 6), child: Text('الإجابات في آخر 7 أيام', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: SizedBox(
              height: 150,
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                for (final d in days)
                  Expanded(
                    child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                      Text('${d.$3}', style: const TextStyle(fontSize: 11)),
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 5),
                        height: 4 + 90.0 * d.$3 / maxT,
                        decoration: BoxDecoration(color: d.$3 == 0 ? Colors.grey.withValues(alpha: .3) : Brand.violet, borderRadius: BorderRadius.circular(8)),
                      ),
                      const SizedBox(height: 4),
                      Text(d.$1, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                    ]),
                  ),
              ]),
            ),
          ),
        ),
        const Padding(padding: EdgeInsets.only(top: 10, bottom: 4), child: Text('نقاط القوة', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
        for (final i in strong.take(3))
          if (i.starsEarned(store) > 0)
            ListTile(
              leading: Text(i.emoji, style: const TextStyle(fontSize: 28)),
              title: Text(i.name),
              subtitle: Text('⭐ ${i.starsEarned(store)}/${i.starsMax}'),
            ),
        if (strong.every((i) => i.starsEarned(store) == 0)) const Text('ستظهر هنا بعد إنهاء أول الدروس.'),
        const Padding(padding: EdgeInsets.only(top: 10, bottom: 4), child: Text('تحتاج مراجعة (نجمة واحدة)', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
        if (weak.isEmpty) const Text('لا توجد محطات تحتاج مراجعة الآن 👏'),
        for (final w in weak.take(6))
          ListTile(
            dense: true,
            leading: Text(w.$1.emoji, style: const TextStyle(fontSize: 22)),
            title: Text(w.$2.title, maxLines: 2, overflow: TextOverflow.ellipsis),
            subtitle: Text(w.$1.name),
          ),
        const Padding(padding: EdgeInsets.only(top: 10, bottom: 4), child: Text('نصائح', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
        for (final a in advice) Card(child: Padding(padding: const EdgeInsets.all(12), child: Text('💡 $a', style: const TextStyle(height: 1.5)))),
      ]),
    );
  }
}

// ======================================================================
// لعبة بناء الكلمات (عربي + إنجليزي)
// ======================================================================
const _enWords = <(String, String)>[
  ('planet', 'كوكب'), ('energy', 'طاقة'), ('library', 'مكتبة'), ('science', 'علوم'), ('journey', 'رحلة'),
  ('history', 'تاريخ'), ('oxygen', 'أكسجين'), ('triangle', 'مثلث'), ('digital', 'رقمي'), ('farmer', 'مزارع'),
  ('healthy', 'صحي'), ('teacher', 'معلم'), ('student', 'طالب'), ('country', 'دولة'), ('weather', 'طقس'),
  ('island', 'جزيرة'), ('answer', 'إجابة'), ('number', 'عدد'), ('animal', 'حيوان'), ('garden', 'حديقة'),
];

const _arWords = <(String, String)>[
  ('مكتبة', 'مكان نستعير منه الكتب'), ('كوكب', 'يدور حول الشمس'), ('حديقة', 'فيها أشجار وزهور'),
  ('مدرسة', 'نتعلم فيها'), ('معلومات', 'نبحث عنها في المصادر'), ('نجاح', 'ثمرة الاجتهاد'),
  ('أمانة', 'حفظ ما نؤتمن عليه'), ('صدق', 'قول الحق'), ('تعاون', 'عمل جماعي'),
  ('طبيعة', 'الجبال والأنهار والأشجار'), ('حضارة', 'مثل الحضارة المصرية القديمة'), ('مجتهد', 'يبذل جهدًا في دراسته'),
  ('وطن', 'بلدنا الذي نحبه'), ('قلم', 'نكتب به'), ('كتاب', 'فيه علم ومعرفة'),
];

class WordBuilderPage extends StatefulWidget {
  const WordBuilderPage({super.key, required this.store});
  final ProgressStore store;
  @override
  State<WordBuilderPage> createState() => _WordBuilderPageState();
}

class _WordBuilderPageState extends State<WordBuilderPage> {
  final Random _r = Random();
  late List<(String, String)> _words = _mk();
  int _i = 0, _score = 0, _wrongTries = 0, _hints = 0;
  List<String> _tiles = [];
  List<int> _picked = [];
  bool _over = false;
  bool _ok = false;

  List<(String, String)> _mk() {
    final en = [..._enWords]..shuffle(_r);
    final ar = [..._arWords]..shuffle(_r);
    return ([...en.take(4), ...ar.take(4)]..shuffle(_r));
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _word => _words[_i].$1;
  List<String> _letters(String w) => w.runes.map(String.fromCharCode).toList();

  void _load() {
    final l = _letters(_word);
    var t = [...l]..shuffle(_r);
    if (t.join() == l.join() && l.length > 1) t = t.reversed.toList();
    _tiles = t;
    _picked = [];
    _ok = false;
  }

  void _tap(int idx) {
    if (_ok || _picked.contains(idx)) return;
    Sfx.play('pop');
    setState(() => _picked.add(idx));
    if (_picked.length == _tiles.length) {
      final guess = _picked.map((i) => _tiles[i]).join();
      if (guess == _word) {
        _score++;
        _ok = true;
        Sfx.correct();
        setState(() {});
        Future<void>.delayed(const Duration(milliseconds: 900), _next);
      } else {
        _wrongTries++;
        Sfx.wrong();
        Future<void>.delayed(const Duration(milliseconds: 450), () {
          if (mounted) setState(() => _picked = []);
        });
      }
    }
  }

  void _hint() {
    if (_ok) return;
    final w = _letters(_word);
    final next = _picked.length;
    if (next >= w.length) return;
    // إن كانت الحروف المختارة صحيحة حتى الآن نضيف التالي، وإلا نبدأ من جديد.
    var good = true;
    for (var k = 0; k < _picked.length; k++) {
      if (_tiles[_picked[k]] != w[k]) good = false;
    }
    if (!good) _picked = [];
    final need = w[_picked.length];
    final idx = [for (var i = 0; i < _tiles.length; i++) if (!_picked.contains(i) && _tiles[i] == need) i];
    if (idx.isNotEmpty) {
      _hints++;
      _tap(idx.first);
    }
  }

  Future<void> _next() async {
    if (!mounted) return;
    if (_i + 1 >= _words.length) {
      final coins = _score * 3 + (_score == _words.length ? 8 : 0);
      await widget.store.addCoins(coins);
      await widget.store.putInt('totalCorrect', widget.store.totalCorrect + _score);
      await widget.store.bumpQuest('correct', _score);
      await widget.store.logDay(_score, _words.length);
      Sfx.play(_score >= 5 ? 'win' : 'lose');
      setState(() => _over = true);
      return;
    }
    setState(() {
      _i++;
      _load();
    });
  }

  void _again() {
    setState(() {
      _words = _mk();
      _i = 0;
      _score = 0;
      _wrongTries = 0;
      _hints = 0;
      _over = false;
      _load();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_over) {
      return GameOverView(
        win: _score >= 5,
        title: 'كوّنتِ $_score من ${_words.length} كلمات',
        lines: ['محاولات خاطئة: $_wrongTries  •  تلميحات: $_hints'],
        coins: _score * 3 + (_score == _words.length ? 8 : 0),
        onAgain: _again,
      );
    }
    final w = _letters(_word);
    final isAr = RegExp(r'[\u0600-\u06FF]').hasMatch(_word);
    return Scaffold(
      appBar: AppBar(title: const Text('🔤 بناء الكلمات')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Text('${_i + 1}/${_words.length}', style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(isAr ? 'المعنى: ${_words[_i].$2}' : 'المعنى بالعربية: ${_words[_i].$2}',
              textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          Directionality(
            textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
            child: Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
              for (var k = 0; k < w.length; k++)
                Container(
                  width: 46,
                  height: 54,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: _ok ? const Color(0xFFD7F5E3) : Brand.violet.withValues(alpha: .08),
                    border: Border.all(color: _ok ? const Color(0xFF2EAD6B) : Brand.violet.withValues(alpha: .3), width: 2),
                  ),
                  child: Text(k < _picked.length ? _tiles[_picked[k]] : '', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                ),
            ]),
          ),
          const SizedBox(height: 26),
          Directionality(
            textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
            child: Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [
              for (var k = 0; k < _tiles.length; k++)
                Pressable(
                  onTap: () => _tap(k),
                  child: Opacity(
                    opacity: _picked.contains(k) ? .25 : 1,
                    child: Container(
                      width: 52,
                      height: 58,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: Brand.violet,
                        boxShadow: const [BoxShadow(color: Color(0xFF3B2490), offset: Offset(0, 4))],
                      ),
                      child: Text(_tiles[k], style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white)),
                    ),
                  ),
                ),
            ]),
          ),
          const Spacer(),
          if (_ok) const PopIn(child: Text('أحسنتِ! 🌟', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
          TextButton.icon(onPressed: _hint, icon: const Icon(Icons.lightbulb_outline_rounded), label: const Text('تلميح (حرف)')),
          TextButton(onPressed: () => setState(() => _picked = []), child: const Text('مسح')),
        ]),
      ),
    );
  }
}

// ======================================================================
// شرح بداية التطبيق (يظهر مرة واحدة)
// ======================================================================
Future<void> showOnboarding(BuildContext context, ProgressStore store) async {
  final pages = <(String, String, String)>[
    ('🗺️', 'خريطة المغامرة', 'كل مادة جزيرة. أكملي المحطات واحدة بعد الأخرى، وفي آخر كل وحدة زعيم ينتظرك!'),
    ('⭐', 'النجوم والعملات', 'كل درس يمنحك حتى 3 نجوم وعملات. اجمعي النجوم لتفتحي الألعاب والجوائز.'),
    ('🎮', 'ألعاب ومهام', 'مهام يومية وتحدٍّ أسبوعي وصناديق كنز، وألعاب ممتعة تتدربين فيها دون ملل.'),
    ('👗', 'غرفة رغد', 'اشتري بعملاتك ملابس لرغد وغرفًا جديدة، واحمي سلسلة أيامك بالحماية.'),
  ];
  final pc = PageController();
  var page = 0;
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (d) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        content: SizedBox(
          width: double.maxFinite,
          height: 250,
          child: Column(children: [
            Expanded(
              child: PageView(
                controller: pc,
                onPageChanged: (v) => set(() => page = v),
                children: [
                  for (final p in pages)
                    Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(p.$1, style: const TextStyle(fontSize: 64)),
                      const SizedBox(height: 8),
                      Text(p.$2, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 6),
                      Text(p.$3, textAlign: TextAlign.center, style: const TextStyle(height: 1.6)),
                    ]),
                ],
              ),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var i = 0; i < pages.length; i++)
                Container(
                  width: 9,
                  height: 9,
                  margin: const EdgeInsets.all(3),
                  decoration: BoxDecoration(shape: BoxShape.circle, color: i == page ? Brand.violet : Brand.violet.withValues(alpha: .2)),
                ),
            ]),
          ]),
        ),
        actions: [
          FilledButton(
            onPressed: () {
              if (page < pages.length - 1) {
                pc.nextPage(duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
              } else {
                Navigator.pop(d);
              }
            },
            child: Text(page < pages.length - 1 ? 'التالي' : 'ابدئي المغامرة! 🚀'),
          ),
        ],
      ),
    ),
  );
  pc.dispose();
  await store.putFlag('onboarded', true);
}

// ======================================================================
// نسخة احتياطية: نسخ/لصق نص JSON (بلا حاجة لصلاحيات أو إنترنت)
// ======================================================================
class BackupPage extends StatefulWidget {
  const BackupPage({super.key, required this.store, required this.onChanged});
  final ProgressStore store;
  final VoidCallback onChanged;
  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  final TextEditingController _c = TextEditingController();
  String _msg = '';
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.store.exportJson()));
    setState(() => _msg = '✅ نُسخت بياناتك. الصقيها في رسالة لنفسك أو في ملاحظات واحتفظي بها.');
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    if (d?.text != null) setState(() => _c.text = d!.text!);
  }

  Future<void> _restore() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('استعادة النسخة؟'),
        content: const Text('ستُستبدل بياناتك الحالية بمحتوى النسخة.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('استعادة')),
        ],
      ),
    );
    if (ok != true) return;
    final good = await widget.store.importJson(_c.text);
    widget.onChanged();
    setState(() => _msg = good ? '✅ تمت الاستعادة. أعيدي فتح التطبيق لتظهر كل البيانات.' : '❌ النص ليس نسخة صالحة من التطبيق.');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('نسخة احتياطية')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('احفظي تقدمك قبل تغيير الجهاز أو حذف التطبيق، ثم استعيديه عند الحاجة.', style: TextStyle(height: 1.6)),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: _copy, icon: const Icon(Icons.copy_rounded), label: const Text('انسخي بياناتي')),
          const Divider(height: 32),
          const Text('الاستعادة', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
          const SizedBox(height: 8),
          TextField(controller: _c, maxLines: 5, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'الصقي النسخة هنا')),
          Row(children: [
            TextButton.icon(onPressed: _paste, icon: const Icon(Icons.paste_rounded), label: const Text('لصق')),
            const Spacer(),
            FilledButton(onPressed: _c.text.trim().isEmpty ? null : _restore, child: const Text('استعادة')),
          ]),
          if (_msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_msg, style: const TextStyle(fontWeight: FontWeight.w800))),
        ]),
      );
}
