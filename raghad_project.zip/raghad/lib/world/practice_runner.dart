import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models.dart';
import '../progress_store.dart';
import '../quiz_engine.dart';
import 'brand.dart';
import 'fx.dart';
import 'sfx.dart';

class AnswerRecord {
  const AnswerRecord(this.q, this.ok);
  final Question q;
  final bool ok;
}

String correctText(Question q) {
  switch (q.type) {
    case 'fill':
      return q.accepted.isEmpty ? '' : q.accepted.first;
    case 'order':
      return q.options.join(' ← ');
    default:
      return q.answer >= 0 && q.answer < q.options.length ? q.options[q.answer] : '';
  }
}

/// مشغّل الأسئلة: يدعم اختيار من متعدد، صح/خطأ، إكمال، وترتيب،
/// مع تلميحات وعدّاد تتابع ومؤقت اختياري.
class PracticeRunner extends StatefulWidget {
  const PracticeRunner({
    super.key,
    required this.questions,
    required this.store,
    required this.onFinished,
    this.allowHints = true,
    this.seconds,
    this.accent = Brand.violet,
    this.adaptive = false,
  });
  final bool adaptive;
  final List<Question> questions;
  final ProgressStore store;
  final void Function(List<AnswerRecord> records, int secondsUsed) onFinished;
  final bool allowHints;
  final int? seconds;
  final Color accent;
  @override
  State<PracticeRunner> createState() => _PracticeRunnerState();
}

class _PracticeRunnerState extends State<PracticeRunner> {
  late final List<Question> _qs = QuizEngine.prepare(widget.questions);
  final TextEditingController _text = TextEditingController();
  final List<AnswerRecord> _records = [];
  final Set<int> _hidden = {};
  List<String> _picked = [];
  late List<String> _pool = _mkPool();
  String? _hintText;
  int _n = 0;
  int? _chosen;
  bool _answered = false;
  bool _ok = false;
  bool _hinted = false;
  bool _ended = false;
  int _wrongCount = 0;
  int _combo = 0;
  int _best = 0;
  int _used = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_ended || !mounted) return;
      setState(() => _used++);
      if (widget.seconds != null && _used >= widget.seconds!) _endAll();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _text.dispose();
    super.dispose();
  }

  List<String> _mkPool() {
    if (_qs.isEmpty || _qs[_n].type != 'order') return [];
    return [..._qs[_n].options]..shuffle();
  }

  void _feedback(bool ok) {
    if (ok) {
      Sfx.correct(combo: _combo);
    } else {
      Sfx.wrong();
    }
  }

  void _answer(bool ok, {int? chosen}) {
    if (_answered || _ended) return;
    setState(() {
      _answered = true;
      _ok = ok;
      _chosen = chosen;
      _records.add(AnswerRecord(_qs[_n], ok));
      if (ok && !_hinted) {
        _combo++;
        if (_combo > _best) _best = _combo;
      } else if (!ok) {
        _combo = 0;
        _wrongCount++;
      }
    });
    _feedback(ok);
  }

  /// يختار السؤال التالي بحسب مستوى الأداء: يصعد بعد إجابتين متتاليتين، وينزل بعد الخطأ.
  void _adaptNext() {
    if (!widget.adaptive || _n + 1 >= _qs.length) return;
    final cur = _qs[_n].difficulty;
    var target = cur;
    if (!_ok) {
      target = cur - 1;
    } else if (_combo >= 2) {
      target = cur + 1;
    }
    target = target.clamp(1, 3);
    var best = _n + 1;
    for (var i = _n + 1; i < _qs.length; i++) {
      if ((_qs[i].difficulty - target).abs() < (_qs[best].difficulty - target).abs()) best = i;
    }
    if (best != _n + 1) {
      final t = _qs[best];
      _qs[best] = _qs[_n + 1];
      _qs[_n + 1] = t;
    }
  }

  void _next() {
    _adaptNext();
    if (_n + 1 < _qs.length) {
      setState(() {
        _n++;
        _chosen = null;
        _answered = false;
        _ok = false;
        _hinted = false;
        _hintText = null;
        _hidden.clear();
        _picked = [];
        _text.clear();
        _pool = _mkPool();
      });
    } else {
      _endAll();
    }
  }

  void _endAll() {
    if (_ended) return;
    _ended = true;
    _timer?.cancel();
    // الأسئلة التي لم يُجب عنها تُحسب خطأ.
    final answeredIds = _records.map((r) => r.q.id).toSet();
    for (final q in _qs) {
      if (!answeredIds.contains(q.id)) _records.add(AnswerRecord(q, false));
    }
    widget.onFinished(_records, _used);
  }

  void _hint() {
    final q = _qs[_n];
    if (_answered || _hinted) return;
    setState(() {
      _hinted = true;
      switch (q.type) {
        case 'mcq':
          final wrong = [
            for (var i = 0; i < q.options.length; i++)
              if (i != q.answer) i
          ]..shuffle();
          _hidden.addAll(wrong.take(wrong.length >= 3 ? 2 : 1));
          _hintText = 'شطبتُ لكِ إجابات غير صحيحة 🔍';
        case 'fill':
          final a = correctText(q);
          _hintText = a.isEmpty ? null : 'الإجابة تبدأ بـ «${a[0]}» وطولها ${a.length}';
        case 'order':
          if (_picked.isEmpty && q.options.isNotEmpty) _picked = [q.options.first];
          _hintText = 'وضعتُ الخطوة الأولى لكِ 🧩';
        default:
          final e = q.explanation.split(RegExp(r'[.\n]')).first.trim();
          _hintText = e.isEmpty ? 'اقرئي العبارة ببطء وفكّري في القاعدة 🤔' : 'تذكّري: $e';
      }
    });
  }

  Widget _options(Question q) {
    final cs = Theme.of(context).colorScheme;
    return Column(children: [
      for (var i = 0; i < q.options.length; i++)
        if (!_hidden.contains(i))
          Pressable(
            onTap: _answered ? null : () => _answer(QuizEngine.isCorrect(q, i), chosen: i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(vertical: 6),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: !_answered
                    ? cs.surface
                    : i == q.answer
                        ? const Color(0xFFD7F5E3)
                        : i == _chosen
                            ? const Color(0xFFFFE1D6)
                            : cs.surface,
                border: Border.all(
                  width: 2,
                  color: !_answered
                      ? widget.accent.withValues(alpha: .25)
                      : i == q.answer
                          ? const Color(0xFF2EAD6B)
                          : i == _chosen
                              ? const Color(0xFFE5703F)
                              : widget.accent.withValues(alpha: .12),
                ),
              ),
              child: Row(children: [
                CircleAvatar(
                  radius: 15,
                  backgroundColor: widget.accent.withValues(alpha: .12),
                  child: Text(q.type == 'tf' ? (i == 0 ? '✓' : '✗') : ['أ', 'ب', 'ج', 'د'][i % 4],
                      style: TextStyle(fontWeight: FontWeight.w900, color: widget.accent)),
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: Text(q.options[i],
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: _answered && (i == q.answer || i == _chosen) ? Brand.ink : null))),
              ]),
            ),
          ),
    ]);
  }

  Widget _fill(Question q) => Column(children: [
        TextField(
          controller: _text,
          enabled: !_answered,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
          decoration: const InputDecoration(hintText: 'اكتبي إجابتك هنا'),
          onSubmitted: (_) => _answer(QuizEngine.checkText(q, _text.text)),
        ),
        const SizedBox(height: 12),
        if (!_answered)
          FilledButton(
              onPressed: () => _answer(QuizEngine.checkText(q, _text.text)),
              child: const Text('تحقّقي')),
      ]);

  Widget _order(Question q) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('اضغطي بالترتيب الصحيح:'),
        const SizedBox(height: 8),
        Container(
          constraints: const BoxConstraints(minHeight: 56),
          width: double.infinity,
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: widget.accent.withValues(alpha: .3), width: 2)),
          child: Wrap(spacing: 6, runSpacing: 6, children: [
            for (final p in _picked)
              InputChip(
                  label: Text(p),
                  onDeleted: _answered ? null : () => setState(() => _picked.remove(p))),
          ]),
        ),
        const SizedBox(height: 10),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (final p in _pool)
            if (!_picked.contains(p))
              ActionChip(
                  label: Text(p),
                  onPressed: _answered ? null : () => setState(() => _picked.add(p))),
        ]),
        const SizedBox(height: 12),
        if (!_answered)
          FilledButton(
              onPressed: _picked.length == q.options.length
                  ? () => _answer(QuizEngine.checkOrder(q, _picked))
                  : null,
              child: const Text('تحقّقي')),
      ]);

  String _clock(int s) => '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    if (_qs.isEmpty) return const Center(child: Text('لا توجد أسئلة'));
    final q = _qs[_n];
    final left = widget.seconds == null ? null : widget.seconds! - _used;
    return Stack(children: [
    Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
        child: Row(children: [
          IconButton(onPressed: () => Navigator.maybePop(context), icon: const Icon(Icons.close_rounded)),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: (_n + (_answered ? 1 : 0)) / _qs.length),
                duration: const Duration(milliseconds: 350),
                builder: (_, v, __) => LinearProgressIndicator(
                    value: v, minHeight: 12, color: widget.accent, backgroundColor: widget.accent.withValues(alpha: .12)),
              ),
            ),
          ),
          const SizedBox(width: 8),
          if (left != null)
            StatPill('⏱️', _clock(left < 0 ? 0 : left), light: false)
          else if (_combo >= 2)
            StatPill('🔥', 'x$_combo', light: false),
        ]),
      ),
      Expanded(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('سؤال ${_n + 1} من ${_qs.length}', style: TextStyle(color: widget.accent, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Shake(
              trigger: _wrongCount,
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    color: widget.accent.withValues(alpha: .08)),
                child: Text(q.text, style: const TextStyle(fontSize: 21, height: 1.6, fontWeight: FontWeight.w800)),
              ),
            ),
            if (_hintText != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text('💡 $_hintText', style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
            const SizedBox(height: 14),
            if (q.type == 'fill') _fill(q) else if (q.type == 'order') _order(q) else _options(q),
            if (widget.allowHints && !_answered && !_hinted)
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                    onPressed: _hint,
                    icon: const Icon(Icons.lightbulb_outline_rounded),
                    label: const Text('تلميح')),
              ),
          ]),
        ),
      ),
      if (_answered)
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _ok ? const Color(0xFFD7F5E3) : const Color(0xFFFFE9DF),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: SafeArea(
            top: false,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(_ok ? 'أحسنتِ! 🌟' : 'قريبة! الإجابة: ${correctText(q)}',
                  style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Brand.ink)),
              if (!_ok && _chosen != null && _chosen! < q.notes.length && q.notes[_chosen!].isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('💡 ${q.notes[_chosen!]}',
                      style: const TextStyle(color: Brand.ink, height: 1.5, fontWeight: FontWeight.w800)),
                ),
              if (q.explanation.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(q.explanation, style: const TextStyle(color: Brand.ink, height: 1.5)),
                ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: GameButton(
                  color: _ok ? const Color(0xFF2EAD6B) : const Color(0xFFE5703F),
                  onPressed: _next,
                  label: _n + 1 < _qs.length ? 'التالي' : 'إنهاء',
                ),
              ),
            ]),
          ),
        ),
    ]),
    if (_answered && _ok)
      Positioned.fill(
        child: Align(
          alignment: const Alignment(0, .2),
          child: ParticleBurst(key: ValueKey('b$_n'), seed: _n + 1, emojis: _combo >= 3 ? const ['🔥', '⭐', '✨'] : const ['⭐', '✨']),
        ),
      ),
    ]);
  }
}
