import 'package:flutter/material.dart';
import '../models.dart';
import '../progress_store.dart';
import 'rewards.dart';

/// محطة على الطريق: درس أو «زعيم» (اختبار الوحدة).
class MapNode {
  const MapNode({
    required this.id,
    required this.title,
    required this.islandId,
    this.lesson,
    this.bossQuestions = const [],
  });
  final String id;
  final String title;
  final String islandId;
  final Lesson? lesson;
  final List<Question> bossQuestions;
  bool get isBoss => lesson == null;
}

class UnitGroup {
  const UnitGroup(this.title, this.nodes);
  final String title;
  final List<MapNode> nodes;
}

class Island {
  const Island({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.emoji,
    required this.c1,
    required this.c2,
    required this.subject,
    required this.nodes,
    required this.units,
    this.archive = false,
  });
  final String id;
  final String name;
  final String subtitle;
  final String emoji;
  final Color c1;
  final Color c2;
  final Subject subject;
  final List<MapNode> nodes;
  final List<UnitGroup> units;
  final bool archive;

  int starsEarned(ProgressStore s) =>
      nodes.fold(0, (a, n) => a + s.starsOf(n.id));
  int get starsMax => nodes.length * 3;
  int doneCount(ProgressStore s) =>
      nodes.where((n) => s.starsOf(n.id) > 0).length;
  double progress(ProgressStore s) =>
      nodes.isEmpty ? 0 : doneCount(s) / nodes.length;

  /// المحطة تُفتح بعد نيل نجمة على الأقل في التي قبلها. الأرشيف مفتوح دائمًا.
  bool isUnlocked(ProgressStore s, int index) {
    if (archive || index == 0) return true;
    return s.starsOf(nodes[index - 1].id) > 0;
  }

  MapNode? nextNode(ProgressStore s) {
    for (var i = 0; i < nodes.length; i++) {
      if (s.starsOf(nodes[i].id) == 0 && isUnlocked(s, i)) return nodes[i];
    }
    return null;
  }
}

class _Style {
  const _Style(this.name, this.sub, this.emoji, this.c1, this.c2);
  final String name;
  final String sub;
  final String emoji;
  final Color c1;
  final Color c2;
}

const _styles = <String, _Style>{
  'math_ar': _Style('جزيرة الأرقام', 'رياضيات', '🔢', Color(0xFFFFB347), Color(0xFFFF7E5F)),
  'math_en': _Style('Number Island', 'Mathematics', '🔢', Color(0xFFFFB347), Color(0xFFFF7E5F)),
  'science_ar': _Style('جزيرة المعمل', 'علوم', '🔬', Color(0xFF43CBA0), Color(0xFF1B9E77)),
  'science_en': _Style('Science Lab', 'Science', '🔬', Color(0xFF43CBA0), Color(0xFF1B9E77)),
  'arabic': _Style('غابة الحروف', 'لغة عربية', '📖', Color(0xFFB57BEE), Color(0xFF7B4FD1)),
  'english': _Style('Word Bay', 'English – Connect', '🔤', Color(0xFF4CC9F0), Color(0xFF3A86FF)),
  'english_plus': _Style('Word Bay Plus', 'English – Connect Plus', '🔤', Color(0xFF4CC9F0), Color(0xFF3A86FF)),
  'social': _Style('جزيرة الخرائط', 'دراسات اجتماعية', '🌍', Color(0xFF90C95B), Color(0xFF4F9D2D)),
  'religion_islamic': _Style('واحة القيم', 'تربية إسلامية', '🕌', Color(0xFF5EC6B8), Color(0xFF2A9D8F)),
  'religion_christian': _Style('واحة المحبة', 'تربية مسيحية', '🕊️', Color(0xFF8EB8FF), Color(0xFF5A8DEE)),
  'ict': _Style('جزيرة التقنية', 'تكنولوجيا المعلومات', '💻', Color(0xFF6C8CFF), Color(0xFF3F51D8)),
  'library': _Style('كهف الباحثين', 'مكتبة وبحث', '🔎', Color(0xFFC49A6C), Color(0xFF8D6A44)),
  'agriculture': _Style('مزرعة المستقبل', 'زراعة وريادة', '🌱', Color(0xFFA8E063), Color(0xFF56AB2F)),
  'family_management': _Style('بيت المهارات', 'إدارة الأسرة وريادة الأعمال', '🏡', Color(0xFFFF9EC4), Color(0xFFE5589A)),
  'cms': _Style('جزيرة ولي الأمر', 'دروس أضافها ولي الأمر', '🎁', Color(0xFFFFD166), Color(0xFFEF8354)),
};

const _hidden = {'math_fr', 'science_fr'};

final _unitRe = RegExp(r'-u(\d+)-');

/// يبني الجزر من المحتوى. نسخ المسارات المكررة تُخفى حسب مسار المدرسة.
List<Island> buildIslands(Content content, ProgressStore store) {
  final langs = store.str('schoolTrack') == 'languages';
  final religion = store.str('religionTrack') ?? 'both';
  final out = <Island>[];
  final archive = <Island>[];
  for (final s in content.subjects) {
    if (_hidden.contains(s.id) || s.lessons.isEmpty) continue;
    if (religion == 'islamic' && s.id.contains('christian')) continue;
    if (religion == 'christian' && s.id.contains('islamic')) continue;
    if (langs) {
      if (s.id == 'math_ar' || s.id == 'science_ar' || s.id == 'english') continue;
    } else {
      if (s.id == 'math_en' || s.id == 'science_en' || s.id == 'english_plus') continue;
    }
    final isArchive = s.id.endsWith('_2025_2026');
    final st = _styles[s.id] ??
        (isArchive
            ? const _Style('أرشيف العام السابق', 'منهج ٢٠٢٥/٢٠٢٦', '🗄️', Color(0xFFB0A8C9), Color(0xFF7D7599))
            : const _Style('جزيرة جديدة', 'دروس إضافية', '🏝️', Color(0xFF6DD5ED), Color(0xFF2193B0)));
    final name = isArchive ? '${st.name}: ${s.name}' : st.name;

    // تجميع الدروس في وحدات: من رقم الوحدة في المعرّف، وإلا كل ٤ دروس وحدة.
    final order = <String>[];
    final groups = <String, List<Lesson>>{};
    for (var i = 0; i < s.lessons.length; i++) {
      final l = s.lessons[i];
      final m = _unitRe.firstMatch(l.id);
      final key = m != null ? 'u${m.group(1)}' : 'c${i ~/ 4}';
      if (!groups.containsKey(key)) order.add(key);
      groups.putIfAbsent(key, () => []).add(l);
    }
    final units = <UnitGroup>[];
    final nodes = <MapNode>[];
    for (var u = 0; u < order.length; u++) {
      final ls = groups[order[u]]!;
      final un = <MapNode>[
        for (final l in ls)
          MapNode(id: l.id, title: l.title, islandId: s.id, lesson: l),
      ];
      if (ls.length >= 2) {
        un.add(MapNode(
          id: 'boss:${s.id}:${order[u]}',
          title: 'تحدي الوحدة ${u + 1}',
          islandId: s.id,
          bossQuestions: [for (final l in ls) ...l.questions],
        ));
      }
      units.add(UnitGroup('الوحدة ${u + 1}', un));
      nodes.addAll(un);
    }
    final island = Island(
      id: s.id,
      name: name,
      subtitle: st.sub,
      emoji: st.emoji,
      c1: st.c1,
      c2: st.c2,
      subject: s,
      nodes: nodes,
      units: units,
      archive: isArchive,
    );
    (isArchive ? archive : out).add(island);
  }
  return [...out, ...archive];
}

/// أول محطة لم تُنجز عبر كل الجزر الرئيسية (للزر «كملي رحلتك»).
({Island island, MapNode node})? continuePoint(
    List<Island> islands, ProgressStore s) {
  final lastId = s.lastLesson;
  if (lastId != null) {
    for (final i in islands) {
      if (i.archive) continue;
      for (var k = 0; k < i.nodes.length; k++) {
        if (i.nodes[k].id == lastId) {
          // الأقرب هو المحطة التالية غير المنجزة بعدها، أو نفس المحطة.
          for (var j = k; j < i.nodes.length; j++) {
            if (s.starsOf(i.nodes[j].id) == 0 && i.isUnlocked(s, j)) {
              return (island: i, node: i.nodes[j]);
            }
          }
        }
      }
    }
  }
  for (final i in islands) {
    if (i.archive) continue;
    final n = i.nextNode(s);
    if (n != null) return (island: i, node: n);
  }
  return null;
}
