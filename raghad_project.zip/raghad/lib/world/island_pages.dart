import 'dart:math';
import 'package:flutter/material.dart';
import '../progress_store.dart';
import 'brand.dart';
import 'fx.dart';
import 'games.dart';
import 'sfx.dart';
import 'lesson_flow.dart';
import 'rewards.dart';
import 'world_data.dart';

/// خريطة الجزر: كل مادة جزيرة بتقدمها ونجومها.
class IslandsPage extends StatelessWidget {
  const IslandsPage({super.key, required this.store, required this.islands, required this.onChanged});
  final ProgressStore store;
  final List<Island> islands;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    final main = islands.where((i) => !i.archive).toList();
    final arch = islands.where((i) => i.archive).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(14, 10, 14, 24), children: [
      Row(children: [
        const Text('🗺️', style: TextStyle(fontSize: 28)),
        const SizedBox(width: 8),
        Text('خريطة المغامرة', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
        const Spacer(),
        StatPill('⭐', '${store.totalStars}', light: false),
      ]),
      const SizedBox(height: 6),
      for (final i in main) _IslandCard(island: i, store: store, onChanged: onChanged),
      if (arch.isNotEmpty) ...[
        const Padding(
            padding: EdgeInsets.only(top: 16, bottom: 2),
            child: Text('🗄️ أرشيف العام السابق', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
        for (final i in arch) _IslandCard(island: i, store: store, onChanged: onChanged),
      ],
    ]);
  }
}

class _IslandCard extends StatelessWidget {
  const _IslandCard({required this.island, required this.store, required this.onChanged});
  final Island island;
  final ProgressStore store;
  final VoidCallback onChanged;
  @override
  Widget build(BuildContext context) {
    final done = island.doneCount(store);
    return GradientCard(
      colors: [island.c1, island.c2],
      onTap: () async {
        await Navigator.push(
            context, MaterialPageRoute<void>(builder: (_) => IslandPathPage(island: island, store: store)));
        onChanged();
      },
      child: Row(children: [
        Container(
          width: 74,
          height: 74,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: Colors.white.withValues(alpha: .22), shape: BoxShape.circle),
          child: Text(island.emoji, style: const TextStyle(fontSize: 38)),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(island.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
            Text(island.subtitle, style: const TextStyle(color: Colors.white70, fontSize: 13)),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                  value: island.progress(store),
                  minHeight: 9,
                  backgroundColor: Colors.white30,
                  color: Colors.white),
            ),
            const SizedBox(height: 4),
            Text('$done / ${island.nodes.length} محطة • ⭐ ${island.starsEarned(store)}/${island.starsMax}',
                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
          ]),
        ),
        const Icon(Icons.chevron_left_rounded, color: Colors.white),
      ]),
    );
  }
}

/// طريق الجزيرة: محطات متعرّجة، وتُفتح واحدة بعد الأخرى.
class IslandPathPage extends StatefulWidget {
  const IslandPathPage({super.key, required this.island, required this.store});
  final Island island;
  final ProgressStore store;
  @override
  State<IslandPathPage> createState() => _IslandPathPageState();
}

class _IslandPathPageState extends State<IslandPathPage> {
  static const _rowH = 128.0;

  Future<void> _open(int index) async {
    final isl = widget.island;
    final node = isl.nodes[index];
    if (!isl.isUnlocked(widget.store, index)) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('أكملي المحطة السابقة أولًا لفتح هذه المحطة 🔒')));
      return;
    }
    final stars = widget.store.starsOf(node.id);
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheet) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 4, 22, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(node.isBoss ? '👹 ${node.title}' : node.title,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Row(children: [StarRow(stars, size: 24), const Spacer()]),
          const SizedBox(height: 8),
          if (node.isBoss)
            Text('اختبار شامل على دروس الوحدة: ${min(10, node.bossQuestions.length)} أسئلة بمؤقت. اجمعي ٣ نجوم لتفوزي بصندوق وجواهر!')
          else
            for (final o in node.lesson!.objectives) Text('• $o', style: const TextStyle(height: 1.7)),
          const SizedBox(height: 16),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: isl.c2),
            onPressed: () {
              Navigator.pop(sheet);
              _start(node);
            },
            child: Text(node.isBoss ? 'اخوضي التحدي!' : stars > 0 ? 'راجعي الدرس' : 'ابدئي الدرس'),
          ),
        ]),
      ),
    );
  }

  Future<void> _start(MapNode node) async {
    final isl = widget.island;
    final Widget page;
    if (node.isBoss) {
      final qs = [...node.bossQuestions]..shuffle();
      page = BossBattlePage(
          store: widget.store,
          questions: qs,
          bossName: 'زعيم ${isl.name}',
          bossEmoji: bossEmojis[isl.id.hashCode.abs() % bossEmojis.length],
          accent: isl.c2,
          nodeId: node.id);
    } else {
      page = LessonFlowPage(lesson: node.lesson!, store: widget.store, accent: isl.c2, nodeId: node.id);
    }
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page));
    if (mounted) setState(() {});
    if (mounted && isl.doneCount(widget.store) == isl.nodes.length && await widget.store.awardIsland(isl.id)) {
      Sfx.play('levelup');
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (d) => Stack(alignment: Alignment.center, children: [
          AlertDialog(
            title: const Text('🏅 ميدالية الجزيرة!', textAlign: TextAlign.center),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(isl.emoji, style: const TextStyle(fontSize: 64)),
              Text('أنهيتِ ${isl.name} كاملة!', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Wrap(spacing: 8, children: [StatPill('💎', '+5', light: false), StatPill('🎁', '+1 صندوق', light: false)]),
            ]),
            actions: [FilledButton(onPressed: () => Navigator.pop(d), child: const Text('رائع!'))],
          ),
          const IgnorePointer(child: ParticleBurst(count: 30, emojis: ['🏅', '⭐', '🎉', '✨'])),
        ]),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isl = widget.island;
    final s = widget.store;
    final nodes = isl.nodes;
    return Scaffold(
      appBar: AppBar(
        title: Text('${isl.emoji} ${isl.name}'),
        backgroundColor: isl.c1.withValues(alpha: .25),
      ),
      body: LayoutBuilder(builder: (context, box) {
        final w = box.maxWidth;
        final pts = <Offset>[
          for (var i = 0; i < nodes.length; i++)
            Offset(w / 2 + sin(i * 1.15) * w * .26, 70 + i * _rowH)
        ];
        final next = isl.nextNode(s);
        return SingleChildScrollView(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [isl.c1.withValues(alpha: .20), Theme.of(context).scaffoldBackgroundColor]),
            ),
            child: SizedBox(
              height: nodes.length * _rowH + 150,
              width: w,
              child: CustomPaint(
                painter: _PathPainter(pts, isl.c2, [for (var i = 0; i < nodes.length; i++) s.starsOf(nodes[i].id) > 0]),
                child: Stack(children: [
                  for (var i = 0; i < nodes.length; i++)
                    Positioned(
                      left: pts[i].dx - 56,
                      top: pts[i].dy - 40,
                      width: 112,
                      child: _NodeBubble(
                        node: nodes[i],
                        stars: s.starsOf(nodes[i].id),
                        unlocked: isl.isUnlocked(s, i),
                        current: next?.id == nodes[i].id,
                        island: isl,
                        onTap: () => _open(i),
                      ),
                    ),
                ]),
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _PathPainter extends CustomPainter {
  _PathPainter(this.pts, this.color, this.done);
  final List<Offset> pts;
  final Color color;
  final List<bool> done;
  @override
  void paint(Canvas c, Size s) {
    for (var i = 0; i + 1 < pts.length; i++) {
      final a = pts[i], b = pts[i + 1];
      final path = Path()
        ..moveTo(a.dx, a.dy)
        ..cubicTo(a.dx, a.dy + 60, b.dx, b.dy - 60, b.dx, b.dy);
      c.drawPath(
          path,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeWidth = 12
            ..color = done[i] ? color.withValues(alpha: .55) : Colors.grey.withValues(alpha: .25));
    }
  }

  @override
  bool shouldRepaint(covariant _PathPainter o) => o.pts.length != pts.length || o.color != color || o.done != done;
}

class _NodeBubble extends StatelessWidget {
  const _NodeBubble({
    required this.node,
    required this.stars,
    required this.unlocked,
    required this.current,
    required this.island,
    required this.onTap,
  });
  final MapNode node;
  final int stars;
  final bool unlocked;
  final bool current;
  final Island island;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final done = stars > 0;
    final base = unlocked ? island.c2 : Colors.grey.shade400;
    return Pressable(
      onTap: onTap,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
          if (current)
            TweenAnimationBuilder<double>(
              tween: Tween(begin: .9, end: 1.15),
              duration: const Duration(milliseconds: 900),
              curve: Curves.easeInOut,
              builder: (_, v, __) => Transform.scale(
                  scale: v,
                  child: Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: island.c1.withValues(alpha: .35)))),
            ),
          Container(
            width: node.isBoss ? 74 : 66,
            height: node.isBoss ? 74 : 66,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: unlocked ? [island.c1, island.c2] : [Colors.grey.shade300, Colors.grey.shade500]),
              border: Border.all(color: Colors.white, width: 4),
              boxShadow: [BoxShadow(color: base.withValues(alpha: .4), blurRadius: 12, offset: const Offset(0, 6))],
            ),
            child: !unlocked
                ? const Icon(Icons.lock_rounded, color: Colors.white, size: 28)
                : node.isBoss
                    ? const Text('👹', style: TextStyle(fontSize: 32))
                    : done
                        ? const Icon(Icons.check_rounded, color: Colors.white, size: 34)
                        : const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 38),
          ),
        ]),
        const SizedBox(height: 4),
        if (done) StarRow(stars, size: 16),
        Text(node.title,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: unlocked ? null : Colors.grey)),
      ]),
    );
  }
}
