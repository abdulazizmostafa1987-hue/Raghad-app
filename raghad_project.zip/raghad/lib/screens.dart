import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'models.dart';
import 'progress_store.dart';
import 'quiz_engine.dart';
import 'screens2.dart';
import 'screens3.dart';
import 'widgets.dart';
import 'dart:async';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class Shell extends StatefulWidget {
  const Shell({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;
  late Content _c = widget.content;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _askName());
  }

  Future<void> _askName() async {
    if (widget.store.str('name') != null || !mounted) return;
    final c = TextEditingController();
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (d) => AlertDialog(
        title: const Text('مرحبًا! ما اسمك؟'),
        content: TextField(controller: c, decoration: const InputDecoration(hintText: 'اسمك')),
        actions: [FilledButton(onPressed: () => Navigator.pop(d), child: const Text('ابدئي'))],
      ),
    );
    final n = c.text.trim();
    c.dispose();
    await widget.store.putStr('name', n.isEmpty ? 'رغد' : n);
    if (mounted) setState(() {});
  }
  void _refresh() => setState(() {});
  Future<void> _reload() async {
    final c = await Content.load(widget.store);
    if (mounted) setState(() => _c = c);
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomePage(store: widget.store, content: _c, onChanged: _refresh),
      LibraryPage(store: widget.store, content: _c, onChanged: _refresh),
      AchievementsPage(store: widget.store),
      GamesPage(content: _c, store: widget.store),
      AccountPage(store: widget.store, content: _c, onChanged: _refresh, onReload: _reload),
    ];
    return Scaffold(
      appBar: AppBar(leading: Padding(padding: const EdgeInsets.all(9), child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/branding/raghad_brand.png', fit: BoxFit.cover))), title: const Text('رغد – رحلتي نحو التفوق'), actions: [IconButton(tooltip: 'الصوت', icon: Icon(widget.store.flag('soundOn', def: true) ? Icons.volume_up_rounded : Icons.volume_off_rounded), onPressed: () async { final v = !widget.store.flag('soundOn', def: true); await widget.store.putFlag('soundOn', v); if (v) SystemSound.play(SystemSoundType.click); setState(() {}); })]),
      body: pages[_i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) { if (widget.store.flag('focusMode') && (v == 2 || v == 3)) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('وضع التركيز مفعّل؛ الإنجازات والألعاب متوقفة مؤقتًا.'))); return; } if (widget.store.flag('soundOn', def: true)) SystemSound.play(SystemSoundType.click); if (widget.store.flag('hapticsOn', def: true)) HapticFeedback.selectionClick(); setState(() => _i = v); },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'المكتبة'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'إنجازاتي'),
          NavigationDestination(icon: Icon(Icons.extension_outlined), label: 'الألعاب'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

Lesson? _findLesson(Content c, String? id) {
  for (final s in c.subjects) {
    for (final l in s.lessons) {
      if (l.id == id) return l;
    }
  }
  return null;
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.store, required this.content, required this.onChanged});
  final ProgressStore store;
  final Content content;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    final last = _findLesson(content, store.lastLesson);
    return ListView(padding: const EdgeInsets.all(16), children: [
      HomeHeader(store: store),
      Card(child: ListTile(
        leading: const Icon(Icons.timer_outlined),
        title: const Text('ابدئي جلسة مذاكرة'),
        subtitle: Text('جلسة هادئة لمدة ${store.getInt('sessionMinutes', 20)} دقيقة'),
        trailing: const Icon(Icons.chevron_left),
        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => StudySessionPage(store: store))).then((_) => onChanged()),
      )),
      Card(color: Theme.of(context).colorScheme.primaryContainer, child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [const Icon(Icons.auto_awesome, size: 30), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('مهمتك الصغيرة اليوم', style: Theme.of(context).textTheme.titleMedium), const Text('خطوة قصيرة كل يوم تصنع فرقًا كبيرًا ✨')]))]))),
      if (last != null)
        Card(
          child: ListTile(
            leading: const Icon(Icons.play_circle),
            title: const Text('استكمل من حيث توقفت'),
            subtitle: Text(last.title),
            onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                        builder: (_) => LessonPage(lesson: last, store: store)))
                .then((_) => onChanged()),
          ),
        ),
      if (content.allQuestions.isNotEmpty)
        Card(
          child: ListTile(
            leading: const Icon(Icons.bolt),
            title: const Text('تحدي اليوم'),
            subtitle: const Text('٥ أسئلة متنوعة'),
            onTap: () {
              final d = DateTime.now();
              final qs = ([...content.allQuestions]
                    ..shuffle(Random(d.year * 10000 + d.month * 100 + d.day)))
                  .take(5)
                  .toList();
              Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                          builder: (_) =>
                              QuizPage(lessonId: 'daily', questions: qs, store: store)))
                  .then((_) => onChanged());
            },
          ),
        ),
      if (store.flag('focusMode'))
        const Card(child: ListTile(leading: Icon(Icons.center_focus_strong), title: Text('وضع التركيز مفعّل'), subtitle: Text('الألعاب والمكافآت ليست ضمن شاشة الدرس.'))),
      if (content.isSample)
        const Card(
          child: ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('المحتوى الحالي تجريبي'),
            subtitle: Text('لم يُعتمد بعد من المنهج الرسمي.'),
          ),
        ),
    ]);
  }
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key, required this.store, required this.content, required this.onChanged});
  final ProgressStore store;
  final Content content;
  final VoidCallback onChanged;

  Future<void> _openSource(BuildContext context, String url) async {
    final uri = Uri.parse(url);
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر فتح المصدر. تحققي من اتصال الإنترنت.')),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر فتح المصدر حاليًا.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final track = store.str('schoolTrack') ?? 'arabic';
    final religion = store.str('religionTrack') ?? 'both';
    final ministry = 'https://ellibrary.moe.gov.eg/books/';
    final mathBook = 'https://elearnningcontent.blob.core.windows.net/elearnningcontent/2026_2027/Primary/Primary6/Term1/StudentBook/Math_Primary6_T1.pdf';
    final items = <(String, String, IconData, Color, String, String)>[
      ('اللغة العربية', 'القراءة والنصوص والنحو والتعبير', Icons.menu_book_rounded, const Color(0xFF8E65C7), ministry, 'arabic'),
      (track == 'languages' ? 'English – Connect Plus' : 'English – Connect', 'المفردات والقواعد والقراءة والاستماع', Icons.translate_rounded, const Color(0xFF36A6A0), ministry, track == 'languages' ? 'english_plus' : 'english'),
      (track == 'languages' ? 'Mathematics – English' : 'الرياضيات', 'الحس العددي والجبر والإحصاء', Icons.calculate_rounded, const Color(0xFFE6A33B), mathBook, track == 'languages' ? 'math_en' : 'math_ar'),
      ('العلوم', 'الفهم العلمي والاستكشاف والتجارب الآمنة', Icons.science_rounded, const Color(0xFF4C9D79), ministry, track == 'languages' ? 'science_en' : 'science_ar'),
      ('الدراسات الاجتماعية', 'التاريخ والجغرافيا والخرائط', Icons.public_rounded, const Color(0xFF4C8FC4), ministry, 'social'),
      if (religion == 'both' || religion == 'islamic') ('التربية الدينية الإسلامية', 'القيم والعبادات والسيرة', Icons.auto_stories_rounded, const Color(0xFF54A58A), ministry, 'religion_islamic'),
      if (religion == 'both' || religion == 'christian') ('التربية الدينية المسيحية', 'القيم والتعاليم الدينية', Icons.church_rounded, const Color(0xFF9B83C8), ministry, 'religion_christian'),
      ('تكنولوجيا المعلومات والاتصالات', 'المهارات الرقمية والاستخدام المسؤول', Icons.computer_rounded, const Color(0xFF5686C5), ministry, 'ict'),
      ('المكتبات ومهارات البحث', 'البحث عن المعلومات وتقييم المصادر', Icons.search_rounded, const Color(0xFFB57A9D), ministry, 'library'),
      ('مهارات الزراعة وريادة الأعمال', 'الزراعة والتخطيط والمشروعات الصغيرة', Icons.eco_rounded, const Color(0xFF79A75C), ministry, 'agriculture'),
      ('مهارات إدارة الأسرة وريادة الأعمال', 'التعاون والتخطيط والمهارات الحياتية', Icons.groups_rounded, const Color(0xFFD18C55), ministry, 'family_management'),
    ];
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF7045B5), Color(0xFF9B70D1), Color(0xFFE99ABF)],
              begin: Alignment.topRight, end: Alignment.bottomLeft,
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Row(children: [
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('مدينة المعرفة 🏰', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 21)),
              SizedBox(height: 6),
              Text('اختاري عالمًا، تعلّمي فكرة، واجمعي نجوم المعرفة!', style: TextStyle(color: Colors.white, height: 1.4)),
            ])),
            const SizedBox(width: 12),
            const Icon(Icons.auto_awesome, color: Color(0xFFFFE28A), size: 52),
          ]),
        ),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.verified_outlined)),
            title: const Text('مصدر الكتب الرسمية'),
            subtitle: const Text('مكتبة وزارة التربية والتعليم – اختاري الصف السادس والمادة والفصل.'),
            trailing: const Icon(Icons.open_in_new),
            onTap: () => _openSource(context, ministry),
          ),
        ),
        Card(
          color: Theme.of(context).colorScheme.secondaryContainer,
          child: const Padding(
            padding: EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('حالة محتوى المنهج 2026/2027', style: TextStyle(fontWeight: FontWeight.w900)),
              SizedBox(height: 5),
              Text('تضم النسخة 225 درسًا مساندًا موزعة على 18 مسارًا/حزمة محتوى، مع ثلاثة أسئلة على الأقل لكل درس. وهي محتويات أصلية مساندة وليست بديلًا عن مراجعة الكتاب الرسمي.'),
              SizedBox(height: 5),
              Text('الفصل الثاني: ننتظر نشر كتب العام 2026/2027 رسميًا. لن نستخدم كتب سنة سابقة على أنها المنهج الحالي.'),
            ]),
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(4, 14, 4, 8),
          child: Text('عوالم التعلم', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        ),
        for (var i = 0; i < items.length; i++)
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.94, end: 1),
            duration: Duration(milliseconds: 260 + i * 35),
            curve: Curves.easeOutBack,
            builder: (context, scale, child) => Transform.scale(scale: scale, child: child),
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () {
                final matches = content.subjects.where((s) => s.id == items[i].$6).toList();
                if (matches.isNotEmpty && matches.first.lessons.isNotEmpty) {
                  Navigator.push(context, MaterialPageRoute<void>(
                    builder: (_) => SubjectLessonsPage(subject: matches.first, store: store),
                  ));
                } else {
                  _openSource(context, items[i].$5);
                }
              },
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    Container(
                      width: 54, height: 54,
                      decoration: BoxDecoration(color: items[i].$4.withValues(alpha: .15), borderRadius: BorderRadius.circular(17)),
                      child: Icon(items[i].$3, color: items[i].$4, size: 29),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(items[i].$1, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                      const SizedBox(height: 3),
                      Text(items[i].$2, style: Theme.of(context).textTheme.bodySmall),
                      const SizedBox(height: 5),
                      Text(
                        content.subjects.where((s) => s.id == items[i].$6).isNotEmpty
                            ? '${content.subjects.firstWhere((s) => s.id == items[i].$6).lessons.length} دروس واختبارات مساندة • اضغطي للفتح'
                            : 'افتحي الكتاب الرسمي',
                        style: const TextStyle(fontSize: 11, color: Colors.blueGrey),
                      ),
                    ])),
                    const Icon(Icons.arrow_forward_ios_rounded, size: 16),
                  ]),
                ),
              ),
            ),
          ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.tertiaryContainer,
            borderRadius: BorderRadius.circular(18),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('مهم: حالة المحتوى', style: TextStyle(fontWeight: FontWeight.w900)),
            SizedBox(height: 5),
            Text('تضم النسخة الحالية 225 درسًا مساندًا موزعة على 18 مسارًا/حزمة محتوى. المسارات اللغوية Math/Science تقدم شرحًا عربيًا مساندًا، وليست ترجمة رسمية. راجعي كتاب المدرسة للتأكد من ترتيب المنهج وتفاصيله.'),
          ]),
        ),
        Card(
          color: Theme.of(context).colorScheme.errorContainer,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('الفصل الدراسي الثاني – أرشيف 2025/2026', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('تنبيه: هذه مراجع من العام الدراسي السابق فقط، وليست منهج 2026/2027. لا تعتمدي عليها كمنهج حالي، وقد تختلف الدروس والتقييمات عند صدور كتب العام الجديد.'),
              const SizedBox(height: 8),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.menu_book_outlined),
                title: const Text('كتاب اللغة العربية – الفصل الثاني 2025/2026'),
                trailing: const Icon(Icons.open_in_new),
                onTap: () => _openSource(context, 'https://elearnningcontent.blob.core.windows.net/elearnningcontent/2026/Primary/Primary6/Term2/StudentBook/Arabic_prim6_TR2.pdf'),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.menu_book_outlined),
                title: const Text('كتاب التربية الدينية المسيحية – الفصل الثاني 2025/2026'),
                trailing: const Icon(Icons.open_in_new),
                onTap: () => _openSource(context, 'https://elearnningcontent.blob.core.windows.net/elearnningcontent/2026/Primary/Primary6/Term2/StudentBook/CH_prim6_Tr2.pdf'),
              ),
              for (final archiveId in ['arabic_term2_2025_2026', 'christian_term2_2025_2026'])
                Builder(builder: (context) {
                  final archived = content.subjects.where((s) => s.id == archiveId).toList();
                  if (archived.isEmpty) return const SizedBox.shrink();
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.quiz_outlined),
                    title: Text(archived.first.name),
                    subtitle: Text('${archived.first.lessons.length} درسًا واختبارًا مساندًا'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Navigator.push(context, MaterialPageRoute<void>(
                      builder: (_) => SubjectLessonsPage(subject: archived.first, store: store),
                    )),
                  );
                }),
              const Text('أُضيفت دروس واختبارات مساندة من فهرس الكتابين. هذا أرشيف للعام 2025/2026 فقط، وليس منهج 2026/2027.', style: TextStyle(fontSize: 12)),
            ]),
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(4, 16, 4, 6),
          child: Text('خريطة الرياضيات – الفصل الدراسي الأول', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        ),
        const Text('أسماء الوحدات والدروس التالية من فهرس كتاب الوزارة. علامة «متاح» تعني وجود شرح وتدريبات داخل التطبيق؛ أما «في الكتاب» فتفتحين موضوعه في الكتاب الرسمي.'),
        for (final unit in <(String, List<String>)>[
          ('الوحدة ١ • قابلية القسمة والعوامل والمضاعفات', ['قابلية القسمة', 'تحليل العدد إلى عوامله الأولية', 'كتابة تعبيرات عددية باستخدام العامل المشترك الأكبر', 'تحليل المضاعف المشترك الأصغر']),
          ('الوحدة ٢ • الأعداد النسبية', ['استخدام خط الأعداد لوصف البيانات', 'استخدام خط الأعداد والرموز لمقارنة الأعداد', 'تحليل الأعداد النسبية باستخدام النماذج', 'مقارنة الأعداد النسبية وترتيبها', 'استكشاف القيمة المطلقة', 'مقارنة القيم المطلقة']),
          ('الوحدة ٣ • المقادير الجبرية', ['تكوين تعبيرات رياضية', 'تحليل التعبيرات الرياضية', 'كتابة مقادير جبرية', 'ترتيب العمليات والأسس', 'إيجاد قيمة المقدار الجبري', 'تطبيقات على المقادير الجبرية', 'تحديد المقادير الجبرية المتكافئة']),
          ('الوحدة ٤ • المعادلات والمتباينات', ['حل المعادلات', 'استكشاف المتباينات', 'حل المتباينات']),
          ('الوحدة ٥ • المتغيرات التابعة والمستقلة', ['العلاقة بين المتغير التابع والمتغير المستقل', 'تطبيقات على المتغيرات التابعة والمستقلة', 'تحليل العلاقة بين المتغير التابع والمستقل', 'التمثيل البياني للمتغيرات التابعة والمستقلة']),
          ('الوحدة ٦ • توزيع البيانات', ['البيانات والأسئلة الإحصائية', 'استكشاف المدرج التكراري', 'تمثيل البيانات بالمدرج التكراري', 'استكشاف المخطط الصندوقي', 'تطبيقات على التمثيلات البيانية']),
          ('الوحدة ٧ • مقاييس النزعة المركزية والانتشار', ['استكشاف توازن مجموعات البيانات', 'تفسير الوسط الحسابي', 'استكشاف الوسيط والمنوال والقيم المتطرفة', 'استكشاف المدى']),
        ])
          Card(
            child: ExpansionTile(
              title: Text(unit.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${unit.$2.length} دروس في فهرس الكتاب'),
              children: [
                for (final title in unit.$2)
                  Builder(builder: (context) {
                    final available = content.subjects.expand((s) => s.lessons).any((l) => l.title == title);
                    final matches = content.subjects
                        .where((s) => s.id == 'math_ar')
                        .expand((s) => s.lessons)
                        .where((l) => l.title == title)
                        .toList();
                    return ListTile(
                      dense: true,
                      leading: Icon(available ? Icons.check_circle_rounded : Icons.menu_book_outlined,
                          color: available ? Colors.green : Theme.of(context).colorScheme.outline),
                      title: Text(title),
                      subtitle: Text(available ? 'شرح واختبار داخل رغد' : 'افتحي الكتاب الرسمي'),
                      onTap: () {
                        if (matches.isNotEmpty) {
                          Navigator.push(context, MaterialPageRoute<void>(
                            builder: (_) => LessonPage(lesson: matches.first, store: store),
                          ));
                        } else {
                          _openSource(context, mathBook);
                        }
                      },
                    );
                  }),
              ],
            ),
          ),
        for (final subject in content.subjects)
          ExpansionTile(
            title: Text(subject.name),
            subtitle: Text('${subject.lessons.length} دروس تفاعلية متاحة'),
            children: [
              for (final lesson in subject.lessons)
                ListTile(
                  leading: const Icon(Icons.stars_rounded, color: Colors.amber),
                  title: Text(lesson.title),
                  subtitle: Text('${lesson.questions.length} تدريبات • شرح مبسط'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () async {
                    await store.setLastLesson(lesson.id, title: lesson.title);
                    if (!context.mounted) return;
                    await Navigator.push(context, MaterialPageRoute<void>(
                      builder: (_) => LessonPage(lesson: lesson, store: store),
                    ));
                    onChanged();
                  },
                ),
            ],
          ),
      ],
    );
  }
}

class SubjectLessonsPage extends StatelessWidget {
  const SubjectLessonsPage({super.key, required this.subject, required this.store});
  final Subject subject;
  final ProgressStore store;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(subject.name),),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                'هذه دروس وشروح واختبارات أصلية مساندة. راجعي كتاب المدرسة الرسمي للتأكد من مطابقة ترتيب الدروس وتفاصيل المنهج.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ),
          for (final lesson in subject.lessons)
            Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.menu_book_rounded)),
                title: Text(lesson.title),
                subtitle: Text('${lesson.questions.length} أسئلة • شرح وأهداف'),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => Navigator.push(context, MaterialPageRoute<void>(
                  builder: (_) => LessonPage(lesson: lesson, store: store),
                )),
              ),
            ),
        ],
      ),
    );
  }
}

class LessonPage extends StatefulWidget {
  const LessonPage({super.key, required this.lesson, required this.store});
  final Lesson lesson;
  final ProgressStore store;
  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  late final TextEditingController _note =
      TextEditingController(text: widget.store.note(widget.lesson.id));
  final FlutterTts _tts = FlutterTts();
  bool _speaking = false;

  @override
  void initState() {
    super.initState();
    _tts.setCompletionHandler(() { if (mounted) setState(() => _speaking = false); });
    _tts.setCancelHandler(() { if (mounted) setState(() => _speaking = false); });
  }

  Future<void> _toggleSpeak() async {
    try {
      if (_speaking) {
        await _tts.stop();
      } else {
        await _tts.setLanguage('ar');
        await _tts.setSpeechRate(0.4);
        await _tts.speak(widget.lesson.body);
      }
      setState(() => _speaking = !_speaking);
    } catch (_) {}
  }

  @override
  void dispose() {
    _tts.stop();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.lesson;
    final fav = widget.store.favs.contains(l.id);
    return Scaffold(
      appBar: AppBar(title: Text(l.title), actions: [
        IconButton(
          icon: Icon(fav ? Icons.favorite : Icons.favorite_border),
          onPressed: () async {
            await widget.store.toggleFav(l.id);
            setState(() {});
          },
        ),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (l.source.isNotEmpty) Text('المصدر: ${l.source}'),
        Text('أهداف التعلم', style: Theme.of(context).textTheme.titleMedium),
        for (final o in l.objectives) Text('• $o'),
        const SizedBox(height: 16),
        Text('الشرح', style: Theme.of(context).textTheme.titleMedium),
        Text(l.body, style: const TextStyle(fontSize: 18, height: 1.7)),
        TextButton.icon(
          onPressed: _toggleSpeak,
          icon: Icon(_speaking ? Icons.stop : Icons.volume_up),
          label: Text(_speaking ? 'إيقاف' : 'استمعي للشرح'),
        ),
        const SizedBox(height: 24),
        if (l.questions.isNotEmpty)
          FilledButton.icon(
            icon: const Icon(Icons.quiz),
            label: const Text('اختبار قصير'),
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                    builder: (_) => QuizPage(
                        lessonId: l.id, questions: l.questions, store: widget.store))),
          ),
        const SizedBox(height: 16),
        TextField(
          controller: _note,
          maxLines: 4,
          decoration: const InputDecoration(
              labelText: 'ملاحظاتي', border: OutlineInputBorder()),
          onChanged: (v) => widget.store.setNote(l.id, v),
        ),
      ]),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key, required this.lessonId, required this.questions, required this.store, this.seconds});
  final int? seconds;
  final String lessonId;
  final List<Question> questions;
  final ProgressStore store;
  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  late final List<Question> _qs = QuizEngine.prepare(widget.questions);
  final TextEditingController _text = TextEditingController();
  int _n = 0;
  int? _chosen;
  bool _answered = false;
  bool _ok = false;
  List<String> _picked = [];
  late List<String> _pool = _mkPool();
  final Set<String> _wrong = {};
  final Set<String> _right = {};
  bool _done = false;
  bool _completing = false;
  Timer? _timer;
  int _left = 0;

  @override
  void initState() {
    super.initState();
    if (widget.seconds != null) {
      _left = widget.seconds!;
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (_done || _completing) return;
        setState(() => _left--);
        if (_left <= 0) _complete();
      });
    }
  }

  List<String> _mkPool() {
    if (_qs.isEmpty || _qs[_n].type != 'order') return [];
    return [..._qs[_n].options]..shuffle();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _text.dispose();
    super.dispose();
  }

  void _finish(bool ok, {int? chosen}) {
    final q = _qs[_n];
    setState(() {
      _answered = true;
      _ok = ok;
      _chosen = chosen;
      (ok ? _right : _wrong).add(q.id);
    });
    if (widget.store.flag('soundOn', def: true)) SystemSound.play(SystemSoundType.click);
    if (widget.store.flag('hapticsOn', def: true)) {
      if (ok) { HapticFeedback.lightImpact(); } else { HapticFeedback.selectionClick(); }
    }
  }

  Future<void> _next() async {
    if (_n + 1 < _qs.length) {
      setState(() {
        _n++;
        _chosen = null;
        _answered = false;
        _ok = false;
        _picked = [];
        _text.clear();
        _pool = _mkPool();
      });
      return;
    }
    await _complete();
  }

  Future<void> _complete() async {
    if (_completing) return;
    _completing = true;
    _timer?.cancel();
    await widget.store.recordAttempt(
        lessonId: widget.lessonId,
        correct: _right.length,
        total: _qs.length,
        wrong: _wrong,
        right: _right);
    if (mounted) setState(() => _done = true);
  }

  Widget _input(Question q) {
    if (q.type == 'fill') {
      return Column(children: [
        TextField(
          controller: _text,
          enabled: !_answered,
          decoration: const InputDecoration(
              border: OutlineInputBorder(), hintText: 'اكتبي إجابتك'),
        ),
        const SizedBox(height: 8),
        if (!_answered)
          FilledButton(
              onPressed: () => _finish(QuizEngine.checkText(q, _text.text)),
              child: const Text('تحقق')),
      ]);
    }
    if (q.type == 'order') {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('اضغطي بالترتيب الصحيح:'),
        Wrap(spacing: 6, children: [
          for (final p in _picked)
            InputChip(
                label: Text(p),
                onDeleted: _answered ? null : () => setState(() => _picked.remove(p))),
        ]),
        const Divider(),
        Wrap(spacing: 6, children: [
          for (final p in _pool)
            if (!_picked.contains(p))
              ActionChip(
                  label: Text(p),
                  onPressed: _answered ? null : () => setState(() => _picked.add(p))),
        ]),
        if (!_answered)
          FilledButton(
              onPressed: _picked.length == q.options.length
                  ? () => _finish(QuizEngine.checkOrder(q, _picked))
                  : null,
              child: const Text('تحقق')),
      ]);
    }
    return Column(children: [
      for (var i = 0; i < q.options.length; i++)
        Card(
          color: _chosen == null
              ? null
              : i == q.answer
                  ? Colors.green.withValues(alpha: 0.25)
                  : i == _chosen
                      ? Colors.orange.withValues(alpha: 0.25)
                      : null,
          child: ListTile(
            title: Text(q.options[i]),
            onTap: _answered
                ? null
                : () => _finish(QuizEngine.isCorrect(q, i), chosen: i),
          ),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    if (_qs.isEmpty) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('لا توجد أسئلة.')));
    }
    if (_done) {
      final p = QuizEngine.percent(_right.length, _qs.length);
      return ResultView(
        percent: p,
        right: _right.length,
        total: _qs.length,
        onClose: () => Navigator.pop(context),
      );
    }
    final q = _qs[_n];
    final timeTxt = widget.seconds == null
        ? ''
        : '   ⏱ ${_left ~/ 60}:${(_left % 60).toString().padLeft(2, "0")}';
    return Scaffold(
      appBar: AppBar(title: Text('سؤال ${_n + 1} من ${_qs.length}$timeTxt')),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: ListView(key: ValueKey(_n), padding: const EdgeInsets.all(16), children: [
        Text(q.text, style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 12),
        _input(q),
        if (_answered) ...[
          const SizedBox(height: 8),
          Text(_ok ? 'أحسنتِ! 🌟' : 'قريبة! راجعي التفسير:'),
          if (!_ok && q.type == 'fill' && q.accepted.isNotEmpty)
            Text('الإجابة الصحيحة: ${q.accepted.first}'),
          if (!_ok && q.type == 'order')
            Text('الترتيب الصحيح: ${q.options.join(" ← ")}'),
          Text(q.explanation),
          const SizedBox(height: 12),
          FilledButton(onPressed: _next, child: const Text('التالي')),
        ],
      ])),
    );
  }
}

class AchievementsPage extends StatelessWidget {
  const AchievementsPage({super.key, required this.store});
  final ProgressStore store;
  @override
  Widget build(BuildContext context) {
    final a = store.attempts.reversed.toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('المستوى ${store.level} • ${store.xp} نقطة • سلسلة ${store.streak} يوم',
          style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      Wrap(spacing: 8, children: [
        for (final e in store.badges.entries)
          Chip(
            avatar: Icon(e.value ? Icons.military_tech : Icons.lock_outline, size: 18),
            label: Text(e.key),
          ),
      ]),
      const Divider(),
      if (a.isEmpty) const Text('ابدئي أول اختبار لتظهر إنجازاتك هنا.'),
      for (final x in a)
        ListTile(
          leading: const Icon(Icons.check_circle_outline),
          title: Text('${x['correct']} / ${x['total']}'),
          subtitle: Text('${x['lesson']}'),
        ),
    ]);
  }
}

class GamesPage extends StatelessWidget {
  const GamesPage({super.key, required this.content, required this.store});
  final Content content;
  final ProgressStore store;

  void _open(BuildContext c, Widget w) =>
      Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final all = content.allQuestions;
    final orders = all.where((q) => q.type == 'order').toList();
    return ListView(children: [
      ListTile(
        leading: const Icon(Icons.grid_view),
        title: const Text('لعبة الذاكرة'),
        subtitle: const Text('طابقي الكسر مع قيمته العشرية'),
        onTap: () => _open(context, MemoryGamePage(pairs: content.pairs, store: store)),
      ),
      if (content.pairs.isNotEmpty)
        ListTile(
          leading: const Icon(Icons.compare_arrows),
          title: const Text('لعبة التوصيل'),
          subtitle: const Text('وصّلي كل كسر بقيمته'),
          onTap: () => _open(context, MatchGamePage(pairs: content.pairs, store: store)),
        ),
      ListTile(
        leading: const Icon(Icons.search),
        title: const Text('اكتشف الخطأ'),
        subtitle: const Text('٣ جولات: عبارة واحدة خاطئة'),
        onTap: () => _open(context, SpotErrorPage(questions: all, store: store)),
      ),
      if (all.isNotEmpty)
        ListTile(
          leading: const Icon(Icons.style),
          title: const Text('بطاقات المراجعة'),
          subtitle: const Text('اقلبي البطاقة وتأكدي من إجابتك'),
          onTap: () => _open(context, FlashcardsPage(questions: all, store: store)),
        ),
      ListTile(
        leading: const Icon(Icons.calculate),
        title: const Text('الحساب الذهني'),
        subtitle: const Text('٨ مسائل قصيرة'),
        onTap: () => _open(context, MentalMathPage(store: store)),
      ),
      if (all.isNotEmpty)
        ListTile(
          leading: const Icon(Icons.psychology),
          title: const Text('تحدي المعرفة'),
          subtitle: const Text('٥ أسئلة عشوائية بدون سباق مع الوقت'),
          onTap: () => _open(
              context,
              QuizPage(
                  lessonId: 'game-quiz',
                  questions: ([...all]..shuffle()).take(5).toList(),
                  store: store)),
        ),
      if (orders.isNotEmpty)
        ListTile(
          leading: const Icon(Icons.format_list_numbered),
          title: const Text('ترتيب المعلومات'),
          subtitle: const Text('رتبي الخطوات أو الأحداث'),
          onTap: () => _open(
              context, QuizPage(lessonId: 'game-order', questions: orders, store: store)),
        ),
    ]);
  }
}

class MentalMathPage extends StatefulWidget {
  const MentalMathPage({super.key, required this.store});
  final ProgressStore store;
  @override
  State<MentalMathPage> createState() => _MentalMathPageState();
}

class _MentalMathPageState extends State<MentalMathPage> {
  final _r = Random();
  final _c = TextEditingController();
  late final List<(String, int)> _ps = List.generate(8, (_) => _gen());
  int _i = 0;
  int _score = 0;
  bool _checked = false;
  bool _ok = false;
  bool _done = false;

  (String, int) _gen() {
    final k = _r.nextInt(4);
    if (k == 0) {
      final a = 10 + _r.nextInt(90), b = 10 + _r.nextInt(90);
      return ('$a + $b', a + b);
    }
    if (k == 1) {
      final a = 50 + _r.nextInt(50), b = 10 + _r.nextInt(40);
      return ('$a − $b', a - b);
    }
    if (k == 2) {
      final a = 2 + _r.nextInt(11), b = 2 + _r.nextInt(11);
      return ('$a × $b', a * b);
    }
    final b = 2 + _r.nextInt(11), q = 2 + _r.nextInt(11);
    return ('${b * q} ÷ $b', q);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _check() {
    final v = int.tryParse(QuizEngine.normalize(_c.text));
    final ok = v == _ps[_i].$2;
    setState(() {
      _checked = true;
      _ok = ok;
      if (ok) _score++;
    });
  }

  Future<void> _next() async {
    if (_i + 1 < _ps.length) {
      setState(() {
        _i++;
        _checked = false;
        _c.clear();
      });
      return;
    }
    await widget.store.recordAttempt(
        lessonId: 'game-math', correct: _score, total: _ps.length, wrong: {}, right: {});
    if (mounted) setState(() => _done = true);
  }

  @override
  Widget build(BuildContext context) {
    if (_done) {
      return Scaffold(
        appBar: AppBar(title: const Text('الحساب الذهني')),
        body: Center(child: Text('أحسنتِ! أجبتِ $_score من ${_ps.length} 🌟')),
      );
    }
    return Scaffold(
      appBar: AppBar(title: Text('مسألة ${_i + 1} من ${_ps.length}')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          Text(_ps[_i].$1, style: Theme.of(context).textTheme.displaySmall),
          const SizedBox(height: 16),
          TextField(
            controller: _c,
            enabled: !_checked,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            decoration: const InputDecoration(border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          if (!_checked) FilledButton(onPressed: _check, child: const Text('تحقق')),
          if (_checked) ...[
            Text(_ok ? 'صحيح! 🌟' : 'الإجابة الصحيحة: ${_ps[_i].$2}'),
            const SizedBox(height: 8),
            FilledButton(onPressed: _next, child: const Text('التالي')),
          ],
        ]),
      ),
    );
  }
}

class _MCard {
  _MCard(this.pair, this.label);
  final int pair;
  final String label;
  bool open = false;
  bool matched = false;
}

class MemoryGamePage extends StatefulWidget {
  const MemoryGamePage({super.key, required this.pairs, required this.store});
  final List<List<String>> pairs;
  final ProgressStore store;
  @override
  State<MemoryGamePage> createState() => _MemoryGamePageState();
}

class _MemoryGamePageState extends State<MemoryGamePage> {
  late final List<_MCard> _cards = _build();
  int? _first;
  bool _lock = false;
  bool _saved = false;

  List<_MCard> _build() {
    final l = <_MCard>[];
    for (var i = 0; i < widget.pairs.length; i++) {
      l.add(_MCard(i, widget.pairs[i][0]));
      l.add(_MCard(i, widget.pairs[i][1]));
    }
    return l..shuffle(Random());
  }

  Future<void> _tap(int i) async {
    final c = _cards[i];
    if (_lock || c.open || c.matched) return;
    setState(() => c.open = true);
    if (_first == null) {
      _first = i;
      return;
    }
    final f = _cards[_first!];
    _first = null;
    if (f.pair == c.pair) {
      setState(() {
        f.matched = true;
        c.matched = true;
      });
      if (_cards.every((card) => card.matched) && !_saved) {
        _saved = true;
        await widget.store.recordAttempt(lessonId: 'game-memory', correct: widget.pairs.length, total: widget.pairs.length, wrong: {}, right: {});
      }
    } else {
      _lock = true;
      await Future<void>.delayed(const Duration(milliseconds: 700));
      if (!mounted) return;
      setState(() {
        f.open = false;
        c.open = false;
      });
      _lock = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final won = _cards.every((c) => c.matched);
    return Scaffold(
      appBar: AppBar(title: Text(won ? 'أحسنتِ! أنهيتِ اللعبة 🎉' : 'لعبة الذاكرة')),
      body: GridView.count(
        crossAxisCount: 4,
        padding: const EdgeInsets.all(12),
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        children: [
          for (var i = 0; i < _cards.length; i++)
            InkWell(
              onTap: () => _tap(i),
              child: Card(
                color: _cards[i].matched ? Colors.green.withValues(alpha: 0.3) : null,
                child: Center(
                    child: Text(
                        _cards[i].open || _cards[i].matched ? _cards[i].label : '؟',
                        style: const TextStyle(fontSize: 18))),
              ),
            ),
        ],
      ),
    );
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({
    super.key,
    required this.store,
    required this.content,
    required this.onChanged,
    required this.onReload,
  });
  final ProgressStore store;
  final Content content;
  final VoidCallback onChanged;
  final Future<void> Function() onReload;

  Future<void> _go(BuildContext c, Widget w) async {
    await Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));
    onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final all = content.allQuestions;
    final due = store.dueIds();
    final review = all.where((q) => due.contains(q.id)).toList();
    final wrong = all.where((q) => store.wrongIds.contains(q.id)).toList();
    return ListView(padding: const EdgeInsets.all(8), children: [
      ListTile(
        leading: const Icon(Icons.event_repeat),
        title: const Text('مراجعة اليوم (متباعدة)'),
        subtitle: Text('${review.length} سؤال'),
        enabled: review.isNotEmpty,
        onTap: () => _go(context,
            QuizPage(lessonId: 'review', questions: review, store: store)),
      ),
      ListTile(
        leading: const Icon(Icons.replay),
        title: const Text('مراجعة أخطائي'),
        subtitle: Text('${wrong.length} سؤال'),
        enabled: wrong.isNotEmpty,
        onTap: () => _go(context,
            QuizPage(lessonId: 'wrong', questions: wrong, store: store)),
      ),
      if (store.flag('tutorOn'))
        ListTile(
          leading: const Icon(Icons.school),
          title: const Text('معلم رغد'),
          onTap: () => _go(context, TutorPage(store: store, content: content)),
        ),
      ListTile(
        leading: const Icon(Icons.calendar_month),
        title: const Text('جدول المذاكرة'),
        onTap: () => _go(context, SchedulePage(store: store)),
      ),
      ListTile(
        leading: const Icon(Icons.favorite),
        title: const Text('المفضلة'),
        onTap: () => _go(context, FavoritesPage(store: store, content: content)),
      ),
      ListTile(
        leading: const Icon(Icons.face),
        title: const Text('تخصيص رغد'),
        onTap: () => _go(context, MascotPage(store: store)),
      ),
      if (all.length >= 3)
        ListTile(
          leading: const Icon(Icons.timer),
          title: const Text('امتحان محاكاة'),
          subtitle: const Text('حتى ١٠ أسئلة في ١٠ دقائق'),
          onTap: () => _go(
              context,
              QuizPage(
                  lessonId: 'exam',
                  questions: ([...all]..shuffle()).take(10).toList(),
                  store: store,
                  seconds: 600)),
        ),
      ListTile(
        leading: const Icon(Icons.privacy_tip),
        title: const Text('عن التطبيق والخصوصية'),
        onTap: () => showDialog<void>(
          context: context,
          builder: (d) => AlertDialog(
            title: const Text('رغد'),
            content: const Text(
                'بيانات رغد تُحفظ على الجهاز فقط. لا إعلانات ولا مشتريات ولا محادثات مع غرباء. '
                'مفتاح Gemini يُخزَّن مشفّرًا، وعند تفعيل المعلم يُرسَل نص السؤال والدرس فقط إلى Google.'),
            actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('حسنًا'))],
          ),
        ),
      ),
      ListTile(
        leading: const Icon(Icons.lock),
        title: const Text('ولي الأمر'),
        onTap: () => _go(context, ParentGate(store: store, onReload: onReload)),
      ),
    ]);
  }
}
