import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'models.dart';
import 'progress_store.dart';
import 'quiz_engine.dart';
import 'screens2.dart';

class Shell extends StatefulWidget {
  const Shell({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;
  late Content _c = widget.content;
  void _refresh() => setState(() {});
  Future<void> _reload() async {
    final c = await Content.load(widget.store);
    if (mounted) setState(() => _c = c);
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomePage(store: widget.store, content: _c, onChanged: _refresh),
      LibraryPage(store: widget.store, content: _c, onChanged: _refresh),
      AchievementsPage(store: widget.store),
      GamesPage(content: _c, store: widget.store),
      AccountPage(store: widget.store, content: _c, onChanged: _refresh, onReload: _reload),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('رغد – رحلتي نحو التفوق')),
      body: pages[_i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'المكتبة'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'إنجازاتي'),
          NavigationDestination(icon: Icon(Icons.extension_outlined), label: 'الألعاب'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

Lesson? _findLesson(Content c, String? id) {
  for (final s in c.subjects) {
    for (final l in s.lessons) {
      if (l.id == id) return l;
    }
  }
  return null;
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.store, required this.content, required this.onChanged});
  final ProgressStore store;
  final Content content;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    final last = _findLesson(content, store.lastLesson);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('أهلًا يا رغد 👋', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 12),
      Card(
        child: ListTile(
          leading: const Icon(Icons.star),
          title: Text('المستوى ${store.level}'),
          subtitle: Text('نقاط الخبرة: ${store.xp}'),
        ),
      ),
      if (last != null)
        Card(
          child: ListTile(
            leading: const Icon(Icons.play_circle),
            title: const Text('استكمل من حيث توقفت'),
            subtitle: Text(last.title),
            onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                        builder: (_) => LessonPage(lesson: last, store: store)))
                .then((_) => onChanged()),
          ),
        ),
      if (content.allQuestions.isNotEmpty)
        Card(
          child: ListTile(
            leading: const Icon(Icons.bolt),
            title: const Text('تحدي اليوم'),
            subtitle: const Text('٥ أسئلة متنوعة'),
            onTap: () {
              final d = DateTime.now();
              final qs = ([...content.allQuestions]
                    ..shuffle(Random(d.year * 10000 + d.month * 100 + d.day)))
                  .take(5)
                  .toList();
              Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                          builder: (_) =>
                              QuizPage(lessonId: 'daily', questions: qs, store: store)))
                  .then((_) => onChanged());
            },
          ),
        ),
      if (content.isSample)
        const Card(
          child: ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('المحتوى الحالي تجريبي'),
            subtitle: Text('لم يُعتمد بعد من المنهج الرسمي.'),
          ),
        ),
    ]);
  }
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key, required this.store, required this.content, required this.onChanged});
  final ProgressStore store;
  final Content content;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    return ListView(children: [
      for (final s in content.subjects)
        ExpansionTile(
          title: Text(s.name),
          initiallyExpanded: true,
          children: [
            for (final l in s.lessons)
              ListTile(
                title: Text(l.title),
                trailing: const Icon(Icons.chevron_left),
                onTap: () async {
                  await store.setLastLesson(l.id);
                  if (!context.mounted) return;
                  await Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                          builder: (_) => LessonPage(lesson: l, store: store)));
                  onChanged();
                },
              ),
          ],
        ),
    ]);
  }
}

class LessonPage extends StatefulWidget {
  const LessonPage({super.key, required this.lesson, required this.store});
  final Lesson lesson;
  final ProgressStore store;
  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  late final TextEditingController _note =
      TextEditingController(text: widget.store.note(widget.lesson.id));
  final FlutterTts _tts = FlutterTts();
  bool _speaking = false;

  Future<void> _toggleSpeak() async {
    try {
      if (_speaking) {
        await _tts.stop();
      } else {
        await _tts.setLanguage('ar');
        await _tts.setSpeechRate(0.4);
        await _tts.speak(widget.lesson.body);
      }
      setState(() => _speaking = !_speaking);
    } catch (_) {}
  }

  @override
  void dispose() {
    _tts.stop();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.lesson;
    final fav = widget.store.favs.contains(l.id);
    return Scaffold(
      appBar: AppBar(title: Text(l.title), actions: [
        IconButton(
          icon: Icon(fav ? Icons.favorite : Icons.favorite_border),
          onPressed: () async {
            await widget.store.toggleFav(l.id);
            setState(() {});
          },
        ),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (l.source.isNotEmpty) Text('المصدر: ${l.source}'),
        Text('أهداف التعلم', style: Theme.of(context).textTheme.titleMedium),
        for (final o in l.objectives) Text('• $o'),
        const SizedBox(height: 16),
        Text('الشرح', style: Theme.of(context).textTheme.titleMedium),
        Text(l.body, style: const TextStyle(fontSize: 18, height: 1.7)),
        TextButton.icon(
          onPressed: _toggleSpeak,
          icon: Icon(_speaking ? Icons.stop : Icons.volume_up),
          label: Text(_speaking ? 'إيقاف' : 'استمعي للشرح'),
        ),
        const SizedBox(height: 24),
        if (l.questions.isNotEmpty)
          FilledButton.icon(
            icon: const Icon(Icons.quiz),
            label: const Text('اختبار قصير'),
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                    builder: (_) => QuizPage(
                        lessonId: l.id, questions: l.questions, store: widget.store))),
          ),
        const SizedBox(height: 16),
        TextField(
          controller: _note,
          maxLines: 4,
          decoration: const InputDecoration(
              labelText: 'ملاحظاتي', border: OutlineInputBorder()),
          onChanged: (v) => widget.store.setNote(l.id, v),
        ),
      ]),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key, required this.lessonId, required this.questions, required this.store});
  final String lessonId;
  final List<Question> questions;
  final ProgressStore store;
  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  late final List<Question> _qs = QuizEngine.prepare(widget.questions);
  final TextEditingController _text = TextEditingController();
  int _n = 0;
  int? _chosen;
  bool _answered = false;
  bool _ok = false;
  List<String> _picked = [];
  late List<String> _pool = _mkPool();
  final Set<String> _wrong = {};
  final Set<String> _right = {};
  bool _done = false;

  List<String> _mkPool() {
    if (_qs.isEmpty || _qs[_n].type != 'order') return [];
    return [..._qs[_n].options]..shuffle();
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  void _finish(bool ok, {int? chosen}) {
    final q = _qs[_n];
    setState(() {
      _answered = true;
      _ok = ok;
      _chosen = chosen;
      (ok ? _right : _wrong).add(q.id);
    });
  }

  Future<void> _next() async {
    if (_n + 1 < _qs.length) {
      setState(() {
        _n++;
        _chosen = null;
        _answered = false;
        _ok = false;
        _picked = [];
        _text.clear();
        _pool = _mkPool();
      });
      return;
    }
    await widget.store.recordAttempt(
        lessonId: widget.lessonId,
        correct: _right.length,
        total: _qs.length,
        wrong: _wrong,
        right: _right);
    if (mounted) setState(() => _done = true);
  }

  Widget _input(Question q) {
    if (q.type == 'fill') {
      return Column(children: [
        TextField(
          controller: _text,
          enabled: !_answered,
          decoration: const InputDecoration(
              border: OutlineInputBorder(), hintText: 'اكتبي إجابتك'),
        ),
        const SizedBox(height: 8),
        if (!_answered)
          FilledButton(
              onPressed: () => _finish(QuizEngine.checkText(q, _text.text)),
              child: const Text('تحقق')),
      ]);
    }
    if (q.type == 'order') {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('اضغطي بالترتيب الصحيح:'),
        Wrap(spacing: 6, children: [
          for (final p in _picked)
            InputChip(
                label: Text(p),
                onDeleted: _answered ? null : () => setState(() => _picked.remove(p))),
        ]),
        const Divider(),
        Wrap(spacing: 6, children: [
          for (final p in _pool)
            if (!_picked.contains(p))
              ActionChip(
                  label: Text(p),
                  onPressed: _answered ? null : () => setState(() => _picked.add(p))),
        ]),
        if (!_answered)
          FilledButton(
              onPressed: _picked.length == q.options.length
                  ? () => _finish(QuizEngine.checkOrder(q, _picked))
                  : null,
              child: const Text('تحقق')),
      ]);
    }
    return Column(children: [
      for (var i = 0; i < q.options.length; i++)
        Card(
          color: _chosen == null
              ? null
              : i == q.answer
                  ? Colors.green.withValues(alpha: 0.25)
                  : i == _chosen
                      ? Colors.orange.withValues(alpha: 0.25)
                      : null,
          child: ListTile(
            title: Text(q.options[i]),
            onTap: _answered
                ? null
                : () => _finish(QuizEngine.isCorrect(q, i), chosen: i),
          ),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    if (_qs.isEmpty) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('لا توجد أسئلة.')));
    }
    if (_done) {
      final p = QuizEngine.percent(_right.length, _qs.length);
      return Scaffold(
        appBar: AppBar(title: const Text('النتيجة')),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('$p٪', style: Theme.of(context).textTheme.displayMedium),
            Text('أجبتِ ${_right.length} من ${_qs.length} بشكل صحيح'),
            const SizedBox(height: 16),
            FilledButton(onPressed: () => Navigator.pop(context), child: const Text('رجوع')),
          ]),
        ),
      );
    }
    final q = _qs[_n];
    return Scaffold(
      appBar: AppBar(title: Text('سؤال ${_n + 1} من ${_qs.length}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(q.text, style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 12),
        _input(q),
        if (_answered) ...[
          const SizedBox(height: 8),
          Text(_ok ? 'أحسنتِ! 🌟' : 'قريبة! راجعي التفسير:'),
          if (!_ok && q.type == 'fill' && q.accepted.isNotEmpty)
            Text('الإجابة الصحيحة: ${q.accepted.first}'),
          if (!_ok && q.type == 'order')
            Text('الترتيب الصحيح: ${q.options.join(" ← ")}'),
          Text(q.explanation),
          const SizedBox(height: 12),
          FilledButton(onPressed: _next, child: const Text('التالي')),
        ],
      ]),
    );
  }
}

class AchievementsPage extends StatelessWidget {
  const AchievementsPage({super.key, required this.store});
  final ProgressStore store;
  @override
  Widget build(BuildContext context) {
    final a = store.attempts.reversed.toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('المستوى ${store.level} • ${store.xp} نقطة • سلسلة ${store.streak} يوم',
          style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      Wrap(spacing: 8, children: [
        for (final e in store.badges.entries)
          Chip(
            avatar: Icon(e.value ? Icons.military_tech : Icons.lock_outline, size: 18),
            label: Text(e.key),
          ),
      ]),
      const Divider(),
      if (a.isEmpty) const Text('ابدئي أول اختبار لتظهر إنجازاتك هنا.'),
      for (final x in a)
        ListTile(
          leading: const Icon(Icons.check_circle_outline),
          title: Text('${x['correct']} / ${x['total']}'),
          subtitle: Text('${x['lesson']}'),
        ),
    ]);
  }
}

class GamesPage extends StatelessWidget {
  const GamesPage({super.key, required this.content, required this.store});
  final Content content;
  final ProgressStore store;

  void _open(BuildContext c, Widget w) =>
      Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final all = content.allQuestions;
    final orders = all.where((q) => q.type == 'order').toList();
    return ListView(children: [
      ListTile(
        leading: const Icon(Icons.grid_view),
        title: const Text('لعبة الذاكرة'),
        subtitle: const Text('طابقي الكسر مع قيمته العشرية'),
        onTap: () => _open(context, MemoryGamePage(pairs: content.pairs)),
      ),
      ListTile(
        leading: const Icon(Icons.calculate),
        title: const Text('الحساب الذهني'),
        subtitle: const Text('٨ مسائل قصيرة'),
        onTap: () => _open(context, MentalMathPage(store: store)),
      ),
      if (all.isNotEmpty)
        ListTile(
          leading: const Icon(Icons.psychology),
          title: const Text('تحدي المعرفة'),
          subtitle: const Text('٥ أسئلة عشوائية بدون سباق مع الوقت'),
          onTap: () => _open(
              context,
              QuizPage(
                  lessonId: 'game-quiz',
                  questions: ([...all]..shuffle()).take(5).toList(),
                  store: store)),
        ),
      if (orders.isNotEmpty)
        ListTile(
          leading: const Icon(Icons.format_list_numbered),
          title: const Text('ترتيب المعلومات'),
          subtitle: const Text('رتبي الخطوات أو الأحداث'),
          onTap: () => _open(
              context, QuizPage(lessonId: 'game-order', questions: orders, store: store)),
        ),
    ]);
  }
}

class MentalMathPage extends StatefulWidget {
  const MentalMathPage({super.key, required this.store});
  final ProgressStore store;
  @override
  State<MentalMathPage> createState() => _MentalMathPageState();
}

class _MentalMathPageState extends State<MentalMathPage> {
  final _r = Random();
  final _c = TextEditingController();
  late final List<(String, int)> _ps = List.generate(8, (_) => _gen());
  int _i = 0;
  int _score = 0;
  bool _checked = false;
  bool _ok = false;
  bool _done = false;

  (String, int) _gen() {
    final k = _r.nextInt(4);
    if (k == 0) {
      final a = 10 + _r.nextInt(90), b = 10 + _r.nextInt(90);
      return ('$a + $b', a + b);
    }
    if (k == 1) {
      final a = 50 + _r.nextInt(50), b = 10 + _r.nextInt(40);
      return ('$a − $b', a - b);
    }
    if (k == 2) {
      final a = 2 + _r.nextInt(11), b = 2 + _r.nextInt(11);
      return ('$a × $b', a * b);
    }
    final b = 2 + _r.nextInt(11), q = 2 + _r.nextInt(11);
    return ('${b * q} ÷ $b', q);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _check() {
    final v = int.tryParse(QuizEngine.normalize(_c.text));
    final ok = v == _ps[_i].$2;
    setState(() {
      _checked = true;
      _ok = ok;
      if (ok) _score++;
    });
  }

  Future<void> _next() async {
    if (_i + 1 < _ps.length) {
      setState(() {
        _i++;
        _checked = false;
        _c.clear();
      });
      return;
    }
    await widget.store.recordAttempt(
        lessonId: 'game-math', correct: _score, total: _ps.length, wrong: {}, right: {});
    if (mounted) setState(() => _done = true);
  }

  @override
  Widget build(BuildContext context) {
    if (_done) {
      return Scaffold(
        appBar: AppBar(title: const Text('الحساب الذهني')),
        body: Center(child: Text('أحسنتِ! أجبتِ $_score من ${_ps.length} 🌟')),
      );
    }
    return Scaffold(
      appBar: AppBar(title: Text('مسألة ${_i + 1} من ${_ps.length}')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          Text(_ps[_i].$1, style: Theme.of(context).textTheme.displaySmall),
          const SizedBox(height: 16),
          TextField(
            controller: _c,
            enabled: !_checked,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            decoration: const InputDecoration(border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          if (!_checked) FilledButton(onPressed: _check, child: const Text('تحقق')),
          if (_checked) ...[
            Text(_ok ? 'صحيح! 🌟' : 'الإجابة الصحيحة: ${_ps[_i].$2}'),
            const SizedBox(height: 8),
            FilledButton(onPressed: _next, child: const Text('التالي')),
          ],
        ]),
      ),
    );
  }
}

class _MCard {
  _MCard(this.pair, this.label);
  final int pair;
  final String label;
  bool open = false;
  bool matched = false;
}

class MemoryGamePage extends StatefulWidget {
  const MemoryGamePage({super.key, required this.pairs});
  final List<List<String>> pairs;
  @override
  State<MemoryGamePage> createState() => _MemoryGamePageState();
}

class _MemoryGamePageState extends State<MemoryGamePage> {
  late final List<_MCard> _cards = _build();
  int? _first;
  bool _lock = false;

  List<_MCard> _build() {
    final l = <_MCard>[];
    for (var i = 0; i < widget.pairs.length; i++) {
      l.add(_MCard(i, widget.pairs[i][0]));
      l.add(_MCard(i, widget.pairs[i][1]));
    }
    return l..shuffle(Random());
  }

  Future<void> _tap(int i) async {
    final c = _cards[i];
    if (_lock || c.open || c.matched) return;
    setState(() => c.open = true);
    if (_first == null) {
      _first = i;
      return;
    }
    final f = _cards[_first!];
    _first = null;
    if (f.pair == c.pair) {
      setState(() {
        f.matched = true;
        c.matched = true;
      });
    } else {
      _lock = true;
      await Future<void>.delayed(const Duration(milliseconds: 700));
      if (!mounted) return;
      setState(() {
        f.open = false;
        c.open = false;
      });
      _lock = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final won = _cards.every((c) => c.matched);
    return Scaffold(
      appBar: AppBar(title: Text(won ? 'أحسنتِ! أنهيتِ اللعبة 🎉' : 'لعبة الذاكرة')),
      body: GridView.count(
        crossAxisCount: 4,
        padding: const EdgeInsets.all(12),
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        children: [
          for (var i = 0; i < _cards.length; i++)
            InkWell(
              onTap: () => _tap(i),
              child: Card(
                color: _cards[i].matched ? Colors.green.withValues(alpha: 0.3) : null,
                child: Center(
                    child: Text(
                        _cards[i].open || _cards[i].matched ? _cards[i].label : '؟',
                        style: const TextStyle(fontSize: 18))),
              ),
            ),
        ],
      ),
    );
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({
    super.key,
    required this.store,
    required this.content,
    required this.onChanged,
    required this.onReload,
  });
  final ProgressStore store;
  final Content content;
  final VoidCallback onChanged;
  final Future<void> Function() onReload;

  Future<void> _go(BuildContext c, Widget w) async {
    await Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));
    onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final all = content.allQuestions;
    final due = store.dueIds();
    final review = all.where((q) => due.contains(q.id)).toList();
    final wrong = all.where((q) => store.wrongIds.contains(q.id)).toList();
    return ListView(padding: const EdgeInsets.all(8), children: [
      ListTile(
        leading: const Icon(Icons.event_repeat),
        title: const Text('مراجعة اليوم (متباعدة)'),
        subtitle: Text('${review.length} سؤال'),
        enabled: review.isNotEmpty,
        onTap: () => _go(context,
            QuizPage(lessonId: 'review', questions: review, store: store)),
      ),
      ListTile(
        leading: const Icon(Icons.replay),
        title: const Text('مراجعة أخطائي'),
        subtitle: Text('${wrong.length} سؤال'),
        enabled: wrong.isNotEmpty,
        onTap: () => _go(context,
            QuizPage(lessonId: 'wrong', questions: wrong, store: store)),
      ),
      if (store.flag('tutorOn'))
        ListTile(
          leading: const Icon(Icons.school),
          title: const Text('معلم رغد'),
          onTap: () => _go(context, TutorPage(store: store, content: content)),
        ),
      ListTile(
        leading: const Icon(Icons.calendar_month),
        title: const Text('جدول المذاكرة'),
        onTap: () => _go(context, SchedulePage(store: store)),
      ),
      ListTile(
        leading: const Icon(Icons.favorite),
        title: const Text('المفضلة'),
        onTap: () => _go(context, FavoritesPage(store: store, content: content)),
      ),
      ListTile(
        leading: const Icon(Icons.lock),
        title: const Text('ولي الأمر'),
        onTap: () => _go(context, ParentGate(store: store, onReload: onReload)),
      ),
    ]);
  }
}
