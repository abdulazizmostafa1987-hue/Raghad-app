import 'dart:math';
import 'models.dart';

class QuizEngine {
  /// يخلط ترتيب الأسئلة والاختيارات مع الحفاظ على الإجابة الصحيحة.
  static List<Question> prepare(List<Question> source, {Random? rng}) {
    final r = rng ?? Random();
    final qs = [...source]..shuffle(r);
    return qs.map((q) {
      if (q.type != 'mcq') return q;
      final idx = List<int>.generate(q.options.length, (i) => i)..shuffle(r);
      return Question(
        id: q.id,
        type: q.type,
        text: q.text,
        options: idx.map((i) => q.options[i]).toList(),
        answer: idx.indexOf(q.answer),
        difficulty: q.difficulty,
        explanation: q.explanation,
      );
    }).toList();
  }

  static String normalize(String input) {
    var t = input.trim().toLowerCase();
    t = t.replaceAll(RegExp('[\u064B-\u065F\u0640]'), '');
    t = t
        .replaceAll(RegExp('[أإآ]'), 'ا')
        .replaceAll('ى', 'ي')
        .replaceAll('ة', 'ه');
    const ar = '٠١٢٣٤٥٦٧٨٩';
    for (var i = 0; i < ar.length; i++) {
      t = t.replaceAll(ar[i], '$i');
    }
    return t.replaceAll(RegExp(r'\s+'), ' ');
  }

  static bool checkText(Question q, String input) {
    final n = normalize(input);
    return n.isNotEmpty && q.accepted.any((a) => normalize(a) == n);
  }

  static bool checkOrder(Question q, List<String> picked) {
    if (picked.length != q.options.length) return false;
    for (var i = 0; i < picked.length; i++) {
      if (picked[i] != q.options[i]) return false;
    }
    return true;
  }

  static bool isCorrect(Question q, int chosen) => q.answer == chosen;

  static int percent(int correct, int total) =>
      total == 0 ? 0 : ((correct * 100) / total).round();
}
