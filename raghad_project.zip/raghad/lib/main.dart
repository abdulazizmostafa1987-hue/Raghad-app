import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'models.dart';
import 'progress_store.dart';
import 'world/brand.dart';
import 'world/world_shell.dart';
import 'services.dart';
import 'home_widget_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await ProgressStore.open();
  themeNotifier.value = switch (store.str('theme')) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };
  fontScaleNotifier.value = double.tryParse(store.str('fontScale') ?? '') ?? 1.0;
  final content = await Content.load(store);
  try { await RaghadHomeWidgetService.sync(studentName: store.str('name') ?? 'رغد', lastLesson: store.str('widgetLastLessonTitle') ?? 'ابدئي رحلة التعلم', xp: store.xp, streak: store.streak, studyMinutes: store.studyMinutes); } catch (_) { /* Native widget is optional on non-Android builds. */ }
  runApp(RaghadApp(store: store, content: content));
}

class RaghadApp extends StatelessWidget {
  const RaghadApp({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) => MaterialApp(
        title: 'عالم رغد',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: Brand.theme(Brightness.light),
        darkTheme: Brand.theme(Brightness.dark),
        themeMode: mode,
        builder: (ctx, child) => ValueListenableBuilder<double>(
          valueListenable: fontScaleNotifier,
          builder: (_, f, __) => MediaQuery(
            data: MediaQuery.of(ctx).copyWith(textScaler: TextScaler.linear(f)),
            child: child!,
          ),
        ),
        home: _SplashGate(store: store, content: content),
      ),
    );
  }
}

class _SplashGate extends StatefulWidget {
  const _SplashGate({required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  State<_SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<_SplashGate> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1350))..forward();
  bool _done = false;
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1900), () { if (mounted) setState(() => _done = true); });
  }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_done) return WorldShell(store: widget.store, content: widget.content);
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: Brand.gradient),
        child: SafeArea(
          child: Center(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _controller, curve: Curves.easeOut),
              child: ScaleTransition(
                scale: CurvedAnimation(parent: _controller, curve: Curves.elasticOut),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    RaghadLogo(size: 170),
                    SizedBox(height: 24),
                    Text('عالم رغد', style: TextStyle(color: Colors.white, fontSize: 44, fontWeight: FontWeight.w900)),
                    SizedBox(height: 4),
                    Text('رحلتي نحو التفوق', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
                    SizedBox(height: 18),
                    Text('أتعلم • أكتشف • أنجح', style: TextStyle(color: Colors.white70, fontSize: 14)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
