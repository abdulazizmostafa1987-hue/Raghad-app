import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'models.dart';
import 'progress_store.dart';
import 'screens.dart';
import 'services.dart';
import 'home_widget_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await ProgressStore.open();
  themeNotifier.value = switch (store.str('theme')) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };
  fontScaleNotifier.value = double.tryParse(store.str('fontScale') ?? '') ?? 1.0;
  final content = await Content.load(store);
  try { await RaghadHomeWidgetService.sync(studentName: store.str('name') ?? 'رغد', lastLesson: store.str('widgetLastLessonTitle') ?? 'ابدئي رحلة التعلم', xp: store.xp, streak: store.streak, studyMinutes: store.studyMinutes); } catch (_) { /* Native widget is optional on non-Android builds. */ }
  runApp(RaghadApp(store: store, content: content));
}

class RaghadApp extends StatelessWidget {
  const RaghadApp({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF7045B5);
    final light = ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light);
    final dark = ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark);
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) => MaterialApp(
        title: 'رغد – رحلتي نحو التفوق',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: light,
          scaffoldBackgroundColor: const Color(0xFFFFF9FF),
          cardTheme: CardThemeData(elevation: 1, margin: const EdgeInsets.symmetric(vertical: 7), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
          appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
          inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
        ),
        darkTheme: ThemeData(
          useMaterial3: true,
          colorScheme: dark,
          cardTheme: CardThemeData(elevation: 1, margin: const EdgeInsets.symmetric(vertical: 7), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
          appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
          inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
        ),
        themeMode: mode,
        builder: (ctx, child) => ValueListenableBuilder<double>(
          valueListenable: fontScaleNotifier,
          builder: (_, f, __) => MediaQuery(
            data: MediaQuery.of(ctx).copyWith(textScaler: TextScaler.linear(f)),
            child: child!,
          ),
        ),
        home: _SplashGate(store: store, content: content),
      ),
    );
  }
}

class _SplashGate extends StatefulWidget {
  const _SplashGate({required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  State<_SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<_SplashGate> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1350))..forward();
  bool _done = false;
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1900), () { if (mounted) setState(() => _done = true); });
  }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_done) return Shell(store: widget.store, content: widget.content);
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF6E42B3), Color(0xFF9C70D6), Color(0xFFF49BC0)])),
        child: SafeArea(child: Center(child: FadeTransition(
          opacity: CurvedAnimation(parent: _controller, curve: Curves.easeOut),
          child: ScaleTransition(scale: CurvedAnimation(parent: _controller, curve: Curves.elasticOut), child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 190, height: 190, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(42), boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 24, offset: Offset(0, 12))]), child: Image.asset('assets/branding/raghad_brand.png', fit: BoxFit.cover, alignment: const Alignment(0.0, -0.1))),
              const SizedBox(height: 24),
              const Text('رغد', style: TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.w900)),
              const Text('رحلتي نحو التفوق', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 18),
              const Text('أتعلم • أكتشف • أنجح', style: TextStyle(color: Colors.white70, fontSize: 14)),
            ],
          ))),)),
      ),
    );
  }
}
