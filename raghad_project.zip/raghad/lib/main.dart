import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'models.dart';
import 'progress_store.dart';
import 'screens.dart';
import 'services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await ProgressStore.open();
  themeNotifier.value = switch (store.str('theme')) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };
  fontScaleNotifier.value = double.tryParse(store.str('fontScale') ?? '') ?? 1.0;
  final content = await Content.load(store);
  runApp(RaghadApp(store: store, content: content));
}

class RaghadApp extends StatelessWidget {
  const RaghadApp({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF7B4BC7);
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) => MaterialApp(
        title: 'رغد',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: seed),
        darkTheme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: seed,
            brightness: Brightness.dark),
        themeMode: mode,
        builder: (ctx, child) => ValueListenableBuilder<double>(
          valueListenable: fontScaleNotifier,
          builder: (_, f, __) => MediaQuery(
            data: MediaQuery.of(ctx).copyWith(textScaler: TextScaler.linear(f)),
            child: child!,
          ),
        ),
        home: Shell(store: store, content: content),
      ),
    );
  }
}
