import 'dart:convert';
import 'package:flutter/services.dart';
import 'progress_store.dart';

class Question {
  const Question({
    required this.id,
    required this.type,
    required this.text,
    required this.options,
    required this.answer,
    required this.difficulty,
    required this.explanation,
    this.accepted = const [],
    this.notes = const [],
  });
  final String id;
  final String type; // mcq | tf | fill | order
  final String text;
  final List<String> options; // للاختيارات، أو الترتيب الصحيح في order
  final int answer;
  final int difficulty;
  final String explanation;
  final List<String> accepted; // إجابات مقبولة في fill
  final List<String> notes; // تفسير الخطأ الشائع لكل خيار (اختياري)

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: j['id'] as String,
        type: (j['type'] ?? 'mcq') as String,
        text: j['text'] as String,
        options: List<String>.from((j['options'] ?? []) as List),
        answer: (j['answer'] ?? 0) as int,
        difficulty: (j['difficulty'] ?? 1) as int,
        explanation: (j['explanation'] ?? '') as String,
        accepted: List<String>.from((j['accepted'] ?? []) as List),
        notes: List<String>.from((j['notes'] ?? []) as List),
      );
}

class Lesson {
  const Lesson(this.id, this.title, this.objectives, this.body, this.questions,
      {this.source = '', this.status = 'published', this.version = 1});
  final String id;
  final String title;
  final List<String> objectives;
  final String body;
  final List<Question> questions;
  final String source;
  final String status;
  final int version;

  factory Lesson.fromJson(Map<String, dynamic> j) => Lesson(
        j['id'] as String,
        j['title'] as String,
        List<String>.from((j['objectives'] ?? []) as List),
        (j['body'] ?? '') as String,
        ((j['questions'] ?? []) as List)
            .map((e) => Question.fromJson(e as Map<String, dynamic>))
            .toList(),
        source: (j['source'] ?? '') as String,
        status: (j['status'] ?? 'published') as String,
        version: (j['version'] ?? 1) as int,
      );
}

class Subject {
  const Subject(this.id, this.name, this.lessons);
  final String id;
  final String name;
  final List<Lesson> lessons;
}

class Content {
  const Content(this.isSample, this.subjects, this.pairs);
  final bool isSample;
  final List<Subject> subjects;
  final List<List<String>> pairs;

  List<Question> get allQuestions => [
        for (final s in subjects)
          for (final l in s.lessons) ...l.questions
      ];

  static List<Lesson> _lessons(List<dynamic> l) =>
      l.map((e) => Lesson.fromJson(e as Map<String, dynamic>)).toList();

  /// يدمج: محتوى الأصول التجريبي + الحزم المثبّتة (المنشورة فقط) + دروس CMS المنشورة فقط.
  static Future<Content> load(ProgressStore store) async {
    final raw = await rootBundle.loadString('assets/content/sample_content.json');
    final j = jsonDecode(raw) as Map<String, dynamic>;
    final subjects = <Subject>[];
    final packs = store.map('packs').values;
    var anyPack = false;
    for (final e in packs) {
      final d = (e as Map<String, dynamic>)['data'] as Map<String, dynamic>;
      if (d['status'] != 'published') continue;
      anyPack = true;
      subjects.add(Subject(d['subjectId'] as String, d['subjectName'] as String,
          _lessons(d['lessons'] as List)));
    }
    if (!anyPack || (j['sample'] == false)) {
      for (final s in j['subjects'] as List) {
        final m = s as Map<String, dynamic>;
        subjects.add(Subject(m['id'] as String, m['name'] as String,
            _lessons(m['lessons'] as List)));
      }
    }
    final cms = store
        .map('cms')
        .values
        .cast<Map<String, dynamic>>()
        .where((m) => m['status'] == 'published')
        .toList();
    if (cms.isNotEmpty) {
      subjects.add(Subject('cms', 'دروس أضافها ولي الأمر', _lessons(cms)));
    }
    final pairs = (j['memoryPairs'] as List).map((p) {
      final m = p as Map<String, dynamic>;
      return <String>[m['a'] as String, m['b'] as String];
    }).toList();
    return Content(((j['sample'] ?? false) as bool) && !anyPack, subjects, pairs);
  }
}
