import 'dart:math';
import 'package:flutter/material.dart';
import 'progress_store.dart';

const mascotColors = [
  Color(0xFFB388FF),
  Color(0xFFFF8AB3),
  Color(0xFF4DD0C4),
  Color(0xFFFFD54F),
  Color(0xFF81C784),
];

class MascotPainter extends CustomPainter {
  MascotPainter(this.color, this.level, this.blink);
  final Color color;
  final int level;
  final double blink;

  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    final face = Paint()..color = color;
    c.drawCircle(Offset(w * 0.2, h * 0.3), w * 0.12, face);
    c.drawCircle(Offset(w * 0.8, h * 0.3), w * 0.12, face);
    c.drawOval(Rect.fromCenter(center: Offset(w / 2, h / 2), width: w * 0.8, height: h * 0.8), face);
    final white = Paint()..color = Colors.white;
    final dark = Paint()..color = const Color(0xFF2B2B2B);
    for (final dx in [0.32, 0.68]) {
      final e = Offset(w * dx, h * 0.45);
      c.drawOval(Rect.fromCenter(center: e, width: w * 0.18, height: h * 0.2 * (1 - blink * 0.9)), white);
      c.drawCircle(e, w * 0.04 * (1 - blink), dark);
    }
    final cheek = Paint()..color = Colors.pink.withValues(alpha: 0.35);
    c.drawCircle(Offset(w * 0.27, h * 0.62), w * 0.06, cheek);
    c.drawCircle(Offset(w * 0.73, h * 0.62), w * 0.06, cheek);
    final smile = Paint()
      ..color = const Color(0xFF2B2B2B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.025
      ..strokeCap = StrokeCap.round;
    c.drawArc(Rect.fromCenter(center: Offset(w * 0.5, h * 0.6), width: w * 0.3, height: h * 0.2), 0.2, 2.7, false, smile);
    if (level >= 2) {
      final g = Paint()
        ..color = const Color(0xFF5D4037)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.02;
      c.drawCircle(Offset(w * 0.32, h * 0.45), w * 0.11, g);
      c.drawCircle(Offset(w * 0.68, h * 0.45), w * 0.11, g);
      c.drawLine(Offset(w * 0.43, h * 0.45), Offset(w * 0.57, h * 0.45), g);
    }
    if (level >= 3) {
      final crown = Path()
        ..moveTo(w * 0.32, h * 0.14)
        ..lineTo(w * 0.36, h * 0.02)
        ..lineTo(w * 0.5, h * 0.1)
        ..lineTo(w * 0.64, h * 0.02)
        ..lineTo(w * 0.68, h * 0.14)
        ..close();
      c.drawPath(crown, Paint()..color = const Color(0xFFFFC107));
    }
  }

  @override
  bool shouldRepaint(covariant MascotPainter o) =>
      o.color != color || o.level != level || o.blink != blink;
}

/// شخصية رغد: ترمش وتتحرك حركة خفيفة، وتُفتح لها إكسسوارات بالمستويات.
class Mascot extends StatefulWidget {
  const Mascot({super.key, required this.size, required this.color, required this.level});
  final double size;
  final Color color;
  final int level;
  @override
  State<Mascot> createState() => _MascotState();
}

class _MascotState extends State<Mascot> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final v = _c.value;
        final blink = v > 0.9 ? (1 - ((v - 0.95).abs() / 0.05)).clamp(0.0, 1.0).toDouble() : 0.0;
        return Transform.translate(
          offset: Offset(0, sin(v * 2 * pi) * 4),
          child: CustomPaint(
            size: Size(widget.size, widget.size),
            painter: MascotPainter(widget.color, widget.level, blink),
          ),
        );
      },
    );
  }
}

class Confetti extends StatefulWidget {
  const Confetti({super.key});
  @override
  State<Confetti> createState() => _ConfettiState();
}

class _ConfettiState extends State<Confetti> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 2))..forward();
  final _r = Random(7);
  late final List<(double, double, Color, double)> _ps = List.generate(
      40,
      (i) => (_r.nextDouble(), 0.6 + _r.nextDouble() * 0.8,
          Colors.primaries[i % Colors.primaries.length], 4 + _r.nextDouble() * 5));

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) => CustomPaint(painter: _ConfPainter(_ps, _c.value)),
        ),
      );
}

class _ConfPainter extends CustomPainter {
  _ConfPainter(this.ps, this.t);
  final List<(double, double, Color, double)> ps;
  final double t;
  @override
  void paint(Canvas c, Size s) {
    for (final p in ps) {
      final y = s.height * (t * p.$2 - 0.1);
      final x = s.width * p.$1 + sin(t * 6 + p.$1 * 10) * 12;
      c.drawCircle(Offset(x, y), p.$4,
          Paint()..color = p.$3.withValues(alpha: (1 - t * 0.6).clamp(0.0, 1.0).toDouble()));
    }
  }

  @override
  bool shouldRepaint(covariant _ConfPainter o) => o.t != t;
}

class ResultView extends StatelessWidget {
  const ResultView({
    super.key,
    required this.percent,
    required this.right,
    required this.total,
    required this.onClose,
  });
  final int percent;
  final int right;
  final int total;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final stars = percent >= 90 ? 3 : percent >= 60 ? 2 : 1;
    return Scaffold(
      appBar: AppBar(title: const Text('النتيجة')),
      body: Stack(children: [
        Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(mainAxisSize: MainAxisSize.min, children: [
              for (var i = 0; i < 3; i++)
                TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: 1),
                  duration: Duration(milliseconds: 400 + i * 300),
                  curve: Curves.elasticOut,
                  builder: (_, v, child) => Transform.scale(scale: v, child: child),
                  child: Icon(i < stars ? Icons.star : Icons.star_border,
                      size: 56, color: Colors.amber),
                ),
            ]),
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: percent.toDouble()),
              duration: const Duration(milliseconds: 900),
              builder: (ctx, v, _) => Text('${v.round()}٪',
                  style: Theme.of(ctx).textTheme.displayMedium),
            ),
            Text('أجبتِ $right من $total بشكل صحيح'),
            const SizedBox(height: 8),
            Text(percent >= 60 ? 'رائع! استمري 🌟' : 'محاولة جميلة! راجعي وجرّبي مرة أخرى 💪'),
            const SizedBox(height: 16),
            FilledButton(onPressed: onClose, child: const Text('رجوع')),
          ]),
        ),
        if (percent >= 60) const Positioned.fill(child: Confetti()),
      ]),
    );
  }
}

class HomeHeader extends StatelessWidget {
  const HomeHeader({super.key, required this.store});
  final ProgressStore store;
  @override
  Widget build(BuildContext context) {
    final name = store.str('name') ?? 'رغد';
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: AlignmentDirectional.topStart, end: AlignmentDirectional.bottomEnd, colors: [Color(0xFF7045B5), Color(0xFF9569D0), Color(0xFFE78FB7)])),
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          Container(width: 86, height: 86, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white24, width: 2)), child: Image.asset('assets/branding/raghad_brand.png', fit: BoxFit.cover, alignment: const Alignment(-.92, -.1))),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('أهلًا يا $name 👋', style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.white, fontWeight: FontWeight.w800)),
              Text('المستوى ${store.level} • 🔥 ${store.streak} يوم', style: const TextStyle(color: Colors.white)),
              const SizedBox(height: 8),
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: (store.xp % 100) / 100),
                duration: const Duration(milliseconds: 800),
                builder: (_, v, __) => ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: v, minHeight: 9, backgroundColor: Colors.white30, color: const Color(0xFFFFD66E))),
              ),
              Text('${store.xp % 100} / 100 للمستوى التالي', style: const TextStyle(color: Colors.white70)),
            ]),
          ),
        ]),
      ),
    );
  }
}
