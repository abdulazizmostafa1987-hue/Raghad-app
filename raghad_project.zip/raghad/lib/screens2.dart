import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'home_widget_service.dart';
import 'models.dart';
import 'progress_store.dart';
import 'screens.dart';
import 'services.dart';

void _msg(BuildContext c, String t) {
  if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));
}

// ---------------- معلم رغد ----------------
class TutorPage extends StatefulWidget {
  const TutorPage({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  State<TutorPage> createState() => _TutorPageState();
}

class _TutorPageState extends State<TutorPage> {
  final _q = TextEditingController();
  final List<(bool, String)> _msgs = [];
  late final List<Lesson> _lessons = [
    for (final s in widget.content.subjects) ...s.lessons
  ];
  Lesson? _lesson;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _lesson = _lessons.isEmpty ? null : _lessons.first;
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final t = _q.text.trim();
    final l = _lesson;
    if (t.isEmpty || l == null || _busy) return;
    setState(() {
      _msgs.add((true, t));
      _busy = true;
      _q.clear();
    });
    String r;
    try {
      r = await GeminiService.tutor(widget.store, l.title, l.body, t);
    } catch (_) {
      r = 'لا أستطيع الاتصال الآن. راجعي شرح الدرس:\n${l.body}';
    }
    if (!mounted) return;
    setState(() {
      _msgs.add((false, r));
      _busy = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('معلم رغد')),
      body: Column(children: [
        if (_lesson != null)
          Padding(
            padding: const EdgeInsets.all(8),
            child: DropdownButton<Lesson>(
              isExpanded: true,
              value: _lesson,
              items: [
                for (final l in _lessons) DropdownMenuItem(value: l, child: Text(l.title))
              ],
              onChanged: (v) => setState(() => _lesson = v),
            ),
          ),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(8), children: [
            for (final m in _msgs)
              Align(
                alignment: m.$1 ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
                child: Card(
                    child: Padding(padding: const EdgeInsets.all(10), child: Text(m.$2))),
              ),
            if (_busy) const LinearProgressIndicator(),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(
                child: TextField(
                    controller: _q,
                    decoration: const InputDecoration(hintText: 'اسألي عن الدرس...'))),
            IconButton(onPressed: _send, icon: const Icon(Icons.send)),
          ]),
        ),
      ]),
    );
  }
}



// ---------------- مختبرات الاكتشاف ----------------
class LearningToolsPage extends StatelessWidget {
  const LearningToolsPage({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 5,
    child: Scaffold(
      appBar: AppBar(title: const Text('مختبرات الاكتشاف'), bottom: const TabBar(
        isScrollable: true,
        tabs: [Tab(text: 'معمل الرياضيات'), Tab(text: 'مختبر العلوم'), Tab(text: 'مستكشف الجغرافيا'), Tab(text: 'تدريب لغوي'), Tab(text: 'تفكير وبرمجة')],
      )),
      body: const TabBarView(children: [_MathLab(), _ScienceLab(), _GeoExplorer(), _LanguagePractice(), _CodeSequence()]),
    ),
  );
}

class _MathLab extends StatefulWidget {
  const _MathLab();
  @override
  State<_MathLab> createState() => _MathLabState();
}

class _MathLabState extends State<_MathLab> {
  final _a = TextEditingController(text: '12');
  final _b = TextEditingController(text: '18');
  String? _result;
  int? _parseNumber(String raw) {
    var value = raw.trim();
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    const eastern = '۰۱۲۳۴۵۶۷۸۹';
    for (var i = 0; i < 10; i++) {
      value = value.replaceAll(arabic[i], '$i').replaceAll(eastern[i], '$i');
    }
    return int.tryParse(value);
  }
  int _gcd(int a, int b) {
    a = a.abs(); b = b.abs();
    while (b != 0) { final t = b; b = a % b; a = t; }
    return a;
  }
  void _calculate() {
    final a = _parseNumber(_a.text);
    final b = _parseNumber(_b.text);
    if (a == null || b == null || a <= 0 || b <= 0) {
      setState(() => _result = 'اكتبي عددين صحيحين موجبين.');
      return;
    }
    final g = _gcd(a, b);
    final l = (a ~/ g) * b;
    setState(() => _result = 'العامل المشترك الأكبر = $g\nالمضاعف المشترك الأصغر = $l\n\nنراجع: $a × $b = $g × $l');
  }
  @override
  void dispose() { _a.dispose(); _b.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('جرّبي تغيير العددين واكتشفي العلاقة بين العامل المشترك الأكبر والمضاعف المشترك الأصغر.'),
    const SizedBox(height: 16),
    Row(children: [Expanded(child: TextField(controller: _a, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'العدد الأول'))), const SizedBox(width: 10), Expanded(child: TextField(controller: _b, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'العدد الثاني')))]),
    const SizedBox(height: 12), FilledButton(onPressed: _calculate, child: const Text('احسبي')),
    if (_result != null) Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(_result!, style: const TextStyle(fontSize: 18, height: 1.6)))),
    const Text('أداة تدريبية مساندة، وليست بديلًا عن شرح الدرس في الكتاب المدرسي.'),
  ]);
}

class _ScienceLab extends StatefulWidget {
  const _ScienceLab();
  @override
  State<_ScienceLab> createState() => _ScienceLabState();
}

class _ScienceLabState extends State<_ScienceLab> {
  static const _steps = [
    ('١. التبخر ☀️', 'تسخّن الشمس الماء في البحار والأنهار، فيتحول جزء منه إلى بخار ماء يصعد إلى الهواء.'),
    ('٢. التكاثف ☁️', 'يبرد بخار الماء في طبقات الجو، ويتحول إلى قطرات صغيرة تتجمع مكوّنة السحب.'),
    ('٣. الهطول 🌧️', 'عندما تكبر قطرات الماء وتثقل، تسقط من السحب مطرًا أو في صور أخرى بحسب الظروف.'),
    ('٤. التجمع 💧', 'تعود المياه إلى الأنهار والبحيرات والبحار، وتتسرب أجزاء منها إلى التربة، ثم تتكرر الدورة.'),
  ];
  int _step = 0;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('استكشفي دورة الماء في الطبيعة خطوة بخطوة.'),
    const SizedBox(height: 18),
    Card(color: Theme.of(context).colorScheme.secondaryContainer, child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [
      Text(_steps[_step].$1, style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
      const SizedBox(height: 14), Text(_steps[_step].$2, style: const TextStyle(fontSize: 18, height: 1.7), textAlign: TextAlign.center),
    ]))),
    LinearProgressIndicator(value: (_step + 1) / _steps.length),
    const SizedBox(height: 12),
    Row(children: [Expanded(child: OutlinedButton(onPressed: _step == 0 ? null : () => setState(() => _step--), child: const Text('السابق'))), const SizedBox(width: 8), Expanded(child: FilledButton(onPressed: _step == _steps.length - 1 ? () => setState(() => _step = 0) : () => setState(() => _step++), child: Text(_step == _steps.length - 1 ? 'إعادة الرحلة' : 'الخطوة التالية')))]),
    const SizedBox(height: 12),
    const Text('نموذج معرفي آمن للشرح والمشاهدة؛ لا يتطلب تنفيذ تجارب أو استخدام أدوات.'),
  ]);
}

class _GeoExplorer extends StatelessWidget {
  const _GeoExplorer();
  static const _places = [
    ('أفريقيا', 'تقع مصر في شمال شرق قارة أفريقيا، ويربط شبه جزيرة سيناء بينها وبين قارة آسيا.'),
    ('آسيا', 'أكبر قارات العالم مساحة، وتضم دولًا كثيرة ومناطق مناخية متنوعة.'),
    ('أوروبا', 'تقع شمال البحر المتوسط، وتضم دولًا ذات تضاريس ومناخات متنوعة.'),
    ('أمريكا الشمالية', 'تضم مساحات واسعة من السهول والجبال والغابات.'),
    ('أمريكا الجنوبية', 'يمر بها نهر الأمازون، وتضم غابات مطيرة واسعة.'),
    ('أستراليا وأوقيانوسيا', 'تضم أستراليا وجزرًا عديدة في المحيط الهادئ.'),
    ('القارة القطبية الجنوبية', 'قارة شديدة البرودة، وتغطي الجليد معظم مساحتها.'),
  ];
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(12), children: [
    const Text('بطاقات استكشاف القارات — اختاري بطاقة لقراءة معلومة جغرافية.'),
    for (final p in _places) Card(child: ExpansionTile(leading: const Icon(Icons.public), title: Text(p.$1), children: [Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), child: Text(p.$2, style: const TextStyle(fontSize: 16, height: 1.6)))])),
    const Text('معلومات إثرائية عامة؛ راجعي خريطة وموضوعات كتاب الدراسات المعتمد للمقرر.'),
  ]);
}



class _LanguagePractice extends StatefulWidget {
  const _LanguagePractice();
  @override
  State<_LanguagePractice> createState() => _LanguagePracticeState();
}

class _LanguagePracticeState extends State<_LanguagePractice> {
  static const _items = [
    ('أي الكلمات الآتية اسم؟', ['يكتب', 'مدرسة', 'إلى'], 1, 'مدرسة اسم يدل على مكان.'),
    ('ما مضاد كلمة «واسع»؟', ['ضيق', 'كبير', 'طويل'], 0, 'ضيق هو المضاد المناسب لكلمة واسع.'),
    ('أي الجمل تنتهي بعلامة استفهام؟', ['ما أجمل السماء!', 'أين كتابي؟', 'ذهبت إلى المدرسة.'], 1, 'السؤال ينتهي بعلامة الاستفهام (؟).'),
  ];
  final Map<int, int> _answers = {};
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(12), children: [
    const Text('تدريب لغوي قصير للتفكير في الكلمات وعلامات الترقيم.'),
    for (var i = 0; i < _items.length; i++) Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(_items[i].$1, style: Theme.of(context).textTheme.titleMedium),
      for (var j = 0; j < _items[i].$2.length; j++) RadioListTile<int>(contentPadding: EdgeInsets.zero, dense: true, value: j, groupValue: _answers[i], title: Text(_items[i].$2[j]), onChanged: (v) => setState(() => _answers[i] = v!)),
      if (_answers.containsKey(i)) Text(_answers[i] == _items[i].$3 ? 'إجابة صحيحة! ${_items[i].$4}' : 'حاولي مرة أخرى. ${_items[i].$4}'),
    ]))),
    Text('أجبتِ عن ${_answers.length} من ${_items.length} تدريبات.'),
  ]);
}

class _CodeSequence extends StatefulWidget {
  const _CodeSequence();
  @override
  State<_CodeSequence> createState() => _CodeSequenceState();
}

class _CodeSequenceState extends State<_CodeSequence> {
  static const _correct = ['ابدئي من نقطة البداية', 'تحركي خطوة إلى الأمام', 'انعطفي إلى اليمين', 'تحركي خطوة أخرى', 'توقفي عند النجمة'];
  late List<String> _steps = ['توقفي عند النجمة', 'تحركي خطوة أخرى', 'ابدئي من نقطة البداية', 'انعطفي إلى اليمين', 'تحركي خطوة إلى الأمام'];
  String? _result;
  void _move(int i, int d) {
    final j = i + d;
    if (j < 0 || j >= _steps.length) return;
    setState(() { final v = _steps.removeAt(i); _steps.insert(j, v); _result = null; });
  }
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(12), children: [
    const Text('رتّبي أوامر الروبوت ليصل إلى النجمة. هذا تدريب على التفكير الخوارزمي: كل خطوة لها ترتيب.'),
    for (var i = 0; i < _steps.length; i++) Card(child: ListTile(leading: CircleAvatar(child: Text('${i + 1}')), title: Text(_steps[i]), trailing: Wrap(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: i == 0 ? null : () => _move(i, -1), icon: const Icon(Icons.keyboard_arrow_up)), IconButton(onPressed: i == _steps.length - 1 ? null : () => _move(i, 1), icon: const Icon(Icons.keyboard_arrow_down))]))),
    FilledButton(onPressed: () => setState(() => _result = _steps.join('|') == _correct.join('|') ? 'ممتاز! وصل الروبوت إلى النجمة بالترتيب الصحيح.' : 'ليس بعد؛ بدّلي ترتيب بعض الخطوات ثم حاولي.'), child: const Text('تحققي من الترتيب')),
    if (_result != null) Text(_result!, style: Theme.of(context).textTheme.titleMedium),
    TextButton(onPressed: () => setState(() { _steps = ['توقفي عند النجمة', 'تحركي خطوة أخرى', 'ابدئي من نقطة البداية', 'انعطفي إلى اليمين', 'تحركي خطوة إلى الأمام']; _result = null; }), child: const Text('إعادة المحاولة')),
  ]);
}

// ---------------- جلسة مذاكرة هادئة ----------------
class StudySessionPage extends StatefulWidget {
  const StudySessionPage({super.key, required this.store});
  final ProgressStore store;
  @override
  State<StudySessionPage> createState() => _StudySessionPageState();
}

class _StudySessionPageState extends State<StudySessionPage> {
  Timer? _timer;
  int get _durationMinutes => widget.store.getInt('sessionMinutes', 20).clamp(10, 40).toInt();
  late int _remaining = _durationMinutes * 60;
  bool _running = false;
  bool _finished = false;
  int get _total => _durationMinutes * 60;

  void _start() {
    if (_finished || _running) return;
    setState(() => _running = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (_remaining <= 1) {
        _timer?.cancel();
        _complete();
      } else {
        setState(() => _remaining--);
      }
    });
  }

  void _pause() {
    _timer?.cancel();
    if (mounted) setState(() => _running = false);
  }

  Future<void> _complete() async {
    _timer?.cancel();
    final elapsed = ((_total - _remaining) / 60).ceil();
    final minutes = _remaining <= 1 ? _durationMinutes : elapsed;
    if (minutes > 0) await widget.store.recordStudySession(minutes);
    if (mounted) setState(() { _remaining = 0; _running = false; _finished = true; });
  }

  void _reset() {
    _timer?.cancel();
    setState(() { _remaining = _total; _running = false; _finished = false; });
  }

  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final mins = _remaining ~/ 60;
    final secs = _remaining % 60;
    final progress = _total == 0 ? 0.0 : 1 - (_remaining / _total);
    return Scaffold(
      appBar: AppBar(title: const Text('جلسة مذاكرة هادئة')),
      body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(
        mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.auto_awesome, size: 54),
          const SizedBox(height: 12),
          Text(_finished ? 'أحسنتِ! أنهيتِ جلستك 🌟' : 'ركّزي في مهمة واحدة صغيرة'),
          const SizedBox(height: 24),
          SizedBox(width: 220, height: 220, child: Stack(fit: StackFit.expand, children: [
            CircularProgressIndicator(value: progress, strokeWidth: 12),
            Center(child: Text('$mins:${secs.toString().padLeft(2, '0')}', style: Theme.of(context).textTheme.displayMedium)),
          ])),
          const SizedBox(height: 24),
          if (_finished)
            FilledButton.icon(onPressed: _reset, icon: const Icon(Icons.refresh), label: const Text('جلسة جديدة'))
          else
            Wrap(spacing: 12, children: [
              FilledButton.icon(onPressed: _running ? _pause : _start, icon: Icon(_running ? Icons.pause : Icons.play_arrow), label: Text(_running ? 'إيقاف مؤقت' : 'ابدئي')),
              OutlinedButton.icon(onPressed: _reset, icon: const Icon(Icons.refresh), label: const Text('إعادة')),
            ]),
          const SizedBox(height: 12),
          Text('إجمالي وقت المذاكرة المسجل: ${widget.store.studyMinutes} دقيقة'),
        ],
      ))),
    );
  }
}

// ---------------- جدول المذاكرة ----------------
class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key, required this.store});
  final ProgressStore store;
  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  static const _names = {6: 'السبت', 7: 'الأحد', 1: 'الاثنين', 2: 'الثلاثاء', 3: 'الأربعاء', 4: 'الخميس', 5: 'الجمعة'};
  late Set<int> _days = widget.store.studyDays;
  late int _goal = widget.store.weeklyGoal;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('جدول المذاكرة')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('أيام المذاكرة'),
        Wrap(spacing: 8, children: [
          for (final e in _names.entries)
            FilterChip(
              label: Text(e.value),
              selected: _days.contains(e.key),
              onSelected: (v) async {
                setState(() => v ? _days.add(e.key) : _days.remove(e.key));
                await widget.store.setStudyDays(_days);
              },
            ),
        ]),
        const SizedBox(height: 16),
        Text('الهدف الأسبوعي: $_goal اختبارات'),
        Slider(
          min: 1,
          max: 14,
          divisions: 13,
          value: _goal.toDouble(),
          onChanged: (v) => setState(() => _goal = v.round()),
          onChangeEnd: (v) => widget.store.setWeeklyGoal(v.round()),
        ),
        Text('أنجزتِ هذا الأسبوع: ${widget.store.attemptsThisWeek} من $_goal'),
        LinearProgressIndicator(
            value: (widget.store.attemptsThisWeek / _goal).clamp(0, 1).toDouble()),
      ]),
    );
  }
}

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  Widget build(BuildContext context) {
    final ls = [
      for (final s in content.subjects)
        for (final l in s.lessons)
          if (store.favs.contains(l.id)) l
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: ls.isEmpty
          ? const Center(child: Text('لا توجد دروس مفضلة بعد.'))
          : ListView(children: [
              for (final l in ls)
                ListTile(
                  title: Text(l.title),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                          builder: (_) => LessonPage(lesson: l, store: store))),
                ),
            ]),
    );
  }
}

// ---------------- ولي الأمر ----------------
class ParentGate extends StatefulWidget {
  const ParentGate({super.key, required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  State<ParentGate> createState() => _ParentGateState();
}

class _ParentGateState extends State<ParentGate> {
  final _c = TextEditingController();
  String? _err;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final pin = _c.text;
    if (pin.length != 4) {
      setState(() => _err = 'الرمز 4 أرقام.');
      return;
    }
    if (!widget.store.hasPin) {
      await widget.store.setPin(pin);
    } else if (!widget.store.checkPin(pin)) {
      setState(() => _err = 'رمز غير صحيح.');
      return;
    }
    if (!mounted) return;
    Navigator.pushReplacement(
        context,
        MaterialPageRoute<void>(
            builder: (_) => ParentPanel(store: widget.store, onReload: widget.onReload)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ولي الأمر')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          Text(widget.store.hasPin ? 'أدخل الرمز' : 'أنشئ رمزًا من 4 أرقام'),
          TextField(
            controller: _c,
            obscureText: true,
            maxLength: 4,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(errorText: _err),
          ),
          FilledButton(onPressed: _submit, child: const Text('متابعة')),
        ]),
      ),
    );
  }
}

class ParentPanel extends StatelessWidget {
  const ParentPanel({super.key, required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('لوحة ولي الأمر'),
          bottom: const TabBar(isScrollable: true, tabs: [
            Tab(text: 'التقارير'),
            Tab(text: 'المحتوى'),
            Tab(text: 'التحديثات'),
            Tab(text: 'الإعدادات'),
          ]),
        ),
        body: TabBarView(children: [
          _Reports(store: store),
          _Cms(store: store, onReload: onReload),
          _Updates(store: store, onReload: onReload),
          _Settings(store: store, onReload: onReload),
        ]),
      ),
    );
  }
}

class _Reports extends StatelessWidget {
  const _Reports({required this.store});
  final ProgressStore store;
  @override
  Widget build(BuildContext context) {
    final att = store.attempts.where((a) => (a['total'] as int) > 0).toList();
    final avg = att.isEmpty
        ? 0
        : (att.map((a) => (a['correct'] as int) * 100 / (a['total'] as int)).reduce((x, y) => x + y) /
                att.length)
            .round();
    final lessons = <String>{for (final a in att) a['lesson'] as String}
      ..removeWhere((e) => e == 'review' || e == 'wrong' || e == 'daily' || e.startsWith('game'));
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('عدد الاختبارات: ${att.length}   •   المتوسط: $avg٪'),
      Text('هذا الأسبوع: ${store.attemptsThisWeek}   •   السلسلة: ${store.streak} يوم'),
      Text('جلسات المذاكرة: ${store.studySessions}   •   الوقت المسجل: ${store.studyMinutes} دقيقة'),
      Text('مراجعات مستحقة: ${store.dueIds().length}   •   أخطاء محفوظة: ${store.wrongIds.length}'),
      OutlinedButton.icon(
        icon: const Icon(Icons.copy),
        label: const Text('نسخ ملخص أسبوعي'),
        onPressed: () async {
          final t = 'ملخص رغد الأسبوعي\n'
              'الاختبارات هذا الأسبوع: ${store.attemptsThisWeek}\n'
              'المتوسط العام: $avg٪\n'
              'المستوى: ${store.level} • النقاط: ${store.xp}\n'
              'سلسلة الأيام: ${store.streak}\n'
              'جلسات المذاكرة: ${store.studySessions} • ${store.studyMinutes} دقيقة\n'
              'مراجعات مستحقة: ${store.dueIds().length}';
          await Clipboard.setData(ClipboardData(text: t));
          if (context.mounted) _msg(context, 'تم النسخ.');
        },
      ),
      const SizedBox(height: 8),
      const Text('الإكمال غير الإتقان: يُعدّ الدرس "متقنًا" عند 80٪ أو أكثر في آخر محاولة.'),
      const Divider(),
      if (lessons.isEmpty) const Text('لا توجد محاولات بعد.'),
      for (final id in lessons) ...[
        Builder(builder: (_) {
          final p = store.lastPercent(id) ?? 0;
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$id — ${p >= 80 ? 'متقن' : 'يحتاج مراجعة'} ($p٪)'),
            LinearProgressIndicator(value: p / 100),
            const SizedBox(height: 10),
          ]);
        }),
      ],
    ]);
  }
}

const _order = ['draft', 'review', 'approved', 'published'];
const _labels = {'draft': 'مسودة', 'review': 'قيد المراجعة', 'approved': 'معتمد', 'published': 'منشور'};
const _nextLabel = {'draft': 'إرسال للمراجعة', 'review': 'اعتماد', 'approved': 'نشر'};

class _Cms extends StatefulWidget {
  const _Cms({required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  State<_Cms> createState() => _CmsState();
}

class _CmsState extends State<_Cms> {
  late Map<String, dynamic> _cms = widget.store.map('cms');

  Future<void> _save() async {
    await widget.store.putMap('cms', _cms);
    await widget.onReload();
    if (mounted) setState(() {});
  }

  void _push(Map<String, dynamic> m) {
    (m['history'] as List).add({
      'v': m['version'],
      'title': m['title'],
      'body': m['body'],
      'objectives': jsonDecode(jsonEncode(m['objectives'] ?? <String>[])),
      'questions': jsonDecode(jsonEncode(m['questions'] ?? <dynamic>[])),
      'source': m['source'] ?? '',
      'at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> _edit([Map<String, dynamic>? m]) async {
    final t = TextEditingController(text: m?['title'] as String? ?? '');
    final b = TextEditingController(text: m?['body'] as String? ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(m == null ? 'درس جديد' : 'تعديل الدرس'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: t, decoration: const InputDecoration(labelText: 'العنوان')),
            TextField(controller: b, maxLines: 6, decoration: const InputDecoration(labelText: 'الشرح')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ')),
        ],
      ),
    );
    final title = t.text.trim();
    final body = b.text;
    t.dispose();
    b.dispose();
    if (ok != true || title.isEmpty) return;
    if (m == null) {
      final id = 'cms-${DateTime.now().millisecondsSinceEpoch}';
      _cms[id] = {
        'id': id, 'title': title, 'body': body, 'objectives': <String>[],
        'questions': <Map<String, dynamic>>[], 'status': 'draft', 'version': 1,
        'source': 'ولي الأمر', 'history': <Map<String, dynamic>>[],
      };
    } else {
      _push(m);
      m['title'] = title;
      m['body'] = body;
      m['version'] = (m['version'] as int) + 1;
      m['status'] = 'draft'; // أي تعديل يتطلب مراجعة واعتمادًا من جديد
    }
    await _save();
  }

  Future<void> _step(Map<String, dynamic> m, int d) async {
    final current = _order.indexOf(m['status'] as String);
    final i = current + d;
    if (i < 0 || i >= _order.length) return;
    if (d > 0 && _order[i] == 'published') {
      final body = (m['body'] as String? ?? '').trim();
      final questions = m['questions'] as List? ?? const [];
      if (body.length < 40 || questions.length < 3) {
        _msg(context, 'لا يمكن نشر الدرس قبل استكمال شرح واضح وثلاثة أسئلة على الأقل ومراجعتها.');
        return;
      }
    }
    m['status'] = _order[i];
    await _save();
  }

  Future<void> _gen(Map<String, dynamic> m) async {
    try {
      final qs = await GeminiService.draftQuestions(widget.store, m['title'] as String,
          m['body'] as String, '${m['id']}-${DateTime.now().millisecondsSinceEpoch}');
      _push(m);
      (m['questions'] as List).addAll(qs);
      m['status'] = 'draft';
      m['version'] = (m['version'] as int) + 1;
      await _save();
      if (mounted) _msg(context, 'أُضيفت ${qs.length} أسئلة كمسودة للمراجعة.');
    } catch (e) {
      if (mounted) _msg(context, 'تعذّر التوليد: $e');
    }
  }

  Future<void> _restore(Map<String, dynamic> m) async {
    final h = (m['history'] as List).cast<Map<String, dynamic>>();
    final pick = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (c) => SimpleDialog(title: const Text('استعادة نسخة'), children: [
        if (h.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('لا توجد نسخ سابقة.')),
        for (final x in h.reversed)
          SimpleDialogOption(
              onPressed: () => Navigator.pop(c, x),
              child: Text('الإصدار ${x['v']} — ${x['title']}')),
      ]),
    );
    if (pick == null) return;
    _push(m);
    m['title'] = pick['title'];
    m['body'] = pick['body'];
    if (pick['objectives'] is List) m['objectives'] = pick['objectives'];
    if (pick['questions'] is List) m['questions'] = pick['questions'];
    if (pick['source'] is String) m['source'] = pick['source'];
    m['version'] = (m['version'] as int) + 1;
    m['status'] = 'draft';
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    final items = _cms.values.cast<Map<String, dynamic>>().toList();
    return Scaffold(
      floatingActionButton: FloatingActionButton(onPressed: _edit, child: const Icon(Icons.add)),
      body: items.isEmpty
          ? const Center(child: Text('لا توجد دروس. أضيفي درسًا بالزر +'))
          : ListView(padding: const EdgeInsets.all(8), children: [
              for (final m in items)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(m['title'] as String, style: Theme.of(context).textTheme.titleMedium),
                      Text('${_labels[m['status']]} • إصدار ${m['version']} • ${(m['questions'] as List).length} سؤال'),
                      Wrap(spacing: 6, children: [
                        TextButton(onPressed: () => _edit(m), child: const Text('تعديل')),
                        if (m['status'] != 'published')
                          FilledButton(
                              onPressed: () => _step(m, 1),
                              child: Text(_nextLabel[m['status']]!)),
                        if (m['status'] != 'draft')
                          TextButton(onPressed: () => _step(m, -1), child: const Text('تراجع خطوة')),
                        TextButton(onPressed: () => _gen(m), child: const Text('أسئلة Gemini')),
                        TextButton(onPressed: () => _restore(m), child: const Text('النسخ')),
                        TextButton(
                            onPressed: () async {
                              _cms.remove(m['id']);
                              await _save();
                            },
                            child: const Text('حذف')),
                      ]),
                    ]),
                  ),
                ),
            ]),
    );
  }
}

class _Updates extends StatefulWidget {
  const _Updates({required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  State<_Updates> createState() => _UpdatesState();
}

class _UpdatesState extends State<_Updates> {
  bool _busy = false;
  late String _log = widget.store.str('updateLog') ?? 'لم يتم التحقق بعد.';

  Future<void> _run() async {
    setState(() => _busy = true);
    final r = await UpdateService.check(widget.store);
    await widget.onReload();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _log = r.join('\n');
    });
  }

  @override
  Widget build(BuildContext context) {
    final packs = widget.store.map('packs');
    return ListView(padding: const EdgeInsets.all(16), children: [
      FilledButton.icon(
          onPressed: _busy ? null : _run,
          icon: const Icon(Icons.system_update),
          label: const Text('التحقق من تحديثات المحتوى')),
      if (_busy) const LinearProgressIndicator(),
      const SizedBox(height: 12),
      Text(_log),
      const Divider(),
      Text('الحزم المثبّتة: ${packs.length}'),
      for (final e in packs.entries) Text('• ${e.key} — الإصدار ${(e.value as Map)['version']}'),
    ]);
  }
}

class _Settings extends StatefulWidget {
  const _Settings({required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  State<_Settings> createState() => _SettingsState();
}

class _SettingsState extends State<_Settings> {
  final _key = TextEditingController();

  @override
  void initState() {
    super.initState();
    SecretStore.read('geminiKey').then((v) {
      if (mounted) _key.text = v;
    });
  }

  late final _model = TextEditingController(text: widget.store.str('geminiModel') ?? 'gemini-2.5-flash');
  late final _url = TextEditingController(text: widget.store.str('manifestUrl') ?? '');
  final _pin = TextEditingController();

  @override
  void dispose() {
    _key.dispose();
    _model.dispose();
    _url.dispose();
    _pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [Icon(Icons.widgets_rounded), SizedBox(width: 8), Expanded(child: Text('أداة رغد على الشاشة الرئيسية', style: TextStyle(fontWeight: FontWeight.w800)))]),
            const SizedBox(height: 6),
            const Text('تعرض آخر درس ونقاط الخبرة وسلسلة أيام التعلم. بعد تثبيت التطبيق، اضغطي مطولًا على مساحة فارغة في الشاشة الرئيسية ثم الأدوات واختاري رغد.'),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: () async {
                try {
                  await RaghadHomeWidgetService.sync(studentName: s.str('name') ?? 'رغد', lastLesson: s.str('widgetLastLessonTitle') ?? 'ابدئي رحلة التعلم', xp: s.xp, streak: s.streak, studyMinutes: s.studyMinutes);
                  if (context.mounted) _msg(context, 'تم تحديث بيانات أداة رغد. أضيفيها من قائمة أدوات الشاشة الرئيسية.');
                } catch (_) {
                  if (context.mounted) _msg(context, 'تعذر تحديث الأداة الآن. تأكدي من تثبيت نسخة Android التي تحتوي على دعم الأداة.');
                }
              },
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('تحديث بيانات الأداة'),
            ),
          ]),
        ),
      ),
      Text('إعدادات المنهج', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 6),
      DropdownButtonFormField<String>(
        value: s.str('schoolTrack') ?? 'arabic',
        decoration: const InputDecoration(labelText: 'نوع المدرسة / مسار اللغة'),
        items: const [
          DropdownMenuItem(value: 'arabic', child: Text('مدارس عربي – Connect')),
          DropdownMenuItem(value: 'languages', child: Text('مدارس لغات – Connect Plus')),
        ],
        onChanged: (v) async { if (v != null) { await s.putStr('schoolTrack', v); setState(() {}); } },
      ),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        value: s.str('religionTrack') ?? 'both',
        decoration: const InputDecoration(labelText: 'التربية الدينية'),
        items: const [
          DropdownMenuItem(value: 'islamic', child: Text('التربية الدينية الإسلامية')),
          DropdownMenuItem(value: 'christian', child: Text('التربية الدينية المسيحية')),
          DropdownMenuItem(value: 'both', child: Text('إتاحة المنهجين واختيار ولي الأمر')),
        ],
        onChanged: (v) async { if (v != null) { await s.putStr('religionTrack', v); setState(() {}); } },
      ),
      const Divider(height: 28),
      Text('تجربة التعلم', style: Theme.of(context).textTheme.titleLarge),
      SwitchListTile(
        title: const Text('المؤثرات الصوتية'), subtitle: const Text('أصوات التنقل والتفاعل'),
        value: s.flag('soundOn', def: true),
        onChanged: (v) async { await s.putFlag('soundOn', v); if (v) SystemSound.play(SystemSoundType.click); setState(() {}); },
      ),
      SwitchListTile(
        title: const Text('الاهتزاز اللمسي'),
        value: s.flag('hapticsOn', def: true),
        onChanged: (v) async { await s.putFlag('hapticsOn', v); if (v) HapticFeedback.selectionClick(); setState(() {}); },
      ),
      SwitchListTile(
        title: const Text('وضع التركيز'), subtitle: const Text('تقليل عناصر التحفيز أثناء جلسة المذاكرة'),
        value: s.flag('focusMode'),
        onChanged: (v) async { await s.putFlag('focusMode', v); setState(() {}); },
      ),
      DropdownButtonFormField<int>(
        value: s.getInt('sessionMinutes', 20),
        decoration: const InputDecoration(labelText: 'مدة جلسة المذاكرة'),
        items: const [10, 15, 20, 25, 30, 40].map((v) => DropdownMenuItem(value: v, child: Text('$v دقيقة'))).toList(),
        onChanged: (v) async { if (v != null) await s.putInt('sessionMinutes', v); },
      ),
      const Divider(height: 28),
      SwitchListTile(
        title: const Text('تفعيل معلم رغد (Gemini)'),
        value: s.flag('tutorOn'),
        onChanged: (v) async {
          await s.putFlag('tutorOn', v);
          await widget.onReload();
          setState(() {});
        },
      ),
      TextField(controller: _key, obscureText: true, decoration: const InputDecoration(labelText: 'مفتاح Gemini API')),
      TextField(controller: _model, decoration: const InputDecoration(labelText: 'اسم النموذج')),
      TextField(controller: _url, decoration: const InputDecoration(labelText: 'رابط manifest.json للتحديثات')),
      const SizedBox(height: 8),
      FilledButton(
        onPressed: () async {
          await SecretStore.write('geminiKey', _key.text.trim());
          await s.putStr('geminiModel', _model.text.trim());
          await s.putStr('manifestUrl', _url.text.trim());
          if (context.mounted) _msg(context, 'تم الحفظ.');
        },
        child: const Text('حفظ'),
      ),
      const Divider(),
      DropdownButton<String>(
        value: s.str('theme') ?? 'system',
        items: const [
          DropdownMenuItem(value: 'system', child: Text('المظهر: حسب الجهاز')),
          DropdownMenuItem(value: 'light', child: Text('المظهر: فاتح')),
          DropdownMenuItem(value: 'dark', child: Text('المظهر: داكن')),
        ],
        onChanged: (v) async {
          await s.putStr('theme', v ?? 'system');
          themeNotifier.value = switch (v) {
            'light' => ThemeMode.light,
            'dark' => ThemeMode.dark,
            _ => ThemeMode.system,
          };
          setState(() {});
        },
      ),
      Text('حجم الخط: ${fontScaleNotifier.value.toStringAsFixed(1)}'),
      Slider(
        min: 0.8,
        max: 1.4,
        divisions: 6,
        value: fontScaleNotifier.value,
        onChanged: (v) {
          fontScaleNotifier.value = v;
          setState(() {});
        },
        onChangeEnd: (v) => s.putStr('fontScale', v.toString()),
      ),
      TextField(controller: _pin, maxLength: 4, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رمز جديد (4 أرقام)')),
      OutlinedButton(
        onPressed: () async {
          if (_pin.text.length == 4) {
            await s.setPin(_pin.text);
            _pin.clear();
            if (context.mounted) _msg(context, 'تم تغيير الرمز.');
          }
        },
        child: const Text('تغيير الرمز'),
      ),
      const Divider(),
      Text('النسخ الاحتياطي', style: Theme.of(context).textTheme.titleMedium),
      OutlinedButton.icon(
        icon: const Icon(Icons.backup_outlined),
        label: const Text('نسخ بيانات التقدم إلى الحافظة'),
        onPressed: () async {
          await Clipboard.setData(ClipboardData(text: s.exportBackup()));
          if (context.mounted) _msg(context, 'تم نسخ النسخة الاحتياطية. احتفظي بها في مكان آمن.');
        },
      ),
      OutlinedButton.icon(
        icon: const Icon(Icons.restore_rounded),
        label: const Text('استعادة نسخة احتياطية من الحافظة'),
        onPressed: () async {
          final clip = await Clipboard.getData(Clipboard.kTextPlain);
          final raw = clip?.text;
          if (raw == null || raw.isEmpty) { if (context.mounted) _msg(context, 'لا توجد نسخة نصية في الحافظة.'); return; }
          final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
            title: const Text('استعادة النسخة؟'),
            content: const Text('ستُضاف بيانات النسخة إلى بيانات التطبيق الحالية. لن يتم استبدال رمز ولي الأمر أو مفاتيح الخدمات.'),
            actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('استعادة'))],
          ));
          if (ok == true) {
            try { await s.restoreBackup(raw); await widget.onReload(); if (context.mounted) _msg(context, 'تمت استعادة البيانات.'); }
            catch (_) { if (context.mounted) _msg(context, 'تعذرت الاستعادة: النسخة غير صالحة.'); }
          }
        },
      ),
      const Divider(),
      TextButton(
        style: TextButton.styleFrom(foregroundColor: Colors.red),
        onPressed: () async {
          final ok = await showDialog<bool>(
            context: context,
            builder: (c) => AlertDialog(
              title: const Text('حذف كل البيانات؟'),
              content: const Text('سيُحذف التقدم والمحتوى والإعدادات نهائيًا.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
                FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف')),
              ],
            ),
          );
          if (ok == true) {
            await SecretStore.write('geminiKey', '');
            await s.wipe();
            await widget.onReload();
            if (context.mounted) _msg(context, 'تم الحذف. أعيدي فتح التطبيق.');
          }
        },
        child: const Text('حذف الحساب والبيانات'),
      ),
    ]);
  }
}
