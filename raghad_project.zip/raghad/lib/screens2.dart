import 'package:flutter/material.dart';
import 'models.dart';
import 'progress_store.dart';
import 'screens.dart';
import 'services.dart';

void _msg(BuildContext c, String t) {
  if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));
}

// ---------------- معلم رغد ----------------
class TutorPage extends StatefulWidget {
  const TutorPage({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  State<TutorPage> createState() => _TutorPageState();
}

class _TutorPageState extends State<TutorPage> {
  final _q = TextEditingController();
  final List<(bool, String)> _msgs = [];
  late final List<Lesson> _lessons = [
    for (final s in widget.content.subjects) ...s.lessons
  ];
  Lesson? _lesson;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _lesson = _lessons.isEmpty ? null : _lessons.first;
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final t = _q.text.trim();
    final l = _lesson;
    if (t.isEmpty || l == null || _busy) return;
    setState(() {
      _msgs.add((true, t));
      _busy = true;
      _q.clear();
    });
    String r;
    try {
      r = await GeminiService.tutor(widget.store, l.title, l.body, t);
    } catch (_) {
      r = 'لا أستطيع الاتصال الآن. راجعي شرح الدرس:\n${l.body}';
    }
    if (!mounted) return;
    setState(() {
      _msgs.add((false, r));
      _busy = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('معلم رغد')),
      body: Column(children: [
        if (_lesson != null)
          Padding(
            padding: const EdgeInsets.all(8),
            child: DropdownButton<Lesson>(
              isExpanded: true,
              value: _lesson,
              items: [
                for (final l in _lessons) DropdownMenuItem(value: l, child: Text(l.title))
              ],
              onChanged: (v) => setState(() => _lesson = v),
            ),
          ),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(8), children: [
            for (final m in _msgs)
              Align(
                alignment: m.$1 ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
                child: Card(
                    child: Padding(padding: const EdgeInsets.all(10), child: Text(m.$2))),
              ),
            if (_busy) const LinearProgressIndicator(),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(
                child: TextField(
                    controller: _q,
                    decoration: const InputDecoration(hintText: 'اسألي عن الدرس...'))),
            IconButton(onPressed: _send, icon: const Icon(Icons.send)),
          ]),
        ),
      ]),
    );
  }
}

// ---------------- جدول المذاكرة ----------------
class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key, required this.store});
  final ProgressStore store;
  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  static const _names = {6: 'السبت', 7: 'الأحد', 1: 'الاثنين', 2: 'الثلاثاء', 3: 'الأربعاء', 4: 'الخميس', 5: 'الجمعة'};
  late Set<int> _days = widget.store.studyDays;
  late int _goal = widget.store.weeklyGoal;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('جدول المذاكرة')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('أيام المذاكرة'),
        Wrap(spacing: 8, children: [
          for (final e in _names.entries)
            FilterChip(
              label: Text(e.value),
              selected: _days.contains(e.key),
              onSelected: (v) async {
                setState(() => v ? _days.add(e.key) : _days.remove(e.key));
                await widget.store.setStudyDays(_days);
              },
            ),
        ]),
        const SizedBox(height: 16),
        Text('الهدف الأسبوعي: $_goal اختبارات'),
        Slider(
          min: 1,
          max: 14,
          divisions: 13,
          value: _goal.toDouble(),
          onChanged: (v) => setState(() => _goal = v.round()),
          onChangeEnd: (v) => widget.store.setWeeklyGoal(v.round()),
        ),
        Text('أنجزتِ هذا الأسبوع: ${widget.store.attemptsThisWeek} من $_goal'),
        LinearProgressIndicator(
            value: (widget.store.attemptsThisWeek / _goal).clamp(0, 1).toDouble()),
      ]),
    );
  }
}

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key, required this.store, required this.content});
  final ProgressStore store;
  final Content content;
  @override
  Widget build(BuildContext context) {
    final ls = [
      for (final s in content.subjects)
        for (final l in s.lessons)
          if (store.favs.contains(l.id)) l
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: ls.isEmpty
          ? const Center(child: Text('لا توجد دروس مفضلة بعد.'))
          : ListView(children: [
              for (final l in ls)
                ListTile(
                  title: Text(l.title),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                          builder: (_) => LessonPage(lesson: l, store: store))),
                ),
            ]),
    );
  }
}

// ---------------- ولي الأمر ----------------
class ParentGate extends StatefulWidget {
  const ParentGate({super.key, required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  State<ParentGate> createState() => _ParentGateState();
}

class _ParentGateState extends State<ParentGate> {
  final _c = TextEditingController();
  String? _err;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final pin = _c.text;
    if (pin.length != 4) {
      setState(() => _err = 'الرمز 4 أرقام.');
      return;
    }
    if (!widget.store.hasPin) {
      await widget.store.setPin(pin);
    } else if (!widget.store.checkPin(pin)) {
      setState(() => _err = 'رمز غير صحيح.');
      return;
    }
    if (!mounted) return;
    Navigator.pushReplacement(
        context,
        MaterialPageRoute<void>(
            builder: (_) => ParentPanel(store: widget.store, onReload: widget.onReload)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ولي الأمر')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          Text(widget.store.hasPin ? 'أدخل الرمز' : 'أنشئ رمزًا من 4 أرقام'),
          TextField(
            controller: _c,
            obscureText: true,
            maxLength: 4,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(errorText: _err),
          ),
          FilledButton(onPressed: _submit, child: const Text('متابعة')),
        ]),
      ),
    );
  }
}

class ParentPanel extends StatelessWidget {
  const ParentPanel({super.key, required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('لوحة ولي الأمر'),
          bottom: const TabBar(isScrollable: true, tabs: [
            Tab(text: 'التقارير'),
            Tab(text: 'المحتوى'),
            Tab(text: 'التحديثات'),
            Tab(text: 'الإعدادات'),
          ]),
        ),
        body: TabBarView(children: [
          _Reports(store: store),
          _Cms(store: store, onReload: onReload),
          _Updates(store: store, onReload: onReload),
          _Settings(store: store, onReload: onReload),
        ]),
      ),
    );
  }
}

class _Reports extends StatelessWidget {
  const _Reports({required this.store});
  final ProgressStore store;
  @override
  Widget build(BuildContext context) {
    final att = store.attempts.where((a) => (a['total'] as int) > 0).toList();
    final avg = att.isEmpty
        ? 0
        : (att.map((a) => (a['correct'] as int) * 100 / (a['total'] as int)).reduce((x, y) => x + y) /
                att.length)
            .round();
    final lessons = <String>{for (final a in att) a['lesson'] as String}
      ..removeWhere((e) => e == 'review' || e == 'wrong' || e == 'daily' || e.startsWith('game'));
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('عدد الاختبارات: ${att.length}   •   المتوسط: $avg٪'),
      Text('هذا الأسبوع: ${store.attemptsThisWeek}   •   السلسلة: ${store.streak} يوم'),
      Text('مراجعات مستحقة: ${store.dueIds().length}   •   أخطاء محفوظة: ${store.wrongIds.length}'),
      const SizedBox(height: 8),
      const Text('الإكمال غير الإتقان: يُعدّ الدرس "متقنًا" عند 80٪ أو أكثر في آخر محاولة.'),
      const Divider(),
      if (lessons.isEmpty) const Text('لا توجد محاولات بعد.'),
      for (final id in lessons) ...[
        Builder(builder: (_) {
          final p = store.lastPercent(id) ?? 0;
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$id — ${p >= 80 ? 'متقن' : 'يحتاج مراجعة'} ($p٪)'),
            LinearProgressIndicator(value: p / 100),
            const SizedBox(height: 10),
          ]);
        }),
      ],
    ]);
  }
}

const _order = ['draft', 'review', 'approved', 'published'];
const _labels = {'draft': 'مسودة', 'review': 'قيد المراجعة', 'approved': 'معتمد', 'published': 'منشور'};
const _nextLabel = {'draft': 'إرسال للمراجعة', 'review': 'اعتماد', 'approved': 'نشر'};

class _Cms extends StatefulWidget {
  const _Cms({required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  State<_Cms> createState() => _CmsState();
}

class _CmsState extends State<_Cms> {
  late Map<String, dynamic> _cms = widget.store.map('cms');

  Future<void> _save() async {
    await widget.store.putMap('cms', _cms);
    await widget.onReload();
    if (mounted) setState(() {});
  }

  void _push(Map<String, dynamic> m) {
    (m['history'] as List).add({
      'v': m['version'],
      'title': m['title'],
      'body': m['body'],
      'at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> _edit([Map<String, dynamic>? m]) async {
    final t = TextEditingController(text: m?['title'] as String? ?? '');
    final b = TextEditingController(text: m?['body'] as String? ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(m == null ? 'درس جديد' : 'تعديل الدرس'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: t, decoration: const InputDecoration(labelText: 'العنوان')),
            TextField(controller: b, maxLines: 6, decoration: const InputDecoration(labelText: 'الشرح')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ')),
        ],
      ),
    );
    final title = t.text.trim();
    final body = b.text;
    t.dispose();
    b.dispose();
    if (ok != true || title.isEmpty) return;
    if (m == null) {
      final id = 'cms-${DateTime.now().millisecondsSinceEpoch}';
      _cms[id] = {
        'id': id, 'title': title, 'body': body, 'objectives': <String>[],
        'questions': <Map<String, dynamic>>[], 'status': 'draft', 'version': 1,
        'source': 'ولي الأمر', 'history': <Map<String, dynamic>>[],
      };
    } else {
      _push(m);
      m['title'] = title;
      m['body'] = body;
      m['version'] = (m['version'] as int) + 1;
      m['status'] = 'draft'; // أي تعديل يتطلب مراجعة واعتمادًا من جديد
    }
    await _save();
  }

  Future<void> _step(Map<String, dynamic> m, int d) async {
    final i = _order.indexOf(m['status'] as String) + d;
    if (i < 0 || i >= _order.length) return;
    m['status'] = _order[i];
    await _save();
  }

  Future<void> _gen(Map<String, dynamic> m) async {
    try {
      final qs = await GeminiService.draftQuestions(widget.store, m['title'] as String,
          m['body'] as String, '${m['id']}-${DateTime.now().millisecondsSinceEpoch}');
      _push(m);
      (m['questions'] as List).addAll(qs);
      m['status'] = 'draft';
      m['version'] = (m['version'] as int) + 1;
      await _save();
      if (mounted) _msg(context, 'أُضيفت ${qs.length} أسئلة كمسودة للمراجعة.');
    } catch (e) {
      if (mounted) _msg(context, 'تعذّر التوليد: $e');
    }
  }

  Future<void> _restore(Map<String, dynamic> m) async {
    final h = (m['history'] as List).cast<Map<String, dynamic>>();
    final pick = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (c) => SimpleDialog(title: const Text('استعادة نسخة'), children: [
        if (h.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('لا توجد نسخ سابقة.')),
        for (final x in h.reversed)
          SimpleDialogOption(
              onPressed: () => Navigator.pop(c, x),
              child: Text('الإصدار ${x['v']} — ${x['title']}')),
      ]),
    );
    if (pick == null) return;
    _push(m);
    m['title'] = pick['title'];
    m['body'] = pick['body'];
    m['version'] = (m['version'] as int) + 1;
    m['status'] = 'draft';
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    final items = _cms.values.cast<Map<String, dynamic>>().toList();
    return Scaffold(
      floatingActionButton: FloatingActionButton(onPressed: _edit, child: const Icon(Icons.add)),
      body: items.isEmpty
          ? const Center(child: Text('لا توجد دروس. أضيفي درسًا بالزر +'))
          : ListView(padding: const EdgeInsets.all(8), children: [
              for (final m in items)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(m['title'] as String, style: Theme.of(context).textTheme.titleMedium),
                      Text('${_labels[m['status']]} • إصدار ${m['version']} • ${(m['questions'] as List).length} سؤال'),
                      Wrap(spacing: 6, children: [
                        TextButton(onPressed: () => _edit(m), child: const Text('تعديل')),
                        if (m['status'] != 'published')
                          FilledButton(
                              onPressed: () => _step(m, 1),
                              child: Text(_nextLabel[m['status']]!)),
                        if (m['status'] != 'draft')
                          TextButton(onPressed: () => _step(m, -1), child: const Text('تراجع خطوة')),
                        TextButton(onPressed: () => _gen(m), child: const Text('أسئلة Gemini')),
                        TextButton(onPressed: () => _restore(m), child: const Text('النسخ')),
                        TextButton(
                            onPressed: () async {
                              _cms.remove(m['id']);
                              await _save();
                            },
                            child: const Text('حذف')),
                      ]),
                    ]),
                  ),
                ),
            ]),
    );
  }
}

class _Updates extends StatefulWidget {
  const _Updates({required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  State<_Updates> createState() => _UpdatesState();
}

class _UpdatesState extends State<_Updates> {
  bool _busy = false;
  late String _log = widget.store.str('updateLog') ?? 'لم يتم التحقق بعد.';

  Future<void> _run() async {
    setState(() => _busy = true);
    final r = await UpdateService.check(widget.store);
    await widget.onReload();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _log = r.join('\n');
    });
  }

  @override
  Widget build(BuildContext context) {
    final packs = widget.store.map('packs');
    return ListView(padding: const EdgeInsets.all(16), children: [
      FilledButton.icon(
          onPressed: _busy ? null : _run,
          icon: const Icon(Icons.system_update),
          label: const Text('التحقق من تحديثات المحتوى')),
      if (_busy) const LinearProgressIndicator(),
      const SizedBox(height: 12),
      Text(_log),
      const Divider(),
      Text('الحزم المثبّتة: ${packs.length}'),
      for (final e in packs.entries) Text('• ${e.key} — الإصدار ${(e.value as Map)['version']}'),
    ]);
  }
}

class _Settings extends StatefulWidget {
  const _Settings({required this.store, required this.onReload});
  final ProgressStore store;
  final Future<void> Function() onReload;
  @override
  State<_Settings> createState() => _SettingsState();
}

class _SettingsState extends State<_Settings> {
  final _key = TextEditingController();

  @override
  void initState() {
    super.initState();
    SecretStore.read('geminiKey').then((v) {
      if (mounted) _key.text = v;
    });
  }

  late final _model = TextEditingController(text: widget.store.str('geminiModel') ?? 'gemini-2.5-flash');
  late final _url = TextEditingController(text: widget.store.str('manifestUrl') ?? '');
  final _pin = TextEditingController();

  @override
  void dispose() {
    _key.dispose();
    _model.dispose();
    _url.dispose();
    _pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    return ListView(padding: const EdgeInsets.all(16), children: [
      SwitchListTile(
        title: const Text('تفعيل معلم رغد (Gemini)'),
        value: s.flag('tutorOn'),
        onChanged: (v) async {
          await s.putFlag('tutorOn', v);
          await widget.onReload();
          setState(() {});
        },
      ),
      TextField(controller: _key, obscureText: true, decoration: const InputDecoration(labelText: 'مفتاح Gemini API')),
      TextField(controller: _model, decoration: const InputDecoration(labelText: 'اسم النموذج')),
      TextField(controller: _url, decoration: const InputDecoration(labelText: 'رابط manifest.json للتحديثات')),
      const SizedBox(height: 8),
      FilledButton(
        onPressed: () async {
          await SecretStore.write('geminiKey', _key.text.trim());
          await s.putStr('geminiModel', _model.text.trim());
          await s.putStr('manifestUrl', _url.text.trim());
          if (context.mounted) _msg(context, 'تم الحفظ.');
        },
        child: const Text('حفظ'),
      ),
      const Divider(),
      DropdownButton<String>(
        value: s.str('theme') ?? 'system',
        items: const [
          DropdownMenuItem(value: 'system', child: Text('المظهر: حسب الجهاز')),
          DropdownMenuItem(value: 'light', child: Text('المظهر: فاتح')),
          DropdownMenuItem(value: 'dark', child: Text('المظهر: داكن')),
        ],
        onChanged: (v) async {
          await s.putStr('theme', v ?? 'system');
          themeNotifier.value = switch (v) {
            'light' => ThemeMode.light,
            'dark' => ThemeMode.dark,
            _ => ThemeMode.system,
          };
          setState(() {});
        },
      ),
      Text('حجم الخط: ${fontScaleNotifier.value.toStringAsFixed(1)}'),
      Slider(
        min: 0.8,
        max: 1.4,
        divisions: 6,
        value: fontScaleNotifier.value,
        onChanged: (v) {
          fontScaleNotifier.value = v;
          setState(() {});
        },
        onChangeEnd: (v) => s.putStr('fontScale', v.toString()),
      ),
      TextField(controller: _pin, maxLength: 4, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رمز جديد (4 أرقام)')),
      OutlinedButton(
        onPressed: () async {
          if (_pin.text.length == 4) {
            await s.setPin(_pin.text);
            _pin.clear();
            if (context.mounted) _msg(context, 'تم تغيير الرمز.');
          }
        },
        child: const Text('تغيير الرمز'),
      ),
      const Divider(),
      TextButton(
        style: TextButton.styleFrom(foregroundColor: Colors.red),
        onPressed: () async {
          final ok = await showDialog<bool>(
            context: context,
            builder: (c) => AlertDialog(
              title: const Text('حذف كل البيانات؟'),
              content: const Text('سيُحذف التقدم والمحتوى والإعدادات نهائيًا.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
                FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف')),
              ],
            ),
          );
          if (ok == true) {
            await SecretStore.write('geminiKey', '');
            await s.wipe();
            await widget.onReload();
            if (context.mounted) _msg(context, 'تم الحذف. أعيدي فتح التطبيق.');
          }
        },
        child: const Text('حذف الحساب والبيانات'),
      ),
    ]);
  }
}
