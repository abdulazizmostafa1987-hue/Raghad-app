import 'dart:math';
import 'package:flutter/material.dart';
import 'game_logic.dart';
import 'models.dart';
import 'progress_store.dart';
import 'widgets.dart';

class MascotPage extends StatefulWidget {
  const MascotPage({super.key, required this.store});
  final ProgressStore store;
  @override
  State<MascotPage> createState() => _MascotPageState();
}

class _MascotPageState extends State<MascotPage> {
  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    return Scaffold(
      appBar: AppBar(title: const Text('تخصيص رغد')),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Mascot(size: 160, color: mascotColors[s.mascot % mascotColors.length], level: s.level),
          const SizedBox(height: 12),
          Text('المستوى ${s.level}'),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('النظارة تُفتح في المستوى ٢، والتاج في المستوى ٣'),
          ),
          Wrap(spacing: 12, children: [
            for (var i = 0; i < mascotColors.length; i++)
              GestureDetector(
                onTap: () async {
                  await s.setMascot(i);
                  setState(() {});
                },
                child: CircleAvatar(
                  radius: 22,
                  backgroundColor: mascotColors[i],
                  child: s.mascot == i ? const Icon(Icons.check, color: Colors.white) : null,
                ),
              ),
          ]),
        ]),
      ),
    );
  }
}

class FlashcardsPage extends StatefulWidget {
  const FlashcardsPage({super.key, required this.questions, required this.store});
  final List<Question> questions;
  final ProgressStore store;
  @override
  State<FlashcardsPage> createState() => _FlashcardsPageState();
}

class _FlashcardsPageState extends State<FlashcardsPage> {
  late final List<Question> _qs = [...widget.questions]..shuffle();
  int _i = 0;
  int _known = 0;
  bool _back = false;
  bool _done = false;

  String _answer(Question q) {
    if (q.type == 'fill') return q.accepted.isEmpty ? '' : q.accepted.first;
    if (q.type == 'order') return q.options.join(' ← ');
    return q.options[q.answer];
  }

  Future<void> _mark(bool known) async {
    if (known) _known++;
    if (_i + 1 < _qs.length) {
      setState(() {
        _i++;
        _back = false;
      });
      return;
    }
    await widget.store.recordAttempt(
        lessonId: 'game-flash', correct: _known, total: _qs.length, wrong: {}, right: {});
    if (mounted) setState(() => _done = true);
  }

  Widget _side(String t, Color? c) => Card(
        color: c,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22)),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (_done) {
      return Scaffold(
        appBar: AppBar(title: const Text('البطاقات')),
        body: Center(child: Text('عرفتِ $_known من ${_qs.length} 🌟')),
      );
    }
    final q = _qs[_i];
    final back = Theme.of(context).colorScheme.secondaryContainer;
    return Scaffold(
      appBar: AppBar(title: Text('بطاقة ${_i + 1} من ${_qs.length}')),
      body: Column(children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: GestureDetector(
              onTap: () => setState(() => _back = !_back),
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: _back ? pi : 0),
                duration: const Duration(milliseconds: 350),
                builder: (_, a, __) {
                  final front = a < pi / 2;
                  return Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..setEntry(3, 2, 0.001)
                      ..rotateY(a),
                    child: front
                        ? _side(q.text, null)
                        : Transform(
                            alignment: Alignment.center,
                            transform: Matrix4.identity()..rotateY(pi),
                            child: _side('${_answer(q)}\n\n${q.explanation}', back),
                          ),
                  );
                },
              ),
            ),
          ),
        ),
        const Text('اضغطي على البطاقة لقلبها'),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            OutlinedButton(onPressed: () => _mark(false), child: const Text('أراجعها لاحقًا')),
            FilledButton(onPressed: () => _mark(true), child: const Text('عرفتها ✅')),
          ]),
        ),
      ]),
    );
  }
}

class MatchGamePage extends StatefulWidget {
  const MatchGamePage({super.key, required this.pairs, required this.store});
  final List<List<String>> pairs;
  final ProgressStore store;
  @override
  State<MatchGamePage> createState() => _MatchGamePageState();
}

class _MatchGamePageState extends State<MatchGamePage> {
  late final List<(int, String)> _l = [
    for (var i = 0; i < widget.pairs.length; i++) (i, widget.pairs[i][0])
  ]..shuffle();
  late final List<(int, String)> _r = [
    for (var i = 0; i < widget.pairs.length; i++) (i, widget.pairs[i][1])
  ]..shuffle();
  int? _sl;
  int? _sr;
  bool _bad = false;
  final Set<int> _done = {};

  void _tap(bool left, int id) {
    if (_done.contains(id) || _bad) return;
    setState(() {
      if (left) {
        _sl = id;
      } else {
        _sr = id;
      }
    });
    if (_sl != null && _sr != null) {
      final ok = _sl == _sr;
      if (ok) {
        setState(() {
          _done.add(_sl!);
          _sl = null;
          _sr = null;
        });
        if (_done.length == widget.pairs.length) {
          widget.store.recordAttempt(
              lessonId: 'game-match',
              correct: widget.pairs.length,
              total: widget.pairs.length,
              wrong: {},
              right: {});
        }
      } else {
        setState(() => _bad = true);
        Future<void>.delayed(const Duration(milliseconds: 500), () {
          if (mounted) {
            setState(() {
              _bad = false;
              _sl = null;
              _sr = null;
            });
          }
        });
      }
    }
  }

  Widget _cell(String t, int id, bool left) {
    final sel = left ? _sl == id : _sr == id;
    final done = _done.contains(id);
    final scheme = Theme.of(context).colorScheme;
    final color = done
        ? Colors.green.withValues(alpha: 0.3)
        : sel
            ? (_bad ? Colors.orange.withValues(alpha: 0.35) : scheme.primaryContainer)
            : null;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        decoration: BoxDecoration(
          color: color ?? scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => _tap(left, id),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Center(child: Text(t, style: const TextStyle(fontSize: 20))),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final win = _done.length == widget.pairs.length && widget.pairs.isNotEmpty;
    return Scaffold(
      appBar: AppBar(title: Text(win ? 'أحسنتِ! وصّلتِ الكل 🎉' : 'لعبة التوصيل')),
      body: Stack(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: Column(children: [for (final x in _l) _cell(x.$2, x.$1, true)])),
            const SizedBox(width: 12),
            Expanded(child: Column(children: [for (final x in _r) _cell(x.$2, x.$1, false)])),
          ]),
        ),
        if (win) const Positioned.fill(child: Confetti()),
      ]),
    );
  }
}

class SpotErrorPage extends StatefulWidget {
  const SpotErrorPage({super.key, required this.questions, required this.store});
  final List<Question> questions;
  final ProgressStore store;
  @override
  State<SpotErrorPage> createState() => _SpotErrorPageState();
}

class _SpotErrorPageState extends State<SpotErrorPage> {
  final _r = Random();
  late List<Statement>? _st = GameLogic.spotTheError(widget.questions, _r);
  int _round = 0;
  int _score = 0;
  int? _picked;
  bool _done = false;

  void _pick(int i) {
    setState(() {
      _picked = i;
      if (!_st![i].correct) _score++;
    });
  }

  Future<void> _next() async {
    if (_round < 2) {
      setState(() {
        _round++;
        _picked = null;
        _st = GameLogic.spotTheError(widget.questions, _r) ?? _st;
      });
      return;
    }
    await widget.store.recordAttempt(
        lessonId: 'game-spot', correct: _score, total: 3, wrong: {}, right: {});
    if (mounted) setState(() => _done = true);
  }

  @override
  Widget build(BuildContext context) {
    final st = _st;
    if (st == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('اكتشف الخطأ')),
        body: const Center(child: Text('تحتاج اللعبة إلى ٣ أسئلة اختيار من متعدد على الأقل.')),
      );
    }
    if (_done) {
      return Scaffold(
        appBar: AppBar(title: const Text('اكتشف الخطأ')),
        body: Center(child: Text('اكتشفتِ $_score من 3 أخطاء 🎯')),
      );
    }
    return Scaffold(
      appBar: AppBar(title: Text('الجولة ${_round + 1} من 3')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('أي عبارة منها خاطئة؟', style: TextStyle(fontSize: 20)),
        const SizedBox(height: 8),
        for (var i = 0; i < st.length; i++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: _picked == null
                  ? Theme.of(context).colorScheme.surfaceContainerHighest
                  : !st[i].correct
                      ? Colors.green.withValues(alpha: 0.3)
                      : _picked == i
                          ? Colors.orange.withValues(alpha: 0.3)
                          : Theme.of(context).colorScheme.surfaceContainerHighest,
            ),
            child: ListTile(
              title: Text(st[i].text),
              onTap: _picked != null ? null : () => _pick(i),
            ),
          ),
        if (_picked != null) ...[
          Text(st[_picked!].correct
              ? 'ليست هذه الخاطئة. تمعّني أكثر في العبارات 🔍'
              : 'أحسنتِ! لقطتِ الخطأ 🎯'),
          const SizedBox(height: 8),
          FilledButton(onPressed: _next, child: const Text('التالي')),
        ],
      ]),
    );
  }
}
