import 'dart:math';
import 'models.dart';

class Statement {
  const Statement(this.text, this.correct);
  final String text;
  final bool correct;
}

class GameLogic {
  /// ثلاث عبارات: اثنتان صحيحتان وواحدة خاطئة، مبنية من أسئلة الاختيار من متعدد.
  static List<Statement>? spotTheError(List<Question> all, Random r) {
    final mcq = all.where((q) => q.type == 'mcq' && q.options.length >= 2).toList()
      ..shuffle(r);
    if (mcq.length < 3) return null;
    final picked = mcq.take(3).toList();
    final wrongIdx = r.nextInt(3);
    final out = <Statement>[];
    for (var i = 0; i < 3; i++) {
      final q = picked[i];
      if (i == wrongIdx) {
        final wrong = [
          for (var k = 0; k < q.options.length; k++)
            if (k != q.answer) q.options[k]
        ];
        out.add(Statement('${q.text} ${wrong[r.nextInt(wrong.length)]}', false));
      } else {
        out.add(Statement('${q.text} ${q.options[q.answer]}', true));
      }
    }
    return out;
  }
}
