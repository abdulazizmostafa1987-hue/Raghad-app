import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'progress_store.dart';

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.system);
final ValueNotifier<double> fontScaleNotifier = ValueNotifier(1.0);

/// تخزين مشفّر (Android Keystore) للمفاتيح السرية.
class SecretStore {
  static const _s = FlutterSecureStorage();
  static Future<String> read(String k) async {
    try {
      return await _s.read(key: k) ?? '';
    } catch (_) {
      return '';
    }
  }

  static Future<void> write(String k, String v) async {
    try {
      await _s.write(key: k, value: v);
    } catch (_) {}
  }
}

Future<String> _get(String url) async {
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  try {
    final r = await (await c.getUrl(Uri.parse(url))).close();
    if (r.statusCode != 200) throw HttpException('HTTP ${r.statusCode}');
    return await utf8.decoder.bind(r).join();
  } finally {
    c.close();
  }
}

/// تحديث حزم المحتوى (منفصل عن تحديث التطبيق). لا يلمس تقدم الطفلة.
class UpdateService {
  static Future<List<String>> check(ProgressStore s) async {
    final url = s.str('manifestUrl');
    if (url == null || url.isEmpty) return ['لم يُضبط رابط التحديثات بعد.'];
    final log = <String>[];
    try {
      final m = jsonDecode(await _get(url)) as Map<String, dynamic>;
      final packs = s.map('packs');
      for (final p in m['packs'] as List) {
        final pm = p as Map<String, dynamic>;
        final id = pm['id'] as String;
        final v = pm['version'] as int;
        final cur = ((packs[id] as Map?)?['version'] ?? 0) as int;
        if (v <= cur) continue;
        final body = await _get(pm['url'] as String);
        if (sha256.convert(utf8.encode(body)).toString() != pm['sha256']) {
          log.add('رُفضت الحزمة $id: البصمة غير مطابقة.');
          continue;
        }
        final data = jsonDecode(body) as Map<String, dynamic>;
        if (data['status'] != 'published') {
          log.add('تخطّي $id: غير معتمدة.');
          continue;
        }
        packs[id] = {'version': v, 'data': data};
        log.add('تم تحديث ${data['subjectName']} إلى الإصدار $v.');
      }
      await s.putMap('packs', packs);
      if (log.isEmpty) log.add('المحتوى محدّث.');
    } catch (e) {
      log.add('تعذّر التحديث: $e');
    }
    await s.putStr('updateLog', log.join('\n'));
    return log;
  }
}

class GeminiService {
  static const _tutorRules =
      'أنتِ "معلم رغد"، معلمة لطفلة في الصف السادس الابتدائي بمصر (تعليم عام). '
      'اشرحي بالعربية البسيطة وبخطوات قصيرة، وشجّعي الطفلة على التفكير قبل إعطاء الإجابة النهائية. '
      'التزمي بمحتوى الدرس المرفق فقط، وإن لم تكوني متأكدة فقولي ذلك بوضوح ولا تخترعي معلومات. '
      'ارفضي بلطف أي موضوع غير تعليمي، ولا تطلبي أي بيانات شخصية.';

  static const _safety = [
    {'category': 'HARM_CATEGORY_HARASSMENT', 'threshold': 'BLOCK_LOW_AND_ABOVE'},
    {'category': 'HARM_CATEGORY_HATE_SPEECH', 'threshold': 'BLOCK_LOW_AND_ABOVE'},
    {'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold': 'BLOCK_LOW_AND_ABOVE'},
    {'category': 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold': 'BLOCK_LOW_AND_ABOVE'},
  ];

  static Future<String> _call(ProgressStore s, String system, String user) async {
    final key = await SecretStore.read('geminiKey');
    if (key.isEmpty) throw StateError('لم يُضبط مفتاح Gemini.');
    final model = s.str('geminiModel') ?? 'gemini-2.5-flash';
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final req = await c.postUrl(Uri.parse(
          'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent'));
      req.headers.set('Content-Type', 'application/json');
      req.headers.set('x-goog-api-key', key);
      req.add(utf8.encode(jsonEncode({
        'systemInstruction': {
          'parts': [
            {'text': system}
          ]
        },
        'contents': [
          {
            'role': 'user',
            'parts': [
              {'text': user}
            ]
          }
        ],
        'safetySettings': _safety,
      })));
      final r = await req.close();
      final body = await utf8.decoder.bind(r).join();
      if (r.statusCode != 200) throw HttpException('HTTP ${r.statusCode}');
      final j = jsonDecode(body) as Map<String, dynamic>;
      return (j['candidates'] as List).first['content']['parts'].first['text']
          as String;
    } finally {
      c.close();
    }
  }

  static Future<String> tutor(
      ProgressStore s, String title, String body, String question) {
    return _call(s, _tutorRules,
        'الدرس: $title\nالشرح: $body\n\nسؤال الطفلة: $question');
  }

  /// يولّد مسودات أسئلة فقط؛ لا تُنشر قبل مراجعة واعتماد ولي الأمر.
  static Future<List<Map<String, dynamic>>> draftQuestions(
      ProgressStore s, String title, String body, String idPrefix) async {
    final txt = await _call(
        s,
        'أنت معدّ أسئلة تعليمية دقيق للصف السادس الابتدائي. أجب بـ JSON فقط بلا أي شرح.',
        'ضع 4 أسئلة أصلية (اختيار من متعدد وصح/خطأ) من هذا الدرس فقط. '
            'الصيغة: [{"type":"mcq","text":"","options":["","","",""],"answer":0,"difficulty":1,"explanation":""}] '
            'وللصح/الخطأ options=["صح","خطأ"].\nالدرس: $title\n$body');
    final clean = txt.replaceAll(RegExp(r'```json|```'), '').trim();
    final out = <Map<String, dynamic>>[];
    final list = jsonDecode(clean) as List;
    for (var i = 0; i < list.length; i++) {
      final q = list[i] as Map<String, dynamic>;
      final opts = q['options'];
      final a = q['answer'];
      if (q['text'] is String && opts is List && opts.length >= 2 && a is int && a >= 0 && a < opts.length) {
        q['id'] = '$idPrefix-g$i';
        q['type'] ??= 'mcq';
        out.add(q);
      }
    }
    return out;
  }
}
