import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'progress_store.dart';

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.system);
final ValueNotifier<double> fontScaleNotifier = ValueNotifier(1.0);

/// تخزين مشفّر (Android Keystore) للمفاتيح السرية.
class SecretStore {
  static const _s = FlutterSecureStorage();
  static Future<String> read(String k) async {
    try {
      return await _s.read(key: k) ?? '';
    } catch (_) {
      return '';
    }
  }

  static Future<void> write(String k, String v) async {
    try {
      await _s.write(key: k, value: v);
    } catch (_) {}
  }
}

Future<String> _get(String url) async {
  final uri = Uri.tryParse(url);
  if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
    throw const FormatException('يجب أن يكون رابط التحديث آمنًا ويبدأ بـ HTTPS.');
  }
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  try {
    final r = await (await c.getUrl(uri)).close();
    if (r.statusCode != 200) throw HttpException('HTTP ${r.statusCode}');
    return await utf8.decoder.bind(r).join();
  } finally {
    c.close();
  }
}

/// تحديث حزم المحتوى (منفصل عن تحديث التطبيق). لا يلمس تقدم الطفلة.
class UpdateService {
  static Future<List<String>> check(ProgressStore s) async {
    final url = s.str('manifestUrl');
    if (url == null || url.isEmpty) return ['لم يُضبط رابط التحديثات بعد.'];
    final log = <String>[];
    try {
      final decoded = jsonDecode(await _get(url));
      if (decoded is! Map<String, dynamic> || decoded['packs'] is! List) {
        throw const FormatException('ملف التحديثات لا يحتوي على قائمة حزم صحيحة.');
      }
      final m = decoded;
      final packs = s.map('packs');
      for (final p in m['packs'] as List) {
        if (p is! Map<String, dynamic> || p['id'] is! String || p['version'] is! int || p['url'] is! String || p['sha256'] is! String) {
          log.add('تم تخطي سجل تحديث غير مكتمل.');
          continue;
        }
        final pm = p;
        final id = pm['id'] as String;
        final v = pm['version'] as int;
        final cur = ((packs[id] as Map?)?['version'] ?? 0) as int;
        if (v <= cur) continue;
        final body = await _get(pm['url'] as String);
        final expectedHash = (pm['sha256'] as String).toLowerCase();
        if (!RegExp(r'^[a-f0-9]{64}$').hasMatch(expectedHash) || sha256.convert(utf8.encode(body)).toString() != expectedHash) {
          log.add('رُفضت الحزمة $id: البصمة غير مطابقة.');
          continue;
        }
        final packDecoded = jsonDecode(body);
        if (packDecoded is! Map<String, dynamic>) {
          log.add('رُفضت الحزمة $id: بنية المحتوى غير صالحة.');
          continue;
        }
        final data = packDecoded;
        if (data['status'] != 'published' || data['subjectId'] is! String || data['subjectName'] is! String || data['lessons'] is! List || (data['lessons'] as List).isEmpty) {
          log.add('تخطّي $id: بيانات الحزمة أو حالة النشر غير صحيحة.');
          continue;
        }
        final lessonList = data['lessons'] as List;
        final validLessons = lessonList.every((lesson) => lesson is Map<String, dynamic> && lesson['id'] is String && lesson['title'] is String && lesson['body'] is String && (lesson['body'] as String).trim().length >= 40 && lesson['questions'] is List && (lesson['questions'] as List).length >= 3);
        if (!validLessons) {
          log.add('رُفضت الحزمة $id: يوجد درس غير مكتمل أو أقل من ثلاثة أسئلة.');
          continue;
        }
        packs[id] = {'version': v, 'data': data};
        log.add('تم تحديث ${data['subjectName']} إلى الإصدار $v.');
      }
      await s.putMap('packs', packs);
      if (log.isEmpty) log.add('المحتوى محدّث.');
    } catch (e) {
      log.add('تعذّر التحديث: $e');
    }
    await s.putStr('updateLog', log.join('\n'));
    return log;
  }
}

class GeminiService {
  static const _tutorRules =
      'أنتِ "معلم رغد"، معلمة لطفلة في الصف السادس الابتدائي بمصر (تعليم عام). '
      'اشرحي بالعربية البسيطة وبخطوات قصيرة، وشجّعي الطفلة على التفكير قبل إعطاء الإجابة النهائية. '
      'التزمي بمحتوى الدرس المرفق فقط، وإن لم تكوني متأكدة فقولي ذلك بوضوح ولا تخترعي معلومات. '
      'ارفضي بلطف أي موضوع غير تعليمي، ولا تطلبي أي بيانات شخصية.';

  static const _safety = [
    {'category': 'HARM_CATEGORY_HARASSMENT', 'threshold': 'BLOCK_LOW_AND_ABOVE'},
    {'category': 'HARM_CATEGORY_HATE_SPEECH', 'threshold': 'BLOCK_LOW_AND_ABOVE'},
    {'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold': 'BLOCK_LOW_AND_ABOVE'},
    {'category': 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold': 'BLOCK_LOW_AND_ABOVE'},
  ];

  static Future<String> _call(ProgressStore s, String system, String user) async {
    final key = await SecretStore.read('geminiKey');
    if (key.isEmpty) throw StateError('لم يُضبط مفتاح Gemini.');
    final model = s.str('geminiModel') ?? 'gemini-2.5-flash';
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final req = await c.postUrl(Uri.parse(
          'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent'));
      req.headers.set('Content-Type', 'application/json');
      req.headers.set('x-goog-api-key', key);
      req.add(utf8.encode(jsonEncode({
        'systemInstruction': {
          'parts': [
            {'text': system}
          ]
        },
        'contents': [
          {
            'role': 'user',
            'parts': [
              {'text': user}
            ]
          }
        ],
        'safetySettings': _safety,
      })));
      final r = await req.close();
      final body = await utf8.decoder.bind(r).join();
      if (r.statusCode != 200) throw HttpException('HTTP ${r.statusCode}');
      final j = jsonDecode(body) as Map<String, dynamic>;
      return (j['candidates'] as List).first['content']['parts'].first['text']
          as String;
    } finally {
      c.close();
    }
  }

  static Future<String> tutor(
      ProgressStore s, String title, String body, String question) {
    return _call(s, _tutorRules,
        'الدرس: $title\nالشرح: $body\n\nسؤال الطفلة: $question');
  }

  /// يولّد مسودات أسئلة فقط؛ لا تُنشر قبل مراجعة واعتماد ولي الأمر.
  static Future<List<Map<String, dynamic>>> draftQuestions(
      ProgressStore s, String title, String body, String idPrefix) async {
    final txt = await _call(
        s,
        'أنت معدّ أسئلة تعليمية دقيق للصف السادس الابتدائي. أجب بـ JSON فقط بلا أي شرح.',
        'ضع 4 أسئلة أصلية (اختيار من متعدد وصح/خطأ) من هذا الدرس فقط. '
            'الصيغة: [{"type":"mcq","text":"","options":["","","",""],"answer":0,"difficulty":1,"explanation":""}] '
            'وللصح/الخطأ options=["صح","خطأ"].\nالدرس: $title\n$body');
    final clean = txt.replaceAll(RegExp(r'```json|```'), '').trim();
    final out = <Map<String, dynamic>>[];
    final list = jsonDecode(clean) as List;
    for (var i = 0; i < list.length; i++) {
      final q = list[i] as Map<String, dynamic>;
      final opts = q['options'];
      final a = q['answer'];
      if (q['text'] is String && opts is List && opts.length >= 2 && a is int && a >= 0 && a < opts.length) {
        q['id'] = '$idPrefix-g$i';
        q['type'] ??= 'mcq';
        out.add(q);
      }
    }
    return out;
  }
}
