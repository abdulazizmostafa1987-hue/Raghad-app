import 'package:home_widget/home_widget.dart';

/// Bridges the learner's local progress to a native Android launcher widget.
class RaghadHomeWidgetService {
  static const provider = 'RaghadHomeWidgetProvider';
  static const qualifiedProvider = 'com.example.raghad.RaghadHomeWidgetProvider';

  static Future<void> sync({
    required String studentName,
    required String lastLesson,
    required int xp,
    required int streak,
    required int studyMinutes,
  }) async {
    await HomeWidget.saveWidgetData<String>('studentName', studentName);
    await HomeWidget.saveWidgetData<String>('lastLesson', lastLesson);
    await HomeWidget.saveWidgetData<String>('xp', '$xp');
    await HomeWidget.saveWidgetData<String>('streak', '$streak');
    await HomeWidget.saveWidgetData<String>('studyMinutes', '$studyMinutes');
    await HomeWidget.saveWidgetData<String>('updatedAt', DateTime.now().toIso8601String());
    await HomeWidget.updateWidget(
      name: provider,
      androidName: provider,
      qualifiedAndroidName: qualifiedProvider,
    );
  }
}
