import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'home_widget_service.dart';

class ProgressStore {
  ProgressStore(this._p);
  final SharedPreferences _p;
  static Future<ProgressStore> open() async =>
      ProgressStore(await SharedPreferences.getInstance());

  String? str(String k) => _p.getString(k);
  Future<void> putStr(String k, String v) => _p.setString(k, v);
  bool flag(String k, {bool def = false}) => _p.getBool(k) ?? def;
  int getInt(String k, int def) => _p.getInt(k) ?? def;
  Future<void> putInt(String k, int v) => _p.setInt(k, v);
  Future<void> putFlag(String k, bool v) => _p.setBool(k, v);
  Map<String, dynamic> map(String k) {
    final s = _p.getString(k);
    return s == null ? <String, dynamic>{} : jsonDecode(s) as Map<String, dynamic>;
  }

  Future<void> putMap(String k, Map<String, dynamic> m) =>
      _p.setString(k, jsonEncode(m));
  Future<void> wipe() => _p.clear();

  /// نسخة احتياطية محلية قابلة للنقل. لا تتضمن رمز ولي الأمر أو مفاتيح الخدمات.
  String exportBackup() {
    final data = <String, dynamic>{};
    for (final key in _p.getKeys()) {
      if (key == 'pin' || key == 'geminiKey') continue;
      final value = _p.get(key);
      if (value is String || value is bool || value is int || value is double || value is List<String>) {
        data[key] = value;
      }
    }
    return jsonEncode({'format': 'raghad-backup-v1', 'createdAt': DateTime.now().toIso8601String(), 'data': data});
  }

  Future<void> restoreBackup(String raw) async {
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic> || decoded['format'] != 'raghad-backup-v1' || decoded['data'] is! Map) {
      throw const FormatException('ملف النسخة الاحتياطية غير صالح.');
    }
    // تحقق كامل قبل الكتابة حتى لا تُستعاد نسخة جزئيًا عند وجود قيمة تالفة.
    final data = decoded['data'] as Map;
    final valid = <String, Object>{};
    for (final entry in data.entries) {
      final key = entry.key;
      final value = entry.value;
      if (key is! String) throw const FormatException('اسم إعداد غير صالح.');
      if (key == 'pin' || key == 'geminiKey') continue;
      if (value is String || value is bool || value is int || value is double) {
        valid[key] = value;
      } else if (value is List && value.every((e) => e is String)) {
        valid[key] = List<String>.from(value);
      } else {
        throw const FormatException('نوع بيانات غير مدعوم في النسخة الاحتياطية.');
      }
    }
    for (final entry in valid.entries) {
      final value = entry.value;
      if (value is String) await _p.setString(entry.key, value);
      else if (value is bool) await _p.setBool(entry.key, value);
      else if (value is int) await _p.setInt(entry.key, value);
      else if (value is double) await _p.setDouble(entry.key, value);
      else if (value is List<String>) await _p.setStringList(entry.key, value);
    }
  }

  Future<void> _syncHomeWidget() async {
    await RaghadHomeWidgetService.sync(
      studentName: str('name') ?? 'رغد',
      lastLesson: str('widgetLastLessonTitle') ?? 'ابدئي رحلة التعلم',
      xp: xp,
      streak: streak,
      studyMinutes: studyMinutes,
    );
  }

  // ---- PIN ----
  String _h(String pin) => sha256.convert(utf8.encode('raghad:$pin')).toString();
  bool get hasPin => _p.getString('pin') != null;
  Future<void> setPin(String pin) => _p.setString('pin', _h(pin));
  bool checkPin(String pin) => _p.getString('pin') == _h(pin);

  // ---- XP / attempts ----
  int get xp => _p.getInt('xp') ?? 0;
  int get level => xp ~/ 100 + 1;
  String? get lastLesson => _p.getString('lastLesson');
  Future<void> setLastLesson(String id, {String? title}) async {
    await _p.setString('lastLesson', id);
    if (title != null) await _p.setString('widgetLastLessonTitle', title);
    try { await _syncHomeWidget(); } catch (_) {}
  }
  Set<String> get wrongIds => (_p.getStringList('wrong') ?? []).toSet();
  List<Map<String, dynamic>> get attempts => (_p.getStringList('attempts') ?? [])
      .map((s) => jsonDecode(s) as Map<String, dynamic>)
      .toList();

  int? lastPercent(String lessonId) {
    for (final a in attempts.reversed) {
      if (a['lesson'] == lessonId && (a['total'] as int) > 0) {
        return ((a['correct'] as int) * 100 / (a['total'] as int)).round();
      }
    }
    return null;
  }

  // ---- المراجعة المتباعدة (Leitner) ----
  static const _days = [0, 1, 3, 7, 14, 30];
  Map<String, dynamic> get leitner => map('leitner');
  Set<String> dueIds() {
    final now = DateTime.now();
    return leitner.entries.where((e) {
      try {
        final value = e.value;
        if (value is! Map || value['due'] is! String) return false;
        return !DateTime.parse(value['due'] as String).isAfter(now);
      } catch (_) {
        return false;
      }
    }).map((e) => e.key).toSet();
  }

  Future<void> recordAttempt({
    required String lessonId,
    required int correct,
    required int total,
    required Set<String> wrong,
    required Set<String> right,
  }) async {
    await _p.setInt('xp', xp + correct * 10);
    final w = wrongIds..addAll(wrong)..removeAll(right);
    await _p.setStringList('wrong', w.toList());
    final l = leitner;
    for (final id in right) {
      final b = (((l[id] as Map?)?['box'] ?? 0) as int);
      final nb = (b + 1).clamp(1, 5).toInt();
      l[id] = {
        'box': nb,
        'due': DateTime.now().add(Duration(days: _days[nb])).toIso8601String()
      };
    }
    for (final id in wrong) {
      l[id] = {
        'box': 1,
        'due': DateTime.now().add(const Duration(days: 1)).toIso8601String()
      };
    }
    await putMap('leitner', l);
    final list = _p.getStringList('attempts') ?? [];
    list.add(jsonEncode({
      'lesson': lessonId,
      'correct': correct,
      'total': total,
      'at': DateTime.now().toIso8601String(),
    }));
    await _p.setStringList('attempts', list);
    try { await _syncHomeWidget(); } catch (_) { /* Widget is optional until Android host is installed. */ }
  }

  // ---- سلسلة الأيام والأوسمة ----
  int get streak {
    final days = attempts
        .map((a) => DateTime.parse(a['at'] as String))
        .map((d) => DateTime(d.year, d.month, d.day))
        .toSet();
    var d = DateTime.now();
    d = DateTime(d.year, d.month, d.day);
    var n = 0;
    while (days.contains(d)) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  Map<String, bool> get badges {
    final a = attempts;
    return {
      'أول اختبار': a.isNotEmpty,
      'خمس محاولات': a.length >= 5,
      'درجة كاملة': a.any((x) => (x['total'] as int) > 0 && x['correct'] == x['total']),
      'ثلاثة أيام متتالية': streak >= 3,
      'مئة نقطة خبرة': xp >= 100,
    };
  }

  int get mascot => _p.getInt('mascot') ?? 0;
  Future<void> setMascot(int i) => _p.setInt('mascot', i);

  // ---- ملاحظات ومفضلة وجدول ----
  String note(String id) => _p.getString('note:$id') ?? '';
  Future<void> setNote(String id, String v) => _p.setString('note:$id', v);
  Set<String> get favs => (_p.getStringList('favs') ?? []).toSet();
  Future<void> toggleFav(String id) async {
    final f = favs;
    f.contains(id) ? f.remove(id) : f.add(id);
    await _p.setStringList('favs', f.toList());
  }

  Set<int> get studyDays =>
      (_p.getStringList('days') ?? []).map(int.parse).toSet();
  Future<void> setStudyDays(Set<int> d) =>
      _p.setStringList('days', d.map((e) => '$e').toList());
  int get weeklyGoal => _p.getInt('goal') ?? 3;
  Future<void> setWeeklyGoal(int g) => _p.setInt('goal', g);
  int get attemptsThisWeek => attempts
      .where((a) => DateTime.parse(a['at'] as String)
          .isAfter(DateTime.now().subtract(const Duration(days: 7))))
      .length;

  // ---- جلسات المذاكرة ----
  int get studyMinutes => _p.getInt('studyMinutes') ?? 0;
  int get studySessions => _p.getInt('studySessions') ?? 0;
  Future<void> recordStudySession(int minutes) async {
    if (minutes <= 0) return;
    await _p.setInt('studyMinutes', studyMinutes + minutes);
    await _p.setInt('studySessions', studySessions + 1);
    final entries = _p.getStringList('studyLog') ?? <String>[];
    entries.add(jsonEncode({'minutes': minutes, 'at': DateTime.now().toIso8601String()}));
    // نحتفظ بآخر 200 جلسة فقط حتى لا يكبر التخزين المحلي بلا حدود.
    if (entries.length > 200) entries.removeRange(0, entries.length - 200);
    await _p.setStringList('studyLog', entries);
    try { await _syncHomeWidget(); } catch (_) { /* Widget is optional until Android host is installed. */ }
  }
}
