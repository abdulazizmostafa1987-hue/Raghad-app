import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProgressStore {
  ProgressStore(this._p);
  final SharedPreferences _p;
  static Future<ProgressStore> open() async =>
      ProgressStore(await SharedPreferences.getInstance());

  String? str(String k) => _p.getString(k);
  Future<void> putStr(String k, String v) => _p.setString(k, v);
  bool flag(String k, {bool def = false}) => _p.getBool(k) ?? def;
  Future<void> putFlag(String k, bool v) => _p.setBool(k, v);
  Map<String, dynamic> map(String k) {
    final s = _p.getString(k);
    return s == null ? <String, dynamic>{} : jsonDecode(s) as Map<String, dynamic>;
  }

  Future<void> putMap(String k, Map<String, dynamic> m) =>
      _p.setString(k, jsonEncode(m));
  Future<void> wipe() => _p.clear();

  // ---- PIN ----
  String _h(String pin) => sha256.convert(utf8.encode('raghad:$pin')).toString();
  bool get hasPin => _p.getString('pin') != null;
  Future<void> setPin(String pin) => _p.setString('pin', _h(pin));
  bool checkPin(String pin) => _p.getString('pin') == _h(pin);

  // ---- XP / attempts ----
  int get xp => _p.getInt('xp') ?? 0;
  int get level => xp ~/ 100 + 1;
  String? get lastLesson => _p.getString('lastLesson');
  Future<void> setLastLesson(String id) => _p.setString('lastLesson', id);
  Set<String> get wrongIds => (_p.getStringList('wrong') ?? []).toSet();
  List<Map<String, dynamic>> get attempts => (_p.getStringList('attempts') ?? [])
      .map((s) => jsonDecode(s) as Map<String, dynamic>)
      .toList();

  int? lastPercent(String lessonId) {
    for (final a in attempts.reversed) {
      if (a['lesson'] == lessonId && (a['total'] as int) > 0) {
        return ((a['correct'] as int) * 100 / (a['total'] as int)).round();
      }
    }
    return null;
  }

  // ---- المراجعة المتباعدة (Leitner) ----
  static const _days = [0, 1, 3, 7, 14, 30];
  Map<String, dynamic> get leitner => map('leitner');
  Set<String> dueIds() {
    final now = DateTime.now();
    return leitner.entries
        .where((e) => DateTime.parse((e.value as Map)['due'] as String).isBefore(now))
        .map((e) => e.key)
        .toSet();
  }

  Future<void> recordAttempt({
    required String lessonId,
    required int correct,
    required int total,
    required Set<String> wrong,
    required Set<String> right,
  }) async {
    await _p.setInt('xp', xp + correct * 10);
    final w = wrongIds..addAll(wrong)..removeAll(right);
    await _p.setStringList('wrong', w.toList());
    final l = leitner;
    for (final id in right) {
      final b = (((l[id] as Map?)?['box'] ?? 0) as int);
      final nb = (b + 1).clamp(1, 5);
      l[id] = {
        'box': nb,
        'due': DateTime.now().add(Duration(days: _days[nb])).toIso8601String()
      };
    }
    for (final id in wrong) {
      l[id] = {
        'box': 1,
        'due': DateTime.now().add(const Duration(days: 1)).toIso8601String()
      };
    }
    await putMap('leitner', l);
    final list = _p.getStringList('attempts') ?? [];
    list.add(jsonEncode({
      'lesson': lessonId,
      'correct': correct,
      'total': total,
      'at': DateTime.now().toIso8601String(),
    }));
    await _p.setStringList('attempts', list);
  }

  // ---- سلسلة الأيام والأوسمة ----
  int get streak {
    final days = attempts
        .map((a) => DateTime.parse(a['at'] as String))
        .map((d) => DateTime(d.year, d.month, d.day))
        .toSet();
    var d = DateTime.now();
    d = DateTime(d.year, d.month, d.day);
    var n = 0;
    while (days.contains(d)) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  Map<String, bool> get badges {
    final a = attempts;
    return {
      'أول اختبار': a.isNotEmpty,
      'خمس محاولات': a.length >= 5,
      'درجة كاملة': a.any((x) => (x['total'] as int) > 0 && x['correct'] == x['total']),
      'ثلاثة أيام متتالية': streak >= 3,
      'مئة نقطة خبرة': xp >= 100,
    };
  }

  // ---- ملاحظات ومفضلة وجدول ----
  String note(String id) => _p.getString('note:$id') ?? '';
  Future<void> setNote(String id, String v) => _p.setString('note:$id', v);
  Set<String> get favs => (_p.getStringList('favs') ?? []).toSet();
  Future<void> toggleFav(String id) async {
    final f = favs;
    f.contains(id) ? f.remove(id) : f.add(id);
    await _p.setStringList('favs', f.toList());
  }

  Set<int> get studyDays =>
      (_p.getStringList('days') ?? []).map(int.parse).toSet();
  Future<void> setStudyDays(Set<int> d) =>
      _p.setStringList('days', d.map((e) => '$e').toList());
  int get weeklyGoal => _p.getInt('goal') ?? 3;
  Future<void> setWeeklyGoal(int g) => _p.setInt('goal', g);
  int get attemptsThisWeek => attempts
      .where((a) => DateTime.parse(a['at'] as String)
          .isAfter(DateTime.now().subtract(const Duration(days: 7))))
      .length;
}
