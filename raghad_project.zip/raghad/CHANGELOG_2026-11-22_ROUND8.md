# Round 8 — Quiz result reliability (2026-11-22)

- Fixed the quiz completion result to expose the final percentage immediately as stable text (`quiz-final-percent`) instead of exposing only a transient animation frame. This makes the result clear to learners, accessible, and deterministic for widget tests.
- Strengthened the true/false flow test to verify the visible final percentage, its stable result key, XP reward, and persisted attempt percentage.
- Updated GitHub Actions checkout and artifact-upload actions to current major versions.
- Bumped app version to 0.6.2+8.

Validation: source-level checks and curriculum audit are run before packaging. Flutter SDK is not available in this editing environment, so `flutter test`, `flutter analyze`, and APK build must be confirmed by GitHub Actions.
