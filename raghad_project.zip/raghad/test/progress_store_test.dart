import 'package:flutter_test/flutter_test.dart';
import 'package:raghad/progress_store.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('المراجعة المتباعدة والنقاط', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    await s.recordAttempt(
        lessonId: 'l', correct: 1, total: 2, wrong: {'b'}, right: {'a'});
    expect(s.xp, 10);
    expect(s.leitner['a']['box'], 1);
    expect(s.wrongIds, {'b'});
    expect(s.dueIds(), isEmpty);
    expect(s.lastPercent('l'), 50);
  });

  test('النسخة الاحتياطية تحفظ التقدم ولا تستبدل رمز ولي الأمر', () async {
    SharedPreferences.setMockInitialValues({'xp': 80, 'pin': 'hashed-pin', 'sessionMinutes': 15});
    final s = await ProgressStore.open();
    final backup = s.exportBackup();
    await s.putInt('sessionMinutes', 30);
    await s.restoreBackup(backup);
    expect(s.xp, 80);
    expect(s.getInt('sessionMinutes', 20), 15);
    expect(s.hasPin, true);
  });

  test('رمز ولي الأمر', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    expect(s.hasPin, false);
    await s.setPin('1234');
    expect(s.checkPin('1234'), true);
    expect(s.checkPin('0000'), false);
  });

  test('تسجيل جلسات المذاكرة يحفظ المدة وعدد الجلسات', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    await s.recordStudySession(20);
    await s.recordStudySession(15);
    expect(s.studyMinutes, 35);
    expect(s.studySessions, 2);
  });

  test('النسخة التالفة لا تغيّر البيانات الحالية جزئيًا', () async {
    SharedPreferences.setMockInitialValues({'xp': 42, 'sessionMinutes': 20});
    final s = await ProgressStore.open();
    const bad = '{"format":"raghad-backup-v1","data":{"xp":99,"bad":{"x":1}}}';
    await expectLater(s.restoreBackup(bad), throwsFormatException);
    expect(s.xp, 42);
  });

}
