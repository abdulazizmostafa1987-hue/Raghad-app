import 'package:flutter_test/flutter_test.dart';
import 'package:raghad/progress_store.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('المراجعة المتباعدة والنقاط', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    await s.recordAttempt(
        lessonId: 'l', correct: 1, total: 2, wrong: {'b'}, right: {'a'});
    expect(s.xp, 10);
    expect(s.leitner['a']['box'], 1);
    expect(s.wrongIds, {'b'});
    expect(s.dueIds(), isEmpty);
    expect(s.lastPercent('l'), 50);
  });

  test('رمز ولي الأمر', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    expect(s.hasPin, false);
    await s.setPin('1234');
    expect(s.checkPin('1234'), true);
    expect(s.checkPin('0000'), false);
  });
}
