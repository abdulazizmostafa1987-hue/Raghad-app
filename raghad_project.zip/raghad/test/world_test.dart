import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:raghad/models.dart';
import 'package:raghad/progress_store.dart';
import 'package:raghad/quiz_engine.dart';
import 'package:raghad/world/games.dart';
import 'package:raghad/world/lesson_flow.dart';
import 'package:raghad/world/practice_gen.dart';
import 'package:raghad/world/practice_runner.dart';
import 'package:raghad/world/rewards.dart';
import 'package:raghad/world/world_data.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:raghad/world/sfx.dart';

Question _q(String id) => Question(
    id: id, type: 'tf', text: 'سؤال $id', options: const ['صح', 'خطأ'], answer: 0, difficulty: 1, explanation: 'شرح');

Lesson _lesson(String id, int n) =>
    Lesson(id, 'درس $id', const ['هدف'], 'فقرة أولى.\n\nفقرة ثانية.', [for (var i = 0; i < n; i++) _q('$id-q$i')]);

void main() {
  Sfx.disabled = true;
  test('gcd و lcm', () {
    expect(gcd(12, 18), 6);
    expect(lcm(4, 6), 12);
  });

  test('مولّد الرياضيات: كل سؤال صالح وإجابته تُقبل', () {
    final r = Random(7);
    for (var round = 0; round < 40; round++) {
      for (final q in MathPractice.generate(r, count: 12, level: 1 + round % 2)) {
        expect(q.text.isNotEmpty, true);
        expect(q.explanation.isNotEmpty, true);
        if (q.type == 'fill') {
          expect(q.accepted.isNotEmpty, true);
          expect(QuizEngine.checkText(q, q.accepted.first), true, reason: q.text);
        } else if (q.type == 'mcq') {
          expect(q.options.length, 4);
          expect(q.options.toSet().length, 4, reason: q.text);
          expect(q.answer, inInclusiveRange(0, 3));
        } else {
          expect(q.type, 'tf');
          expect(q.options.length, 2);
        }
      }
    }
  });

  test('تقسيم نص الدرس إلى بطاقات', () {
    expect(splitBody('أ\n\nب\n\nج').length, 3);
    expect(splitBody('أ\\n\\nب').length, 2);
    expect(splitBody('   ').isEmpty, true);
  });

  test('النجوم والتقديرات', () {
    expect(starsForPercent(95), 3);
    expect(starsForPercent(75), 2);
    expect(starsForPercent(50), 1);
    expect(starsForPercent(10), 0);
    expect(gradeLabel(92), 'ممتاز');
    expect(gradeLabel(20), 'تحتاج مراجعة');
  });

  test('المكافآت: نجوم وعملات وصندوق ثم المتجر', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    final r = await s.rewardNode(nodeId: 'n1', correct: 3, total: 3);
    expect(r.stars, 3);
    expect(r.chest, true);
    expect(s.starsOf('n1'), 3);
    expect(s.coins, r.coins);
    expect(s.chests, 1);
    // إعادة المحاولة بنتيجة أقل لا تُنقص النجوم ولا تعطي صندوقًا جديدًا
    final r2 = await s.rewardNode(nodeId: 'n1', correct: 1, total: 3);
    expect(s.starsOf('n1'), 3);
    expect(r2.chest, false);
    // فتح الصندوق
    final chest = await s.openChest(Random(1));
    expect(chest, isNotNull);
    expect(s.chests, 0);
    expect(await s.openChest(), isNull);
    // الشراء
    await s.addCoins(500);
    final item = shopItems.firstWhere((e) => e.id == 'hat_crown');
    final before = s.coins;
    expect(await s.buy(item), true);
    expect(s.coins, before - item.price);
    await s.equip(item);
    expect(s.equipped['hat'], 'hat_crown');
    await s.unequip('hat');
    expect(s.equipped['hat'], isNull);
  });

  test('لا شراء بدون رصيد كافٍ', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    expect(await s.buy(shopItems.first), false);
    expect(s.coins, 0);
  });

  test('المهام اليومية', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    final qs = s.todaysQuests();
    expect(qs.length, 3);
    final q = qs.first;
    expect(await s.claimQuest(q), 0); // لم تكتمل
    await s.bumpQuest(q.id, q.goal);
    expect(s.questProgress(q.id), q.goal);
    expect(await s.claimQuest(q), q.coins);
    expect(await s.claimQuest(q), 0); // لا مكافأة مزدوجة
    expect(s.coins, q.coins);
  });

  test('الجزر: وحدات وزعيم وفتح تدريجي', () async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    final content = Content(false, [
      Subject('math_ar', 'رياضيات', [
        _lesson('math-divisibility-6', 3),
        _lesson('math-t1-u2-l1', 3),
        _lesson('math-t1-u2-l2', 3),
      ]),
      Subject('math_fr', 'fr', [_lesson('x', 3)]), // مخفية
    ], const []);
    final islands = buildIslands(content, s);
    expect(islands.length, 1);
    final i = islands.first;
    // وحدة 1 (درس واحد بدون زعيم) + وحدة 2 (درسان + زعيم)
    expect(i.nodes.length, 4);
    expect(i.nodes.last.isBoss, true);
    expect(i.isUnlocked(s, 0), true);
    expect(i.isUnlocked(s, 1), false);
    await s.rewardNode(nodeId: i.nodes[0].id, correct: 3, total: 3);
    expect(i.isUnlocked(s, 1), true);
    expect(i.nextNode(s)!.id, i.nodes[1].id);
    expect(continuePoint(islands, s)!.node.id, i.nodes[1].id);
  });

  test('مجمّع أسئلة الألعاب: اختيار فقط والعدد المطلوب', () {
    final qs = choicePool(Random(3), 12, content: [_q('a'), _q('b')]);
    expect(qs.length, 12);
    expect(qs.every((q) => (q.type == 'mcq' || q.type == 'tf') && q.options.length >= 2), true);
  });

  testWidgets('معركة الزعيم: إجابة صحيحة تُنقص طاقة الزعيم', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    await tester.pumpWidget(MaterialApp(
      home: BossBattlePage(store: s, questions: [for (var i = 0; i < 5; i++) _q('b$i')], bossName: 'زعيم'),
    ));
    expect(find.textContaining('طاقة الزعيم: 4/4'), findsOneWidget);
    await tester.tap(find.text('صح'));
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.textContaining('طاقة الزعيم: 3/4'), findsOneWidget);
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('مشغّل الأسئلة ينتهي ويعيد النتائج', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final s = await ProgressStore.open();
    List<AnswerRecord>? got;
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: PracticeRunner(
          questions: [_q('a')],
          store: s,
          onFinished: (r, secs) => got = r,
        ),
      ),
    ));
    await tester.tap(find.text('صح'));
    await tester.pump();
    expect(find.text('أحسنتِ! 🌟'), findsOneWidget);
    await tester.tap(find.text('إنهاء'));
    await tester.pump();
    expect(got, isNotNull);
    expect(got!.single.ok, true);
    // أوقف مؤقت المشغّل قبل نهاية الاختبار
    await tester.pumpWidget(const SizedBox());
  });
}
