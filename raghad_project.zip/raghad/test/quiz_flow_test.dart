import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:raghad/game_logic.dart';
import 'package:raghad/models.dart';
import 'package:raghad/progress_store.dart';
import 'package:raghad/screens.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('اختبار صح/خطأ حتى النتيجة', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = await ProgressStore.open();
    const q = Question(
        id: 't1', type: 'tf', text: 'سؤال', options: ['صح', 'خطأ'],
        answer: 0, difficulty: 1, explanation: 'تفسير');
    await tester.pumpWidget(MaterialApp(
        home: QuizPage(lessonId: 'x', questions: const [q], store: store)));
    await tester.tap(find.text('صح'));
    await tester.pump();
    expect(find.text('أحسنتِ! 🌟'), findsOneWidget);
    await tester.tap(find.text('التالي'));
    await tester.pumpAndSettle();
    expect(find.text('100٪'), findsOneWidget);
    expect(store.xp, 10);
  });

  testWidgets('سؤال أكمل', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = await ProgressStore.open();
    const q = Question(
        id: 'f1', type: 'fill', text: 'اكتبي ٦', options: [], answer: 0,
        difficulty: 1, explanation: '', accepted: ['٦']);
    await tester.pumpWidget(MaterialApp(
        home: QuizPage(lessonId: 'x', questions: const [q], store: store)));
    await tester.enterText(find.byType(TextField), '6');
    await tester.tap(find.text('تحقق'));
    await tester.pump();
    expect(find.text('أحسنتِ! 🌟'), findsOneWidget);
  });

  test('اكتشف الخطأ: عبارة خاطئة واحدة فقط', () {
    final qs = [
      for (var i = 0; i < 4; i++)
        Question(
            id: '$i', type: 'mcq', text: 'س$i', options: const ['أ', 'ب', 'ج'],
            answer: 0, difficulty: 1, explanation: '')
    ];
    final s = GameLogic.spotTheError(qs, Random(1))!;
    expect(s.length, 3);
    expect(s.where((x) => !x.correct).length, 1);
    expect(GameLogic.spotTheError(qs.take(2).toList(), Random(1)), isNull);
  });
}
