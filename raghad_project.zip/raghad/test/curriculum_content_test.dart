import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('Term 1 mathematics supplementary lessons have valid quizzes', () async {
    final raw = await rootBundle.loadString('assets/content/sample_content.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    expect(data['sample'], isFalse);
    final subjects = data['subjects'] as List;
    final math = subjects.cast<Map<String, dynamic>>().singleWhere((s) => s['id'] == 'math_ar');
    final lessons = math['lessons'] as List;
    expect(lessons.length, 33);
    for (final item in lessons.cast<Map<String, dynamic>>()) {
      expect((item['title'] as String).trim(), isNotEmpty);
      expect((item['body'] as String).trim().length, greaterThan(80));
      final questions = item['questions'] as List;
      expect(questions.length, greaterThanOrEqualTo(2));
      for (final q in questions.cast<Map<String, dynamic>>()) {
        final options = q['options'] as List;
        expect(options.length, greaterThanOrEqualTo(2));
        expect(q['answer'], inInclusiveRange(0, options.length - 1));
        expect((q['explanation'] as String).trim(), isNotEmpty);
      }
    }
  });

  test('Term 2 is not falsely labelled as published for 2026/2027', () async {
    final raw = await rootBundle.loadString('assets/content/curriculum_catalog.json');
    final catalog = jsonDecode(raw) as Map<String, dynamic>;
    final term2 = catalog['term2'] as Map<String, dynamic>;
    expect(term2['status'], 'archived_previous_school_year_2025_2026');
    expect((term2['notice'] as String).contains('2025/2026'), isTrue);
    expect((term2['subjects'] as List).length, greaterThanOrEqualTo(2));
  });

  test('Every published subject has unique lesson IDs and at least three quiz questions', () async {
    final raw = await rootBundle.loadString('assets/content/sample_content.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    final subjects = data['subjects'] as List;
    final lessonIds = <String>{};
    final questionIds = <String>{};
    for (final subject in subjects.cast<Map<String, dynamic>>()) {
      final lessons = subject['lessons'] as List;
      expect(lessons, isNotEmpty, reason: subject['id'] as String);
      for (final lesson in lessons.cast<Map<String, dynamic>>()) {
        expect(lessonIds.add(lesson['id'] as String), isTrue);
        expect((lesson['body'] as String).trim(), isNotEmpty);
        final questions = lesson['questions'] as List;
        expect(questions.length, greaterThanOrEqualTo(3));
        for (final question in questions.cast<Map<String, dynamic>>()) {
          expect(questionIds.add(question['id'] as String), isTrue);
          final options = question['options'] as List;
          expect(options.length, greaterThanOrEqualTo(2));
          expect(question['answer'], inInclusiveRange(0, options.length - 1));
          expect((question['explanation'] as String).trim(), isNotEmpty);
        }
      }
    }
  });
}
